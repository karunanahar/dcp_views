<div id="content-wrapper">
	<div class="row">
		<div class="col-lg-12">
			<div class="row">
				<div class="col-lg-12">
					<div id="content-header" class="clearfix">
						<div class="pull-left">
							<ol class="breadcrumb">
								<li><a href="<?php echo base_url('Admin_Dashboard');?>">Dashboard</a></li>
								<li class="active"><span>Portfolio</span></li>
							</ol>
						</div>
					</div>
					<div class="clearfix">
						<h1 class="pull-left">Portfolio</h1>
						<div class="pull-right top-page-ui">
							<a class="btn btn-primary pull-right openBtn" data-toggle="modal" data-target="#myModal" >
								<i class="fa fa-plus-circle fa-lg"></i> Add Portfolio
							</a>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12">
					<div class="main-box no-header clearfix">
						<div class="main-box-body clearfix">
							<div class="table-responsive">
								<table class="table user-list table-hover" id="table-example">
									<thead>
										<tr>
											<th><span>Sl No.</span></th>
											<th><span>Partenaire</span></th>
											<th><span>Date de Signature</span></th>
											<th><span>Taux</span></th>
											<th><span>Frais de Dossier</span></th>
											<th><span>DCP Calcule Assuranc</span></th>
											<th>Status</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
										<?php 
 										$count = 1;
										foreach ($groups as $row) {?>										<tr>
											<td><?php echo $count++; ?></td>
											<td><?php echo $row['company_name']; ?></td>
											<td><?php echo $row['date_signature']; ?></td>
											<td><?php echo $row['interest_tax']; ?></td>
											<td><?php echo $row['fraise_de_dossier_ht']; ?></td>
											<td><?php echo $row['assurance_calculate']; ?></td>
											<td class="text-center">
											<?php 
												if($row['status']=='1'){
												?>
											<span class="label label-success">
												Active
											</span>
										<?php }else{?>
											<span class="label label-danger">
												InActive
											</span>
										<?php }?>
											</td>
											<td style="width: 15%;">
												<a href="javascript:void(0);" class="table-link" class="btn btn-primary pull-right openBtn"  data-toggle="modal" data-target="#modal_edit" onClick="edit_group(<?php echo $row['company_id']; ?>)">
													<span class="fa-stack">
														<i class="fa fa-square fa-stack-2x"></i>
														<i class="fa fa-pencil fa-stack-1x fa-inverse"></i>
													</span>
												</a>

											</td>
										</tr>
									<?php } ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>	
	</div>
	

<div id="myModal" class="modal fade" data-keyboard="false" data-backdrop="static" role="dialog">
  <div class="modal-dialog modal-full-height modal-left modal-notify modal-info">
    <!-- Modal content-->
    <div class="modal-content">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
			<h4 class="modal-title heading lead">Créer un portefeuilleo</h4>
		</div>

		<form role="form" method="post" id="groupForm">

			<div class="flash-msg"></div>
			
            <input type="hidden" name="edit_id" id="edit_id">
	      	<div class="modal-body">
	      		<div class="form-group">        		
	        		<label for="inputError" class="control-label">Partenaire</label>
	        		<input type="text"  class="form-control" id="company_name" name="company_name" value="" placeholder="Enter Company Name">
	        	</div>
	        	
	        	<div class="form-group">        		
	        		<label for="inputError" class="control-label">Date de Signature</label>
	        		<input type="text"  class="form-control" id="date_signature" name="date_signature" value="" placeholder="Signature Date">
	        	</div>
	        	
	        	<div class="form-group">        		
	        		<label for="inputError" class="control-label">Taux</label>
	        		<input type="text"  class="form-control" id="interest_tax" name="interest_tax" value="" placeholder="Tax Interest">
	        	</div>
	        	
	        	<div class="form-group">        		
	        		<label for="inputError" class="control-label">Frais de Dossier</label>
	        		<input type="text"  class="form-control" id="fraise_de_dossier_ht" name="fraise_de_dossier_ht" value="" placeholder="Enter Fraise De Dossier">
	        	</div>
	        	
				<div class="form-group">        		
	        		<label for="inputError" class="control-label">DCP Calcule Assurance</label>
	        		<select class="form-control" id="assurance_calculate" name="assurance_calculate">
	        		    <option value="Y" id="Y">Y</option>
	        		    <option value="N" id="N">N</option>
	        		</select>
	        	</div>
	        	<div class="form-group" >
	        		<label>Status</label>	        		
	        		<select class="form-control" name="status" id="status">
	        			<option value="1">Active</option>
	        			<option value="0">InActive</option>
	        		</select>
	        	</div>
	    
	      	</div>
	      	<div class="modal-footer">
	          <button type="submit" class="btn btn-primary waves-effect waves-light submitBtn" name="save" value="Save">Submit</button>
	          <button type="button" class="btn btn-danger waves-effect waves-light"  data-dismiss="modal">Close</button> 
	          <div class="spinner-border text-success" role="status">
	          	<span class="sr-only">Loading...</span>
	          </div>      
	        </div> 
         </form>
    </div>

  </div>
</div>
 

<script type="text/javascript">
	$(function() {			
		$('.openBtn').on('click',function(){
		 $("#groupForm")[0].reset();	
		 $("h4").text("Créer un portefeuille");			 
			$('.modal-body').load(function(){
			   			
            	$('#myModal').modal({show:true});
        	});
		});			
	});
	
	$('[data-dismiss=modal]').on('click', function (e) {
		var $t = $(this),		
		target = $t[0].href || $t.data("target") || $t.parents('#myModal') || [];		
		$(target)
	    .find("input").val('').end().find("input[type=checkbox]").prop("checked", " ").end();
	    $("label.has-error").html(' ');
	    $("label.has-error").removeClass("has-error");
	    //document.getElementById("errorDiv1").innerHTML=" ";
	   });



	function edit_group(row_id)
	{
		$("#groupForm")[0].reset();
		$("#myModal").modal('show');

		$("h4").text("Modifier le portefeuille");

		$.ajax({

			type:"POST",
			url:'<?php echo base_url("Portfolio_convention/edit_portfolio");?>',
			data:{company_id : row_id},
			success:function(response) {
			    
			     var jdata  =  JSON.parse(response);
			   
                 $("#edit_id").val(jdata['company_id']);
			     $("#company_name").val(jdata['company_name']);
			     $("#date_signature").val(jdata['date_signature']);
			     $("#interest_tax").val(jdata['interest_tax']);
			     $("#fraise_de_dossier_ht").val(jdata['fraise_de_dossier_ht']);
			     $("#assurance_calculate").val(jdata['assurance_calculate']);
			     $("#status").val(jdata['status']);

			}
		});
	}


	function delete_group(id)
	{

	
		if(confirm("Are you sure you want to delete this Record?")){		
	  
			$.ajax({ 
				type: "POST", 
				url: '<?php echo base_url();?>Groups/delete_group',
				data:	{id:id},
				cache: false,
				success: function(resp) {
					if(resp){
					location.reload();
				}else{
					alert('Sorry we can`t deleted right now.');
				}
						
					}
			});
		}

		
	}

	$("#groupForm").validate({
		errorClass: 'has-error',
		rules: {				
			 company_name: {
	            required: true,	
	            minlength: 3,
	            maxlength: 255,
	         }
		},
		messages: {
			company_name: {
				required: "Please enter Company name ",
			},
			date_signature: {
				required: "Please enter Date Signature name ",
			},
			interest_tax: {
				required: "Please enter Tax Interest name ",
			},
			fraise_de_dossier_ht: {
				required: "Please enter Frais de dossier name ",
			}
		},
		submitHandler: function(form) {			
            $.ajax({
                url: '<?php echo base_url("Portfolio_convention/save_portfolio");?>',
                type: 'POST',
                data: $(form).serialize(),
                beforeSend: function(){
                	$('.submitBtn').attr("disabled","disabled");
                	$('#groupForm').css("opacity","0.5");
            	},
                success: function(response) {
                	//alert(response);

                	// return false;
                	$('.flash-msg').html('').removeClass('alert alert-danger fade in');  
                	if(response=='success'){                		             		
                		$('.flash-msg').html('<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><i class="fa fa-check-circle fa-fw fa-lg"></i><strong>Done. </strong> Group Saved Successfully').addClass('alert alert-success fade in').fadeOut(3000);  
                		setTimeout(function(){                  		
                			location.reload();
                		 }, 1500); 

                	}
                	else if(response =='already_exists')
                	{
                		$('.flash-msg').html('<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><i class="fa fa-check-circle fa-fw fa-lg"></i><strong>Done. </strong> This Group Already Exists..').addClass('alert alert-danger fade in').fadeOut(5000); 
                		setTimeout(function(){                  		
                			location.reload();
                		 }, 1500);  
                		
                	}
                	else{
                		$('.flash-msg').html(response).addClass('alert alert-danger fade in');                	
                    
               		}
                }            
            });
          }
	});

	
	
</script>

<script>
	$(document).ready(function() {
		var table = $('#table-example').dataTable({
			'info': false,
			'sDom': 'lTfr<"clearfix">tip',
			'oTableTools': {
	            'aButtons': [
	                {
	                    'sExtends':    'collection',
	                    'sButtonText': '<i class="fa fa-cloud-download"></i>&nbsp;&nbsp;&nbsp;<i class="fa fa-caret-down"></i>',
	                    'aButtons':    [ 'csv', 'xls', 'pdf', 'copy', 'print' ]
	                }
	            ]
	        }
		});
		
	    var tt = new $.fn.dataTable.TableTools( table );
		$( tt.fnContainer() ).insertBefore('div.dataTables_wrapper');
		
		var tableFixed = $('#table-example-fixed').dataTable({
			'info': false,
			'pageLength': 50
		});
		
		new $.fn.dataTable.FixedHeader( tableFixed );
	});
	</script>

</body>
</html>