	<head>

		<!-- STYLE CSS -->

		<link href="<?php  echo base_url('assets/volgh/assets/css/style.css');?>" rel="stylesheet"/>

		<!--C3.JS CHARTS PLUGIN -->

		<link href="<?php echo base_url('assets/volgh/assets/plugins/charts-c3/c3-chart.css');?>" rel="stylesheet"/>

		<!--PERFECT SCROLL CSS-->

		<link href="<?php echo base_url('assets/volgh/assets/plugins/p-scroll/perfect-scrollbar.css');?>" rel="stylesheet"/>

		<!--- FONT-ICONS CSS -->

		<link href="<?php echo base_url('assets/volgh/assets/css/icons.css');?>" rel="stylesheet"/>

		<!-- COLOR SKIN CSS -->

		<link id="theme" rel="stylesheet" type="text/css" media="all" href="<?php echo base_url('assets/volgh/assets/colors/color1.css');?>" />
	</head>

<style>



.container {

    max-width: 1920px !important;
}

.navbar>.container {

    display: block;

}

element.style {

}

.navbar>.container, .navbar>.container-fluid {

    display: -ms-flexbox;

    /* display: flex; */

    -ms-flex-wrap: wrap;

    /* flex-wrap: wrap; */

    -ms-flex-align: center;

    /* align-items: center; */

    -ms-flex-pack: justify;

    /* justify-content: space-between; */

}

.navbar>.container, .navbar>.container-fluid {

    display: -ms-flexbox;

    /* display: flex;*/

    }



html, body {

    font-family: 'Open Sans',sans-serif;

    -webkit-font-smoothing: antialiased;

    overflow-x: hidden;

}

body {

    font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;

    font-size: 14px;

    line-height: 1.42857143;

    color: #333;

    background-color: #fff;

}



* {

    -webkit-box-sizing: border-box;

    -moz-box-sizing: border-box;

    box-sizing: border-box;

}

user agent stylesheet

body {

    display: block;

    margin: 8px;

}

html {

    font-size: 10px;

    -webkit-tap-highlight-color: rgba(0,0,0,0);

}

html {

    font-family: sans-serif;

    -webkit-text-size-adjust: 100%;

    -ms-text-size-adjust: 100%;

}

:after, :before {

    -webkit-box-sizing: border-box;

    -moz-box-sizing: border-box;

    box-sizing: border-box;

}

:after, :before {

    -webkit-box-sizing: border-box;

    -moz-box-sizing: border-box;

    box-sizing: border-box;

    

}

::-webkit-scrollbar {

    width: 5px !important;

    background-color: #005a93 !important;

    height: 5px !important;

}

::-webkit-scrollbar-thumb {

    background-color: #005a93;

}

::-webkit-scrollbar-track {

    webkit-box-shadow: inset 0 0 5px rgba(0,0,0,0.3) !important;

    background-color: #efefef;

}

body {

    margin: 0;

}

@media screen and (min-width: 1920px){

	.container{

		max-width: 100% !important;

	}

}



h6, .h6 {

    font-size: 13px;

}

.card-header .card-title {

    

    font-size: 13px;

}

</style>

<div id="content-wrapper" style="width: 100%;max-width: 100% !important">

	<div class="row">

		<div class="col-lg-12">



			<div id="content-header" class="clearfix">

				<div class="pull-left">

					<ol class="breadcrumb">

						<li><a href="<?php echo base_url('Dashboard');?>">TABLEAU DE BORD</a></li>

						<li class="active"><span>Tableau Performance </span></li>

					</ol>

				</div>



			</div>

			<div class="main-box-body clearfix">

            		<div class="row" style="margin-top:10px;">					

					<div class="col-lg-12">

					<div class="page">

			<div class="page-main">



                <!--app-content open-->

				<div class="container app-content">

					<div class="">



						<!-- PAGE-HEADER -->

						<div class="page-header">

							<div>

								<h1 class="page-title">Indicateurs de Performance</h1>

								

							</div>

							

						</div>



						<div class="page-header">

							<div class="panel panel-primary">

											<div class=" tab-menu-heading">

												<div class="tabs-menu1 ">

													<!-- Tabs -->

													<ul class="nav panel-tabs">
													    
													    
                                                            <?php //echo "<pre>";print_r($all_time_active); ?>
														<li ><a href="#tab4" class="active" data-toggle="tab" id="tab_4"><?php echo $active_loan;?></a></li>
														
														<?php if (($all_time_active[4]['loan_id']=='5') && ($all_time_active[4]['active_loan']=='0')){ ?>
														<li><a href="#tab5" data-toggle="tab" id="tab_5">Credit Express</a></li>
														<?php }
														
														if (($all_time_active[5]['loan_id']=='6') && ($all_time_active[5]['active_loan']=='0')){?>
														<li><a href="#tab6" data-toggle="tab" id="tab_6">Credit Sans Guarantie</a></li>
														<?php }
														
														if (($all_time_active[6]['loan_id']=='7') && ($all_time_active[6]['active_loan']=='0')){?>
														<li><a href="#tab7" data-toggle="tab" id="tab_7">Crédit Privé RG</a></li>
														<?php }
														
														if (($all_time_active[7]['loan_id']=='8') && ($all_time_active[7]['active_loan']=='0')){?>
														<li><a href="#tab8" data-toggle="tab" id="tab_8">Crédit Privé avec Gage Espece</a></li>
														<?php }
														
														if (($all_time_active[8]['loan_id']=='9') && ($all_time_active[8]['active_loan']=='0')){?>
														<li><a href="#tab9" data-toggle="tab" id="tab_9">Crédit Privé avec Caution</a></li>
														<?php }
														 if (($all_time_active[9]['loan_id']=='10') && ($all_time_active[9]['active_loan']=='0')){?>
														<li><a href="#tab10" data-toggle="tab" id="tab_10">Crédit Conventionnes</a></li> 
														<?php }
														if (($all_time_active[10]['loan_id']=='11') && ($all_time_active[10]['active_loan']=='0')){?>
														<li><a href="#tab11" data-toggle="tab" id="tab_11">Onero Secteur Prive</a></li>
														<?php } if (($all_time_active[11]['loan_id']=='12') && ($all_time_active[11]['active_loan']=='0')){?>
														<li><a href="#tab12" data-toggle="tab" id="tab_12">Onero Retraite BICIG</a></li>
														<?php } ?>
													    <?php if (($all_time_active[13]['loan_id']=='14') && ($all_time_active[13]['active_loan']=='0')){?>
														<li><a href="#tab14" data-toggle="tab" id="tab_14">Crédit Dérogatoire</a></li>
														
													    <?php } if (($all_time_active[12]['loan_id']=='13') && ($all_time_active[12]['active_loan']=='0')){	?>
													    <li><a href="#tab13" data-toggle="tab" id="tab_13">Onero Sans Garantie</a></li>
														<?php } if (($all_time_active[14]['loan_id']=='15') && ($all_time_active[14]['active_loan']=='0')){	?>
														<li><a href="#tab15" data-toggle="tab" id="tab_15">Crédit aux Personnel</a></li>
														<?php } ?>

													</ul>

												</div>

											</div>

											<div class="panel-body tabs-menu-body">

												<div class="tab-content">

													<div class="tab-pane active " id="tab4">
															  <img src="<?php echo  base_url('assets/img/select2-spinner.gif');?>" class="spinloader" style="position:relative;left: 50%; display: none;">
													</div>

													<div class="tab-pane active " id="tab5">
															  <img src="<?php echo  base_url('assets/img/select2-spinner.gif');?>" class="spinloader" style="position:relative;left: 50%; display: none;">
													</div>


													<div class="tab-pane active " id="tab6">
															  <img src="<?php echo  base_url('assets/img/select2-spinner.gif');?>" class="spinloader" style="position:relative;left: 50%; display: none;">
													</div>
													
													<div class="tab-pane active " id="tab7">
															  <img src="<?php echo  base_url('assets/img/select2-spinner.gif');?>" class="spinloader" style="position:relative;left: 50%; display: none;">
													</div>

													<div class="tab-pane active " id="tab8">
															  <img src="<?php echo  base_url('assets/img/select2-spinner.gif');?>" class="spinloader" style="position:relative;left: 50%; display: none;">
													</div>

                                                    <div class="tab-pane active " id="tab9">
															  <img src="<?php echo  base_url('assets/img/select2-spinner.gif');?>" class="spinloader" style="position:relative;left: 50%; display: none;">
													</div>

													<div class="tab-pane active " id="tab10">
															  <img src="<?php echo  base_url('assets/img/select2-spinner.gif');?>" class="spinloader" style="position:relative;left: 50%; display: none;">
													</div>
													
													<div class="tab-pane active " id="tab11">
															  <img src="<?php echo  base_url('assets/img/select2-spinner.gif');?>" class="spinloader" style="position:relative;left: 50%; display: none;">
													</div>
													<div class="tab-pane active " id="tab12">
															  <img src="<?php echo  base_url('assets/img/select2-spinner.gif');?>" class="spinloader" style="position:relative;left: 50%; display: none;">
													</div>
													
													<div class="tab-pane active " id="tab13">
															  <img src="<?php echo  base_url('assets/img/select2-spinner.gif');?>" class="spinloader" style="position:relative;left: 50%; display: none;">
													</div>
													
													<div class="tab-pane active " id="tab14">
															  <img src="<?php echo  base_url('assets/img/select2-spinner.gif');?>" class="spinloader" style="position:relative;left: 50%; display: none;">
													</div>

													<div class="tab-pane active" id="tab15">
															  <img src="<?php echo  base_url('assets/img/select2-spinner.gif');?>" class="spinloader" style="position:relative;left: 50%; display: none;">
													</div>

												</div>

											</div>

										</div>

							

						</div>

						<!-- PAGE-HEADER END -->



						<!-- ROW-1 -->

						

						<!-- ROW-1 END -->





					</div>

				</div>

				<!-- CONTAINER END -->

            </div>





		</div>

					</div>

				</div>

			</div>			

		</div>

	</div>

	

</div>





</div>

</div>

</div>

<!-- JQUERY JS -->

<script src="<?php echo base_url('assets/volgh/assets/js/jquery-3.4.1.min.js');?>"></script>

<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

 

<script src="<?php echo  base_url(); ?>assets/js/demo-skin-changer.js"></script>  

<script src="<?php echo  base_url(); ?>assets/js/jquery.js"></script>

<script src="<?php echo  base_url(); ?>assets/js/bootstrap.js"></script>

<script src="<?php echo  base_url(); ?>assets/js/jquery.nanoscroller.min.js"></script>

<script src="<?php echo  base_url(); ?>assets/js/demo.js"></script>  

<script src="<?php echo  base_url(); ?>assets/js/jquery.scrollTo.min.js"></script>

<script src="<?php echo  base_url(); ?>assets/js/jquery.slimscroll.min.js"></script>

<script src="<?php echo  base_url(); ?>assets/js/moment.min.js"></script>



<script src="<?php echo  base_url(); ?>assets/js/raphael-min.js"></script>

<script src="<?php echo  base_url(); ?>assets/js/morris.js"></script>

<script src="<?php echo  base_url(); ?>assets/js/scripts.js"></script>

<script src="<?php echo  base_url(); ?>assets/js/pace.min.js"></script>

<script src="<?php echo  base_url(); ?>assets/js/bootstrap-wizard.js"></script>





<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>

<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>

<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />



<script src="<?php echo  base_url(); ?>assets/js/jquery.dataTables.js"></script>

<script src="<?php echo  base_url(); ?>assets/js/dataTables.fixedHeader.js"></script>

<script src="<?php echo  base_url(); ?>assets/js/dataTables.tableTools.js"></script>

<script src="<?php echo  base_url(); ?>assets/js/jquery.dataTables.bootstrap.js"></script>

 

<script src="<?php echo base_url();?>assets/js/modernizr.custom.js"></script> 

<script src="<?php echo base_url();?>assets/js/notificationFx.js"></script> 

<script src="<?php echo  base_url(); ?>assets/js/classie.js"></script>

<script src="<?php echo  base_url(); ?>assets/js/xlsx.full.min.js"></script>

  





<!-- BOOTSTRAP JS -->

<!-- <script src="<?php echo base_url('assets/volgh/assets/plugins/bootstrap/js/bootstrap.bundle.min.js');?>"></script> -->

<script src="<?php echo base_url('assets/volgh/assets/plugins/bootstrap/js/popper.min.js');?>"></script>

<!-- SPARKLINE JS-->

<script src="<?php echo base_url('assets/volgh/assets/js/jquery.sparkline.min.js');?>"></script>

<!-- ECHART JS-->

<script src="<?php echo base_url('assets/volgh/assets/plugins/echarts/echarts.js');?>"></script>

<!-- SIDEBAR JS -->

<script src="<?php echo base_url('assets/volgh/assets//plugins/sidebar/sidebar.js');?>"></script>

<!-- INDEX JS -->

<script src="<?php echo base_url('assets/volgh/assets/js/index1.js');?>"></script>

<!-- CUSTOM JS -->

<script src="<?php echo base_url('assets/volgh/assets/js/custom.js');?>"></script>

<style type="text/css">

	.app-content div .page-header .panel{

		max-width: 100% !important;

		width: 100% !important;

	}

</style>

<style type="text/css">

	#sidebar-nav[aria-expanded="true"]{

		height: 100% !important;

		display: block !important;

	}

	@media screen and (max-width: 991px){

		#nav-col{

			width: 100% !important;

		}

	}

</style>

<script>


	$(document).ready(function(){
		$("#tab_4").click();
	})

	$("#tab_4").click(function(){
		$.ajax({

			  type: "POST", 

				url:'<?php echo base_url("Inside_data_dashboard/dashboard_data/credit_scolair");?>', 

				cache: false,

				beforeSend: function(){

					$(".spinloader").show();

				},

				success: function(resp){
					$(".spinloader").show();
					//$(".spinloader").hide();

					setTimeout(function(){
					$(".tab-pane").html('');

					//$("#sel_echart2").load(window.location.href + " #sel_echart2");
				    $("#tab4").html(resp);

				     },1000);

				}

		});
	});


	$("#tab_5").click(function(){
		$.ajax({

			  type: "POST", 

				url:'<?php echo base_url("Inside_data_dashboard/dashboard_data/credit_express");?>',

				cache: false,

				beforeSend: function(){

					$(".spinloader").show();

				},

				success: function(resp){
					$(".spinloader").show();

					setTimeout(function(){
					$(".tab-pane").html('');

					//$("#sel_echart2").load(window.location.href + " #sel_echart2");
				    $("#tab5").html(resp);

				     },1000);

				}

		});
	});

	$("#tab_6").click(function(){
		$.ajax({

			  type: "POST", 

				url:'<?php echo base_url("Inside_data_dashboard/dashboard_data/credit_sans_garantie");?>',

				cache: false,

				beforeSend: function(){

					$(".spinloader").show();

				},

				success: function(resp){
					$(".spinloader").show();

					setTimeout(function(){
						$(".tab-pane").html('');
					    $("#tab6").html(resp);
					},1000);

				}

		});
	});

	$("#tab_8").click(function(){
		$.ajax({

			  type: "POST", 

				url:'<?php echo base_url("Inside_data_dashboard/dashboard_data/credit_prive_gage_espece");?>',

				cache: false,

				beforeSend: function(){

					$(".spinloader").show();

				},

				success: function(resp){
					$(".spinloader").show();

					setTimeout(function(){
						$(".tab-pane").html('');
					    $("#tab8").html(resp);
					},1000);

				}

		});
	});
	
		$("#tab_7").click(function(){
		$.ajax({

			  type: "POST", 

				url:'<?php echo base_url("Inside_data_dashboard/dashboard_data/credit_prive");?>',

				cache: false,

				beforeSend: function(){

					$(".spinloader").show();

				},

				success: function(resp){
					$(".spinloader").show();

					setTimeout(function(){
						$(".tab-pane").html('');
					    $("#tab7").html(resp);
					},1000);

				}

		});
	});

    $("#tab_9").click(function(){
		$.ajax({

			  type: "POST", 

				url:'<?php echo base_url("Inside_data_dashboard/dashboard_data/credit_prive_avec_caution");?>',

				cache: false,
 
				beforeSend: function(){

					$(".spinloader").show();

				},

				success: function(resp){
					$(".spinloader").show();

					setTimeout(function(){
						$(".tab-pane").html('');
					    $("#tab9").html(resp);
					},1000);

				}

		});
	});
	$("#tab_10").click(function(){
		$.ajax({

			  type: "POST", 

				url:'<?php echo base_url("Inside_data_dashboard/dashboard_data/credit_conventionnes");?>',

				cache: false,
 
				beforeSend: function(){

					$(".spinloader").show();

				},

				success: function(resp){
					$(".spinloader").show();

					setTimeout(function(){
						$(".tab-pane").html('');
					    $("#tab10").html(resp);
					},1000);

				}

		});
	});
	
		$("#tab_11").click(function(){
		$.ajax({

			  type: "POST", 

				url:'<?php echo base_url("Inside_data_dashboard/dashboard_data/onero_secteur");?>',

				cache: false,
 
				beforeSend: function(){

					$(".spinloader").show();

				},

				success: function(resp){
					$(".spinloader").show();

					setTimeout(function(){
						$(".tab-pane").html('');
					    $("#tab11").html(resp);
					},1000);

				}

		});
	});
	$("#tab_12").click(function(){
		$.ajax({

			  type: "POST", 

				url:'<?php echo base_url("Inside_data_dashboard/dashboard_data/onero_retraite");?>',

				cache: false,
 
				beforeSend: function(){

					$(".spinloader").show();

				},
                success: function(resp){
					$(".spinloader").show();

					setTimeout(function(){
						$(".tab-pane").html('');
					    $("#tab15").html(resp);
					},1000);

				}

		});
	});
	
		$("#tab_13").click(function(){
		$.ajax({

			  type: "POST", 

				url:'<?php echo base_url("Inside_data_dashboard/dashboard_data/onero_sans_garantie");?>',

				cache: false,
 
				beforeSend: function(){

					$(".spinloader").show();

				},

				success: function(resp){
					$(".spinloader").show();

					setTimeout(function(){
						$(".tab-pane").html('');
					    $("#tab13").html(resp);
					},1000);

				}

		});
	});
	
	$("#tab_14").click(function(){
		$.ajax({

			  type: "POST", 

				url:'<?php echo base_url("Inside_data_dashboard/dashboard_data/credit_dero");?>',

				cache: false,
 
				beforeSend: function(){

					$(".spinloader").show();

				},

				success: function(resp){
					$(".spinloader").show();

					setTimeout(function(){
						$(".tab-pane").html('');
					    $("#tab14").html(resp);
					},1000);

				}

		});
	});
	
	$("#tab_15").click(function(){
		$.ajax({

			  type: "POST", 

				url:'<?php echo base_url("Inside_data_dashboard/dashboard_data/credit_aux");?>',

				cache: false,
 
				beforeSend: function(){

					$(".spinloader").show();

				},
                success: function(resp){
					$(".spinloader").show();

					setTimeout(function(){
						$(".tab-pane").html('');
					    $("#tab15").html(resp);
					},1000);

				}

		});
	});
	// ('.navbar-toggle').click(function(){

	// 	if($('#sidebar-nav').hasClass('d-none')){

	// 		alert('asd');

	// 		$('#sidebar-nav').removeClass('d-none');

	// 	}else{

	// 		alert('1122');



	// 		$('#sidebar-nav').addClass('d-none');

	// 		$('#sidebar-nav').addClass('h-100');

	// 	}

	// });

	$(document).on('click', '.tabs-menu1 ul li' ,function(e){

		e.preventDefault();

		$('.tabs-menu1 ul li').removeClass('active');

		$('.tabs-menu1 ul li a').removeClass('active');

		$(this).addClass('active');

		$(this).find('a').addClass('active');

	});





</script>



</body>

</html>