<style type="text/css">
	.hidden { display: none; }

	.lodertypeof {    
    background-color: #dff0d8c7;
    background-image: url("<?php echo base_url('assets/img/select2-spinner.gif');?>");
    background-size: 18px 18px;
    background-position:right center;
    background-repeat: no-repeat;
    opacity: 0.5;
    }
</style>
<div id="content-wrapper">
	<div class="row">
		<div class="col-lg-12">

			<div id="content-header" class="clearfix">
				<div class="pull-left">
					<ol class="breadcrumb">
						<li><a href="<?php echo base_url('Dashboard');?>">TABLEAU DE BORD</a></li>
						<li class="active"><span>Productivité By Client Agence Bancaire</span></li>
					</ol>
				</div>

			</div>
			<div class="main-box-body clearfix">
            		<div class="row" style="margin-top:10px;">					
					<div class="col-lg-12">
						
						
						<div class="main-box clearfix">

							<header class="main-box-header clearfix">								
								<div class="form-group">
									<form id="" action="<?php echo base_url('Inside_data/client_bancaire')?>" method="POST">

                                        <div class="row" style="margin-top:2%">
                                            
                                            <div class="col-md-4">

    											<label class="col-md-4 control-label">Productivité:</label>
    											
    											<div class="col-md-8">
    												<select class="form-control" name="loan_type">
    													<option value="">Select</option>
    												    <option value="credit_conso">Fêtes à la Carte</option>
    												    <option value="credit_scolair">Congés à la Carte</option>
    												    <option value="credit_confort">Crédit Confort</option>
    												    <option value="pp_scolair">Crédit Scolaire</option>
    												</select>
    			
    											</div>
											
											</div>
											
											<div class="col-md-4">
										    	<label class="col-md-4 control-label">DATE:</label>

    											<div class="col-md-8">
    												<input type="text" class="form-control" name="daterange" value="" />
    			
    											</div>
											</div>
											
											<div class="col-md-4">
										    	<button  type ="submit" class="btn btn-primary">Sélectionner</button> &nbsp;
										        <button id="btnExport"  type="button" class="btn btn-primary" onclick="fnExcelReport('xlsx');"> Exporter </button>&nbsp;
										        <button id="btnPdf" type="button" class="btn btn-primary" onclick="generatePDF();"> PDF </button>
											</div>
										</div>
										
										
										
									</form>
									<h4 class="pull-left"><?php echo $date_title;?></h4>
								</div>	
							</header>

							<div class="main-box-body clearfix">
								<div class="row">
								    
								      <?php if($_POST) {?>
								      
								      
								      
                                    <div class="col-md-7">
                                        <h5>Productivite <?php echo $loan_type;?> <?php if($_POST['daterange']) echo 'Date '.$_POST['daterange'].' by Agence';?></h5>
								        <div class="table-responsive">
									<table  id="table-example" class="table table-hover table-striped">
										<thead>
											<tr style="background: #cccccc54;">
											
												<th>Agence</th>
												<th>Number of Loans</th>
												<th>Total Loan Amount</th>
											    <th>Total Medium Loan</th>
												<th>Total Numbers of Placeur</th>
												<th>Average number of Loan by Placeur</th>
											</tr>
											
										</thead>
										<tbody id="getrecord">
										
											<?php 
											    $lc = 0; $ta = 0;$tm = 0;$acc = 0;$avg= 0;
											foreach($details as $key=>$row){
											
												?>

												<tr>
												   
													<td><?php echo trim($row['bank_name'],'"'); ?></td>
													<td><?php echo $row['loan_count'];
													    $lc += $row['loan_count'];
													?></td>
													<td><?php echo $row['total_amount'];
													   
													?></td>
													<td><?php echo $row['total_medium'];
													  
													?></td>
													<td><?php echo $row['account_mgr'];
													    $acc += $row['account_mgr'];
													?></td>
													<td><?php echo $row['average_loan_count'];
													    $avg += $row['average_loan_count'];
													?></td>
												
												</tr>
											   <?php }?>
										</tbody>
										<tfoot>
											<tr>
												<td><span style="font-weight: 700">Total</span></td>
												<td><?php echo $lc; ?></td>
												<td><?php echo number_format($loan_amount,2); ?></td>
											    <td><?php echo number_format($total_medium,2); ?></span></td>
												<td><?php echo $acc; ?></span></td>
												<td><?php echo $avg; ?></td>
											</tr>
										</tfoot>
									</table>
								
								</div>
                                    </div>
                                    <div class="col-md-5">
                                        
                                      
                                        <figure class="highcharts-figure">
                                		    <div id="container"></div>
                                		    <p class="highcharts-description">
                                		       
                                		    </p>
                                		</figure>
                                		
                                	
                                    </div>
                                    
                                    	<?php } ?>

                                </div>
							</div>
						</div>
					</div>
				</div>
			</div>			
		</div>
	</div>
	
</div>
</div>
</div>
</div>

 
<script src="<?php echo  base_url(); ?>assets/js/demo-skin-changer.js"></script>  
<script src="<?php echo  base_url(); ?>assets/js/jquery.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/bootstrap.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/jquery.nanoscroller.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/demo.js"></script>  
<script src="<?php echo  base_url(); ?>assets/js/jquery.scrollTo.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/jquery.slimscroll.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/moment.min.js"></script>
<!-- 
<script src="<?php echo  base_url(); ?>assets/js/jquery-jvectormap-1.2.2.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/jquery-jvectormap-world-merc-en.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/gdp-data.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/flot/jquery.flot.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/flot/jquery.flot.resize.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/flot/jquery.flot.time.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/flot/jquery.flot.threshold.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/flot/jquery.flot.axislabels.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/jquery.sparkline.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/skycons.js"></script> -->

<script src="<?php echo  base_url(); ?>assets/js/raphael-min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/morris.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/scripts.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/pace.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/bootstrap-wizard.js"></script>

<!-- <script src="<?php echo  base_url(); ?>assets/js/select2.min.js"></script>
<script src="<?php echo base_url('assets/js/jquery.validate.min.js');?>"></script> 
<script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script> -->


<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />

<script src="<?php echo  base_url(); ?>assets/js/jquery.dataTables.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/dataTables.fixedHeader.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/dataTables.tableTools.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/jquery.dataTables.bootstrap.js"></script>
 
<script src="<?php echo base_url();?>assets/js/modernizr.custom.js"></script> 
<script src="<?php echo base_url();?>assets/js/notificationFx.js"></script> 
<script src="<?php echo  base_url(); ?>assets/js/classie.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/xlsx.full.min.js"></script>
  
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.min.js"></script>  
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.6/jspdf.plugin.autotable.min.js"></script>  

<script type="text/javascript">
	$('input[name="daterange"]').daterangepicker({
		locale: {
	      format: 'YYYY/M/DD'
	    }
	});
	

function generatePDF() {
    
     var doc = new jsPDF('p', 'pt', 'letter');  
    var htmlstring = '';  
    var tempVarToCheckPageHeight = 0;  
    var pageHeight = 0;  
    pageHeight = doc.internal.pageSize.height;  
    specialElementHandlers = {  
        // element with id of "bypass" - jQuery style selector  
        '#bypassme': function(element, renderer) {  
            // true = "handled elsewhere, bypass text extraction"  
            return true  
        }  
    };  
    margins = {  
        top: 150,  
        bottom: 60,  
        left: 40,  
        right: 40,  
        width: 600  
    };  
    var y = 20;  
    doc.setLineWidth(2);  
    doc.text(200, y = y + 30, "Productivité By Client Agence Bancaire");  
    doc.autoTable({  
        html: '#table-example',  
        startY: 70,  
        theme: 'grid',  
        // columnStyles: {  
        //     0: {  
        //         cellWidth: 180,  
        //     },  
        //     1: {  
        //         cellWidth: 180,  
        //     },  
        //     2: {  
        //         cellWidth: 180,  
        //     }  
        // },  
        // styles: {  
        //     minCellHeight: 40  
        // }  
    })  
    doc.save('Productivite_By_Client_Agence_Bancaire.pdf');  


//  var doc = new jsPDF();
//   doc.fromHTML(document.getElementById("table-example"), // page element which you want to print as PDF
//   15,
//   15, 
//   {
//     'width': 170
//   },
//   function(a) 
//   {
//     doc.save("HTML2PDF.pdf");
//   });
}

Highcharts.setOptions({
    colors: Highcharts.map(Highcharts.getOptions().colors, function (color) {
        return {
            radialGradient: {
                cx: 0.5,
                cy: 0.3,
                r: 0.7
            },
            stops: [
                [0, color],
                [1, Highcharts.color(color).brighten(-0.3).get('rgb')] // darken
            ]
        };
    })
});


Highcharts.chart('container', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'Status Overview'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.y}</b>'
    },
    accessibility: {
        point: {
            valueSuffix: '%'
        }
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.y}',
                connectorColor: 'silver'
            }
        }
    },
    series: [{
        name: 'Count',
        data:<?php echo $pie_data; ?>
    }]
});


$( document ).ready(function() {
$(".highcharts-credits").css('display','none');
});

	


	

	// show popup notification 

   function notificationcall(data, status)
  {
      var notification = new NotificationFx({
          message : data,
          layout : 'bar',
          effect : 'slidetop',
          type : status          
        });
          notification.show();
          this.disabled = true;
  }
</script>

<script>
function fnExcelReport(type, fn, dl)
{
      var elt = document.getElementById('table-example');
    var wb = XLSX.utils.table_to_book(elt, { sheet: "Sheet JS" });
    return dl ?
        XLSX.write(wb, { bookType: type, bookSST: true, type: 'base64' }) :
        XLSX.writeFile(wb, fn || ('Productivite_By_Client_Agence_Bancaire.' + (type || 'xlsx')));

}
$(window).load(function(){
    // alert('table');
		var table = $('#table-example1').dataTable({
			'info': false,
			'sDom': 'lTfr<"clearfix">tip',
			"oLanguage": {
			  "sSearch": "<span>RECHERCHER:</span> _INPUT_", //search
			 // "sLengthMenu": "AFFICHAGE _MENU_ ENREGISTREMENTS",
			}
		});		
		
	    var tt = new $.fn.dataTable.TableTools( table );
		$( tt.fnContainer() ).insertBefore('div.dataTables_wrapper');		
		var tableFixed = $('#table-example-fixed').dataTable({
			'info': false,
			'pageLength': 50
		});	
});

	$('#loan_schedule').change(function() {	    
	    var $option = $(this).find('option:selected');	    
	    var value = $option.val();//to get content of "value" attrib
	    var text = $option.text();//to get <option>Text</option> content
	    $('.addsch').html(text);

	});
	</script>

</body>
</html>