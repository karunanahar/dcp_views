
														<div class="row">

							<div class="col-lg-12 col-md-12 col-sm-12 col-xl-6">

								<div class="row">

									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">

										<div class="card">

											<div class="card-body text-center statistics-info">

												<div class="counter-icon bg-primary mb-0 box-primary-shadow">

													<i class="fe fe-trending-up text-white"></i>

												</div>

												<h6 class="mt-4 mb-1" >Nombre total de prêts décaissés</h6>

												<h2 class="mb-2 number-font"><?php echo  number_format($selected_loan['disbursed_loannumber'],0,',',',') ; ?></h2>

													<!--<div class="card-body ">-->

											

													<!--<div class="progress progress-sm mt-0 mb-2">-->

													<!--	<div class="progress-bar bg-success w-50" role="progressbar"></div>-->

													<!--</div>-->

													<!--	<div class=""><i class="fa fa-caret-down text-danger"></i>5% decrease</div>-->

													<!--</div>-->

											

											</div>

										</div>

									</div>

									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">

										<div class="card">

											<div class="card-body text-center statistics-info">

												<div class="counter-icon bg-secondary mb-0 box-secondary-shadow">

													<i class="fe fe-codepen text-white"></i>

												</div>

												<h6 class="mt-4 mb-1" >Montant total des prêts décaissés</h6>

												<h2 class="mb-2 number-font"><?php echo number_format($selected_loan['disbursed_loanamount'],0,',',',') ; ?></h2>

												<!--<div class="card-body ">-->

												

												<!--	<div class="progress progress-sm mt-0 mb-2">-->

												<!--		<div class="progress-bar bg-success w-50" role="progressbar"></div>-->

												<!--	</div>-->

												<!--		<div class=""><i class="fa fa-caret-down text-danger"></i>5% decrease</div>-->

												<!--	</div>-->

											</div>

										</div>

									</div>

									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">

										<div class="card">

											<div class="card-body text-center statistics-info">

												<div class="counter-icon bg-success mb-0 box-success-shadow">

													<i class="fe fe-dollar-sign text-white"></i>

												</div>

												<h6 class="mt-4 mb-1" >Nombre total de prêts actifs</h6>

												<h2 class="mb-2  number-font"><?php echo number_format($selected_loan['active_loannumber'],0,',',',') ; ?></h2>

												

											</div>

										</div>

									</div>

									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">

										<div class="card">

											<div class="card-body text-center statistics-info">

												<div class="counter-icon bg-info mb-0 box-info-shadow">

													<i class="fe fe-briefcase text-white"></i>

												</div>

												<h6 class="mt-4 mb-1" > Montant total des prêts actifs</h6>

												<h2 class="mb-2  number-font"><?php echo number_format($selected_loan['active_loanamount'],0,',',','); ?></h2>

												

											</div>

										</div>

									</div>

								</div>

							</div>

							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-6">

								<div class="card">

									<div class="card-header">

										<h3 class="card-title">Tendances des prêts</h3>

									</div>

									<div class="card-body">

										<div id="sel_echart2" class="chart-donut chart-dropshadow"></div>

										<!--<div class="mt-4">-->

										<!--	<span class="ml-5"><span class="dot-label bg-info mr-2"></span>Actives</span>-->

										<!--	<span class="ml-5"><span class="dot-label bg-secondary mr-2"></span>Approved</span>-->

										<!--	<span class="ml-5"><span class="dot-label bg-success mr-2"></span>In Process</span>-->

										<!--	<span class="ml-5"><span class="dot-label bg-danger mr-1"></span>Annule/Abondon</span>-->

										<!--</div>-->

									</div>

								</div>

							</div><!-- COL END -->

						</div>



						                                <div class="row">

							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">

								<div class="card">

									<div class="card-body text-center">

										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>

										<h6 class="mt-4 mb-2">Montant moyen de la demande de prêt</h6>

										<h2 class="mb-2  number-font"><?php 

										    if($selected_loan['active_loannumber']){

										    $avg=  ($selected_loan['active_loanamount'] / $selected_loan['active_loannumber']);

										    }else{

										      $avg=0;  

										    }

										    echo number_format($avg,0,',',',');

										?></h2>

										<p class="text-muted"></p>

									</div>

								</div>

							</div><!-- COL END -->



							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">

								<div class="card">

									<div class="card-body text-center">

										<i class="fa fa-globe text-primary fa-3x text-primary-shadow"></i>

										<h6 class="mt-4 mb-2">Moyen Nbre de Jours déboursement</h6>

										<h2 class="mb-2 number-font"><?php if(round($selected_loan['average_loan_disposition']) == 0){

										echo "1";}else{

										    echo round($selected_loan['average_loan_disposition']);

										} ?></h2>

										<p class="text-muted"></p>

									</div>

								</div>

							</div><!-- COL END -->

							

							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">

								<div class="card">

									<div class="card-body text-center">

										<i class="fa fa-globe text-primary fa-3x text-primary-shadow"></i>

										<h6 class="mt-4 mb-2">Productivité Efficacité</h6>

										<h2 class="mb-2 number-font"><?php 

										if($selected_loan['active_loannumber']){

										    echo  number_format((($selected_loan['disbursed_loannumber'] / $selected_loan['active_loannumber'])*100)). "%";

										    }else{

										      echo "0". "%"; 

										    }

										

										 ;?></h2>

										<p class="text-muted"></p>

									</div>

								</div>

							</div><!-- COL END -->

							<!--<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">-->

							<!--	<div class="card">-->

							<!--		<div class="card-body text-center">-->

							<!--			<i class="fa fa-globe text-secondary fa-3x text-secondary-shadow"></i>-->

							<!--			<h6 class="mt-4 mb-2">Loan Approved  V.s Tokos</h6>-->

							<!--			<h2 class="mb-2  number-font"><?php echo $selected_loan['tilllastday_loan_approved']['total_app'];?></h2>-->

							<!--			<p class="text-muted"></p>-->

							<!--		</div>-->

							<!--	</div>-->

							<!--</div>-->

							<!-- COL END -->

						</div>

                        

                                                        <div class="row">

							



							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">

								<div class="card">

									<div class="card-body text-center">

										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>

										<h6 class="mt-4 mb-2">Total des intérêts perçus</h6>

										<h2 class="mb-2 number-font"><?php echo  number_format($selected_loan['total_interest_ht_sum'],0,',',',') ; ?></h2>

										<p class="text-muted"></p>

									</div>

								</div>

							</div><!-- COL END -->



							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">

								<div class="card">

									<div class="card-body text-center">

										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>

										<h6 class="mt-4 mb-2">Total des frais de dossier collectés</h6>

										<h2 class="mb-2  number-font"><?php echo  number_format($selected_loan['frais_de_dossier_sum'],0,',',',') ; ?></h2>

										<p class="text-muted"></p>

									</div>

								</div>

							</div><!-- COL END -->

							

							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">

								<div class="card">

									<div class="card-body text-center">

										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>

										<h6 class="mt-4 mb-2"> Assurance principale totale collectée</h6>

										<h2 class="mb-2 number-font"><?php echo  number_format($selected_loan['frais_de_assurance_sum'],0,',',',') ; ?></h2>

										<p class="text-muted"></p>

									</div>

								</div>

							</div><!-- COL END -->

							

						</div>

						

						<div class="row">

							



							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">

								<div class="card">

									<div class="card-body text-center">

										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>

										<h6 class="mt-4 mb-2">Total des frais de dossier TTC collectés </h6>

										<h2 class="mb-2 number-font"><?php echo  number_format($selected_loan['frais_de_dossier_ttc_sum'],0,',',',') ; ?></h2>

										<p class="text-muted"></p>

									</div>

								</div>

							</div><!-- COL END -->



							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">

								<div class="card">

									<div class="card-body text-center">

										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>

										<h6 class="mt-4 mb-2">Total des frais d'enregistrement TTC collectés</h6>

										<h2 class="mb-2  number-font"><?php echo  number_format($selected_loan['frais_denregistrement_ttc_sum'],0,',',',') ; ?></h2>

										<p class="text-muted"></p>

									</div>

								</div>

							</div><!-- COL END -->

							

							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">

								<div class="card">

									<div class="card-body text-center">

										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>

										<h6 class="mt-4 mb-2"> Total des frais d'enregistrement HT collectés</h6>

										<h2 class="mb-2 number-font"><?php echo  number_format($selected_loan['frais_denregistrement_sum'],0,',',',') ; ?></h2>

										<p class="text-muted"></p>

									</div>

								</div>

							</div><!-- COL END -->

							

						</div>

						

                    						            <div class="row">

                    							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">

                    								<div class="card">

                    									<div class="card-header">

                    										<h3 class="card-title">Top 5 des agences par nombre de prêts</h3>

                    									</div>

                    									<div class="card-body p-4">

                    									    <?php 

                    									    

                    									    if(!empty($selected_loan['top5loan_countdetails'])){ 
                    									        
                    									        $max_count= max(array_column($selected_loan['top5loan_countdetails'], 'loancount'));

                    									        foreach($selected_loan['top5loan_countdetails'] as $tcount){

                    									    ?>

                    							        	<div class="mb-5">

                    											<p class="mb-2"><?php echo $tcount['department']?><span class="float-right text-muted"><?php echo  number_format($tcount['loancount'],0,',',',') ;?></span></p>

                    											<div class="progress  h-2">

                    												<div class="progress-bar"  style="background-color: <?php echo $tcount['color_pattern']?>;width:<?php echo ($tcount['loancount']/$max_count)*100?>%" role="progressbar"></div>

                    											</div>

                    										</div>

                    									    <?php } } ?>

                    										

                    										

                    									</div>

                    								</div>

                    							</div><!-- COL END -->

                    							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">

                    								<div class="card">

                    									<div class="card-header">

                    										<h3 class="card-title">Top 5 des agences par montant de prêt</h3>

                    									</div>

                    									<div class="card-body p-4">

                    									    

                    									    <?php 

                    									   

                    									     if(!empty($selected_loan['top5loan_amountdetails'])){ 
                    									          $max_count= max(array_column($selected_loan['top5loan_amountdetails'], 'total_amount'));

                    									        foreach($selected_loan['top5loan_amountdetails'] as $tamount){

                    									    ?>

                    							        	<div class="mb-5">

                    											<p class="mb-2"><?php echo $tamount['department']?><span class="float-right text-muted"><?php echo number_format($tamount['total_amount'],0,',',',')  ;?></span></p>

                    											<div class="progress h-2">

                    												<div class="progress-bar"  style="background-color: <?php echo $tamount['color_pattern']?>;width:<?php echo ($tamount['total_amount']/$max_count)*100?>%" role="progressbar"></div>

                    											</div>

                    										</div>

                    									    <?php } } ?>


                    									</div>

                    								</div>

                    							</div><!-- COL END -->

                    							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">

                    								<div class="card">

                    									<div class="card-header">

                    										<h3 class="card-title">Top 5 des agences avec le moins de dossiers hors délais (> 3 jours)</h3>

                    									</div>

                    									<div class="card-body p-4">

                    									    <?php 

                    									    

                    									     if(!empty($selected_loan['top5agingloan'])){
                    									         $max_count= max(array_column($selected_loan['top5agingloan'], 'totalcount'));

                    									        foreach($selected_loan['top5agingloan'] as $aging){

                    									    ?>

                    										<div class="mb-5">

                    											<p class="mb-2"><?php echo $aging['department'];?><span class="float-right text-muted"><?php echo $aging['totalcount'];?></span></p>

                    											<div class="progress h-2">

                    												<div class="progress-bar"  style="background-color: <?php echo $aging['color_pattern']?>;width:<?php echo ($aging['totalcount']/$max_count)*100?>%" role="progressbar"></div>

                    											</div>

                    										</div>

                    									    <?php } } ?>

                    										

                    									</div>

                    								</div>

                    							</div><!-- COL END -->

                    

                    						</div>

                                						<div class="row">

                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">

                                								<div class="card">

                                									<div class="card-header">

                                										<h3 class="card-title">Top 5 des agences par rapport au nombre total de prêts par OBJECTIFS</h3>

                                									</div>

                                									<div class="card-body p-4">

                                									    

                                									    <?php 

                                									    

                    									   

                    									     if(!empty($selected_loan['trendingbranch_loannumber'])) {
                    									          $max_count= max(array_column($selected_loan['trendingbranch_loannumber'], 'progress'));

                                									            $branch_loancount = 1;

                                									            foreach($selected_loan['trendingbranch_loannumber'] as $branch_loanno){

                                									                

                                									                if($branch_loanno['progress']) {

                                									    ?>

                                										<div class="mb-5">

                                											<p class="mb-2"><?php echo $branch_loanno['department']; ?><span class="float-right text-muted"><?php echo number_format($branch_loanno['progress'], 2).'%';?></span></p>

                                											<div class="progress h-2">

                                												<div class="progress-bar"  style="background-color: <?php echo $branch_loanno['color_pattern']?>;width:<?php echo ($branch_loanno['progress']/$max_count)*100?>%" role="progressbar"></div>

                                											</div>

                                										</div>

                                										

                                										<?php 

                                										

                                										    if($branch_loancount == 5){

                                										        break;

                                										    }

                                										    $branch_loancount ++;

                                									      } 

                                										}  }?>

                                									</div>

                                								</div>

                                							</div><!-- COL END -->

                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">

                                								<div class="card">

                                									<div class="card-header">

                                										<h3 class="card-title">Top 5 des agences par rapport au montant total du prêt par OBJECTIFS</h3>

                                									</div>

                                									<div class="card-body p-4">

                                									 <?php  

                    									    

                    									    if(!empty($selected_loan['trendingbranch_loanamount'])) {
                    									        $max_count= max(array_column($selected_loan['trendingbranch_loanamount'], 'progress'));

                                									            $branch_amtcount = 1;

                                									            foreach($selected_loan['trendingbranch_loanamount'] as $branch_loanamt){

                                									                

                                									                if($branch_loanamt['progress']) {

                                									    ?>

                                										<div class="mb-5">

                                											<p class="mb-2"><?php echo $branch_loanamt['department']; ?><span class="float-right text-muted"><?php echo number_format($branch_loanamt['progress'], 2).'%';?></span></p>

                                											<div class="progress h-2">

                                												<div class="progress-bar"  style="background-color: <?php echo $branch_loanamt['color_pattern']?>;width:<?php echo ($branch_loanamt['progress']/$max_count)*100?>%" role="progressbar"></div>

                                											</div>

                                										</div>

                                										

                                										<?php 

                                										

                                										    if($branch_amtcount == 5){

                                										        break;

                                										    }

                                										    $branch_amtcount ++;

                                									      } 

                                										}  }?>

                                										

                                									</div>

                                								</div>

                                							</div><!-- COL END -->

                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">

                                								<div class="card">

                                									<div class="card-header">

                                										<h3 class="card-title">Top 5 Placeurs par rapport au nombre total de prêts par OBJECTIFS</h3>

                                									</div>

                                									<div class="card-body p-4">

                                									 <?php  

                    									  

                    									    if(!empty($selected_loan['trendingplaceur_loannumber'])) {
                    									          $max_count= max(array_column($selected_loan['trendingplaceur_loannumber'], 'progress'));

                                									            $placeur_loancount = 1;

                                									            foreach($selected_loan['trendingplaceur_loannumber'] as $placeur_loanno){

                                									                

                                									                if($placeur_loanno['progress']) {

                                									    ?>

                                										<div class="mb-5">

                                											<p class="mb-2"><?php echo $placeur_loanno['user']; ?><span class="float-right text-muted"><?php echo number_format($placeur_loanno['progress'], 2).'%';?></span></p>

                                											<div class="progress h-2">

                                												<div class="progress-bar"  style="background-color: <?php echo $placeur_loanno['color_pattern']?>;width:<?php echo ($placeur_loanno['progress']/$max_count)*100?>%" role="progressbar"></div>

                                											</div>

                                										</div>

                                										

                                										<?php 

                                										

                                										    if($placeur_loancount == 5){

                                										        break;

                                										    }

                                										    $placeur_loancount ++;

                                									      } 

                                										}  }?>

                                										

                                									</div>

                                								</div>

                                							</div><!-- COL END -->

                                

                                						</div>

                                

                                						<div class="row">

                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">

                                								<div class="card">

                                									<div class="card-header">

                                										<h3 class="card-title">5 DERNIÈRES agences par Nbre de prêt</h3>

                                									</div>

                                									<div class="card-body p-4">

                                									 <?php  

                    									  

                    									    if(!empty($selected_loan['last5loan_countdetails'])){ 
                    									          $max_count= max(array_column($selected_loan['last5loan_countdetails'], 'loancount'));

                                									        foreach($selected_loan['last5loan_countdetails'] as $lcount){

                                									    ?>

                                							        	<div class="mb-5">

                                											<p class="mb-2"><?php echo $lcount['department']?><span class="float-right text-muted"><?php echo number_format($lcount['loancount'],0,',',',')  ;?></span></p>

                                											<div class="progress h-2">

                                												<div class="progress-bar"  style="background-color: <?php echo $lcount['color_pattern']?>;width:<?php echo ($lcount['loancount']/$max_count)*100?>%" role="progressbar"></div>

                                											</div>

                                										</div>

                                								    <?php } } ?>

                                										

                                										

                                									</div>

                                								</div>

                                							</div><!-- COL END -->

                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">

                                								<div class="card">

                                									<div class="card-header">

                                										<h3 class="card-title">5 DERNIÈRES  agences par montant de prêt</h3>

                                									</div>

                                									<div class="card-body p-4">

                                									 <?php  

                    									    

                    									    if(!empty($selected_loan['last5loan_amountdetails'])){ 
                    									        $max_count= max(array_column($selected_loan['last5loan_amountdetails'], 'total_amount'));

                                									        foreach($selected_loan['last5loan_amountdetails'] as $lamount){

                                									    ?>

                                							        	<div class="mb-5">

                                											<p class="mb-2"><?php echo $lamount['department']?><span class="float-right text-muted"><?php echo number_format($lamount['total_amount'],0,',',',')  ;?></span></p>

                                											<div class="progress h-2">

                                												<div class="progress-bar"  style="background-color: <?php echo $lamount['color_pattern']?>;width:<?php echo ($lamount['total_amount']/$max_count)*100?>%" role="progressbar"></div>

                                											</div>

                                										</div>

                                								    <?php } } ?>

                                										

                                										

                                									</div>

                                								</div>

                                							</div><!-- COL END -->

                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">

                                								<div class="card">

                                									<div class="card-header">

                                										<h3 class="card-title">Top 5 des agences avec des Nbre de dossiers hors délais (> 3 jours)</h3>

                                									</div>

                                									<div class="card-body p-4">

                                									    

                                									    <?php 

                    									    

                    									     if(!empty($selected_loan['top5loan_moreagingloan'])) {
                    									         $max_count= max(array_column($selected_loan['top5loan_moreagingloan'], 'totalcount'));

                                									        foreach($selected_loan['top5loan_moreagingloan'] as $more_aging){

                                									    ?>

                                										<div class="mb-5">

                                											<p class="mb-2"><?php echo $more_aging['department']; ?><span class="float-right text-muted"><?php echo $more_aging['totalcount']; ?></span></p>

                                											<div class="progress h-2">

                                												<div class="progress-bar"  style="background-color: <?php echo $more_aging['color_pattern']?>;width:<?php echo ($more_aging['totalcount']/$max_count)*100?>%" role="progressbar"></div>

                                											</div>

                                										</div>

                                										<?php } } ?>

                                										

                                									</div>

                                								</div>

                                							</div><!-- COL END -->

                                

                                						</div>

                                

                                						<div class="row">

                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">

                                								<div class="card">

                                									<div class="card-header">

                                										<h3 class="card-title">5 DERNIÈRES Agences par rapport au Nbre de prêt par OBJECTIFS</h3>

                                									</div>

                                									<div class="card-body p-4">

                                									

                                									<?php 

                                									     

                    									   

                    									    

                                									if(!empty($selected_loan['last5branches_loanno'])) {
                                									     $max_count= max(array_column($selected_loan['last5branches_loanno'], 'progress'));

                                									            $last_loancount = 1;

                                									            foreach($selected_loan['last5branches_loanno'] as $last_loanno){

                                									                

                                									                if($last_loanno['progress']) {

                                									    ?>

                                										<div class="mb-5">

                                											<p class="mb-2"><?php echo $last_loanno['department']; ?><span class="float-right text-muted"><?php echo number_format($last_loanno['progress'], 2).'%';?></span></p>

                                											<div class="progress h-2">

                                												<div class="progress-bar"  style="background-color: <?php echo $last_loanno['color_pattern']?>;width:<?php echo ($last_loanno['progress']/$max_count)*100?>%" role="progressbar"></div>

                                											</div>

                                										</div>

                                										

                                										<?php 

                                										

                                										    if($last_loancount == 5){

                                										        break;

                                										    }

                                										    $last_loancount ++;

                                									      } 

                                										}  }?>

                                										

                                									</div>

                                								</div>

                                							</div><!-- COL END -->

                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">

                                								<div class="card">

                                									<div class="card-header">

                                										<h3 class="card-title">5 DERNIÈRES agences par rapport au montant total du prêt par OBJECTIFS</h3>

                                									</div>

                                									<div class="card-body p-4">

                                										<?php 


                                									if(!empty($selected_loan['last5branches_loanamt'])) {
                                									    $max_count= max(array_column($selected_loan['last5branches_loanamt'], 'progress'));

                                									            $last_loanamt = 1;

                                									            foreach($selected_loan['last5branches_loanamt'] as $last_amount){

                                									                

                                									                if($last_amount['progress']) {

                                									    ?>

                                										<div class="mb-5">

                                											<p class="mb-2"><?php echo $last_amount['department']; ?><span class="float-right text-muted"><?php echo number_format($last_amount['progress'], 2).'%';?></span></p>

                                											<div class="progress h-2">

                                												<div class="progress-bar"  style="background-color: <?php echo $last_amount['color_pattern']?>;width:<?php echo ($last_amount['progress']/$max_count)*100?>%" role="progressbar"></div>

                                											</div>

                                										</div>

                                										

                                										<?php 

                                										

                                										    if($last_loanamt == 5){

                                										        break;

                                										    }

                                										    $last_loanamt ++;

                                									      } 

                                										}  }?>

                                										

                                										

                                									</div>

                                								</div>

                                							</div><!-- COL END -->

                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">

                                								<div class="card">

                                									<div class="card-header">

                                										<h3 class="card-title">5 DERNIERS Placeurs par rapport au nombre total de prêts par OBJECTIFS</h3>

                                									</div>

                                									<div class="card-body p-4">

                                								    	<?php 


                                									        if(!empty($selected_loan['last5placeur_loanno'])) {
                                									              $max_count= max(array_column($selected_loan['last5placeur_loanno'], 'progress'));

                                									            $last_placeur = 1;

                                									            foreach($selected_loan['last5placeur_loanno'] as $last_placeurloaanno){

                                									                

                                									                if($last_placeurloaanno['progress']) {

                                									    ?>

                                    										<div class="mb-5">

                                    											<p class="mb-2"><?php echo $last_placeurloaanno['user']; ?><span class="float-right text-muted"><?php echo number_format($last_placeurloaanno['progress'], 2).'%';?></span></p>

                                    											<div class="progress h-2">

                                    												<div class="progress-bar"  style="background-color: <?php echo $last_placeurloaanno['color_pattern']?>;width:<?php echo ($last_placeurloaanno['progress']/100)*100?>%" role="progressbar"></div>

                                    											</div>

                                    										</div>

                                										

                                										<?php 

                                										

                                										    if($last_placeur == 5){

                                										        break;

                                										    }

                                										    $last_placeur ++;

                                									      } 

                                										}  }?>

                                										

                                									</div>

                                								</div>

                                							</div><!-- COL END -->

                                

                                						</div>

                                

                                						<div class="row">

                                							

                                

                                							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">

                                								<div class="card">

                                									<div class="card-body text-center">

                                										<i class="fa fa-globe text-primary fa-3x text-primary-shadow"></i>

                                										<h6 class="mt-4 mb-2">Nombre total d'annulations de prêt</h6>

                                										<h2 class="mb-2 number-font"><?php echo  number_format($selected_loan['Annuler_loannumber'],0,',',',') ; ?></h2>

                                										<p class="text-muted"></p>

                                									</div>

                                								</div>

                                							</div><!-- COL END -->

                                

                                							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">

                                								<div class="card">

                                									<div class="card-body text-center">

                                										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>

                                										<h6 class="mt-4 mb-2">Montant total de l'annulation du prêt</h6>

                                										<h2 class="mb-2  number-font"><?php echo  number_format($selected_loan['Annuler_loanamount'],0,',',',') ; ?></h2>

                                										<p class="text-muted"></p>

                                									</div>

                                								</div>

                                							</div><!-- COL END -->

                                							

                                							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">

                                								<div class="card">

                                									<div class="card-body text-center">

                                										<i class="fa fa-globe text-primary fa-3x text-primary-shadow"></i>

                                										<h6 class="mt-4 mb-2">Nombre total de prêt Abondonne</h6>

                                										<h2 class="mb-2 number-font"><?php echo  number_format($selected_loan['Abandonner_loannumber'],0,',',',') ; ?></h2>

                                										<p class="text-muted"></p>

                                									</div>

                                								</div>

                                							</div><!-- COL END -->

                                							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">

                                								<div class="card">

                                									<div class="card-body text-center">

                                										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>

                                										<h6 class="mt-4 mb-2">Montant total du prêt Abondonne</h6>

                                										<h2 class="mb-2  number-font"><?php echo  number_format($selected_loan['Abandonner_loanamount'],0,',',',') ; ?></h2>

                                										<p class="text-muted"></p>

                                									</div>

                                								</div>

                                							</div><!-- COL END -->

                                						</div>

                                

                                						<div class="row">

                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-3">

                                								<div class="card">

                                									<div class="card-header">

                                										<h3 class="card-title">Top 5 des agences par nombre total de prêts Annule</h3>

                                									</div>

                                									<div class="card-body p-4">

                                									    <?php

                                									   

                                									    if(!empty($selected_loan['top5loan_countdetails_annule'])){ 
                                									         $max_count= max(array_column($selected_loan['top5loan_countdetails_annule'], 'loancount'));

                                									        foreach($selected_loan['top5loan_countdetails_annule'] as $tcount){

                                									    ?>

                                							        	<div class="mb-5">

                                											<p class="mb-2"><?php echo $tcount['department']?><span class="float-right text-muted"><?php echo  number_format($tcount['loancount'],0,',',',') ;?></span></p>

                                											<div class="progress h-2">

                                												<div class="progress-bar"  style="background-color: <?php echo $tcount['color_pattern']?>;width:<?php echo ($tcount['loancount']/$max_count)*100?>%" role="progressbar"></div>

                                											</div>

                                										</div>

                                									    <?php } } ?>

                                										

                                										

                                										

                                									</div>

                                								</div>

                                							</div><!-- COL END -->

                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-3">

                                								<div class="card">

                                									<div class="card-header">

                                										<h3 class="card-title">Top 5 des agences par montant total de prêt Annule</h3>

                                									</div>

                                									<div class="card-body p-4">

                                										<?php

                                										
                                										if(!empty($selected_loan['top5loan_amountdetails_annule'])){ 
                                										    $max_count= max(array_column($selected_loan['top5loan_amountdetails_annule'], 'total_amount'));


                                									        foreach($selected_loan['top5loan_amountdetails_annule'] as $tcount){

                                									    ?>

                                							        	<div class="mb-5">

                                											<p class="mb-2"><?php echo $tcount['department']?><span class="float-right text-muted"><?php echo  number_format($tcount['total_amount'],0,',',',') ;?></span></p>

                                											<div class="progress h-2">

                                												<div class="progress-bar"  style="background-color: <?php echo $tcount['color_pattern']?>;width:<?php echo ($tcount['total_amount']/$max_count)*100?>%" role="progressbar"></div>

                                											</div>

                                										</div>

                                									    <?php } } ?>

                                										

                                										

                                									</div>

                                								</div>

                                							</div><!-- COL END -->

                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-3">

                                								<div class="card">

                                									<div class="card-header">

                                										<h3 class="card-title">Top 5 des agences par nombre total de prêts Abandon</h3>

                                									</div>

                                									<div class="card-body p-4">

                                										<?php

                                										
                                										if(!empty($selected_loan['top5loan_countdetails_Abandonner'])){ 
                                										    	$max_count= max(array_column($selected_loan['top5loan_countdetails_Abandonner'], 'loancount'));

                                									        foreach($selected_loan['top5loan_countdetails_Abandonner'] as $tcount){

                                									    ?>

                                							        	<div class="mb-5">

                                											<p class="mb-2"><?php echo $tcount['department']?><span class="float-right text-muted"><?php echo  number_format($tcount['loancount'],0,',',',') ;?></span></p>

                                											<div class="progress h-2">

                                												<div class="progress-bar"  style="background-color: <?php echo $tcount['color_pattern']?>;width:<?php echo ($tcount['loancount']/$max_count)*100?>%" role="progressbar"></div>

                                											</div>

                                										</div>

                                									    <?php } } ?>

                                										

                                										

                                									</div>

                                								</div>

                                							</div><!-- COL END -->

                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-3">

                                								<div class="card">

                                									<div class="card-header">

                                										<h3 class="card-title">Top 5 des agences par montant total de prêt Abondonne</h3>

                                									</div>

                                									<div class="card-body p-4">

                                										<?php

                                										

                                										if(!empty($selected_loan['top5loan_amountdetails_Abandonner'])){ 
                                										    $max_count= max(array_column($selected_loan['top5loan_amountdetails_Abandonner'], 'total_amount'));

                                									        foreach($selected_loan['top5loan_amountdetails_Abandonner'] as $tcount){

                                									    ?>

                                							        	<div class="mb-5">

                                											<p class="mb-2"><?php echo $tcount['department']?><span class="float-right text-muted"><?php echo  number_format($tcount['total_amount'],0,',',',') ;?></span></p>

                                											<div class="progress h-2">

                                												<div class="progress-bar"  style="background-color: <?php echo $tcount['color_pattern']?>;width:<?php echo ($tcount['total_amount']/$max_count)*100?>%" role="progressbar"></div>

                                											</div>

                                										</div>

                                									    <?php } } ?>

                                										

                                										

                                									</div>

                                								</div>

                                							</div><!-- COL END -->

                                

                                						</div>

<!-- ECHART JS-->


<script src="<?php echo base_url('assets/volgh/assets/plugins/echarts/echarts.js');?>"></script>
<script>
	//import * as echarts from 'echarts';

var app = {};



var chartDom = document.getElementById('sel_echart2');

var myChart = echarts.init(chartDom);

var option;



const posList = [

  'left',

  'right',

  'top',

  'bottom',

  'inside',

  'insideTop',

  'insideLeft',

  'insideRight',

  'insideBottom',

  'insideTopLeft',

  'insideTopRight',

  'insideBottomLeft',

  'insideBottomRight'

];

app.configParameters = {

  rotate: {

    min: -90,

    max: 90

  },

  align: {

    options: {

      left: 'left',

      center: 'center',

      right: 'right'

    }

  },

  verticalAlign: {

    options: {

      top: 'top',

      middle: 'middle',

      bottom: 'bottom'

    }

  },

  position: {

    options: posList.reduce(function (map, pos) {

      map[pos] = pos;

      return map;

    }, {})

  },

  distance: {

    min: 0,

    max: 100

  }

};

app.config = {

  rotate: 90,

  align: 'left',

  verticalAlign: 'middle',

  position: 'insideBottom',

  distance: 15,

  onChange: function () {

    const labelOption = {

      rotate: app.config.rotate,

      align: app.config.align,

      verticalAlign: app.config.verticalAlign,

      position: app.config.position,

      distance: app.config.distance

    };

    myChart.setOption({

      series: [

        {

          label: labelOption

        },

        {

          label: labelOption

        },

        {

          label: labelOption

        },

        {

          label: labelOption

        }

      ]

    });

  }

};

const labelOption = {

  show: true,

  position: app.config.position,

  distance: app.config.distance,

  align: app.config.align,

  verticalAlign: app.config.verticalAlign,

  rotate: app.config.rotate,

  formatter: '{c}  {name|{a}}',

  fontSize: 16,

  rich: {

    name: {}

  }

};

option = {

  tooltip: {

    trigger: 'axis',

    axisPointer: {

      type: 'shadow'

    }

  },

  legend: {

    data: ['Actives', 'Approved', 'In Process', 'Annule/Abondon']

  },

  toolbox: {

    show: true,

    orient: 'vertical',

    left: 'right',

    top: 'center',

    feature: {

    //   mark: { show: true,title: "Reset" },

    //   dataView: { show: true, readOnly: false ,title: "Reset1"},

      magicType: { show: true, type: ['line', 'bar', 'stack'],title: {  line: "Line", bar: "Bar", stack:"Stack"  } },

      restore: { show: true,title: "Reset" },

      saveAsImage: { show: true, title: "Save as Image" }

    }

  },

  xAxis: [

    {

      type: 'category',

      axisTick: { show: false },

      data: ['Cette Semaine', 'Semaine 1', 'Semaine 2', 'Semaine 3']

    }

  ],

  yAxis: [

    {

      type: 'value'

    }

  ],

  series: [

    {

      name: 'Actives',

      type: 'bar',

      barGap: 0,

      label: labelOption,

      emphasis: {

        focus: 'series'

      },

      data: [<?php echo $this->data['this_week_data_actives']; ?>, <?php echo $this->data['prev_week_data1_actives']; ?>, <?php echo $this->data['prev_week_data2_actives']; ?>, <?php echo $this->data['prev_week_data3_actives']; ?>]

    },

    {

      name: 'Approved',

      type: 'bar',

      label: labelOption,

      emphasis: {

        focus: 'series'

      },

      data: [<?php echo $this->data['this_week_data_approved']; ?>, <?php echo $this->data['prev_week_data1_approved']; ?>, <?php echo $this->data['prev_week_data2_approved']; ?>, <?php echo $this->data['prev_week_data3_approved']; ?>]

    },

    {

      name: 'In Process',

      type: 'bar',

      label: labelOption,

      emphasis: {

        focus: 'series'

      },

      data: [<?php echo $this->data['this_week_data_in_process']; ?>, <?php echo $this->data['prev_week_data1_cancelled']; ?>, <?php echo $this->data['prev_week_data2_cancelled']; ?>, <?php echo $this->data['prev_week_data3_cancelled']; ?>]

    },

    {

      name: 'Annule/Abondon',

      type: 'bar',

      label: labelOption,

      emphasis: {

        focus: 'series'

      },

      data: [<?php echo $this->data['this_week_data_cancelled'];?>, <?php echo $this->data['prev_week_data1_in_process']; ?>, <?php echo $this->data['prev_week_data2_in_process']; ?>, <?php echo $this->data['prev_week_data3_in_process']; ?>]

    }

  ]

};



option && myChart.setOption(option);

</script>

