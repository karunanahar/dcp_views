<?php 
$documentArray1 = 0;
if(isset($documentArray))
	$documentArray1 = sizeof($documentArray); 
$customer=(array) json_decode($appformD['customer_data']);
$databinding=(array) json_decode($appformD['databinding']);
$convert=new ConvertNumberToText();
?>

<html>
    <head>
		<style> 
			/*#contractDePret{ */
			/*	margin-top: 5px; */
			/*}*/
		@page {
            margin: 0;
        }
		</style>
		<link rel="stylesheet" href="<?php echo base_url('assets/css/compiled/document_css.css" type="text/css');?>" media='all'/>
	</head> 
	</head>
	<p style="page-break-before: always;">&nbsp;</p>
    <body id="contractDePret"  translate="no" style="background-color: #fff; font-family: Open Sans, sans-serif; font-size: 100%; font-weight: 400; line-height: 1.4; color: #000; margin: 0;">	
        <table style="width: 700px; background-color: #fff; margin: 0px auto;">
            <tbody>
                <tr>
                    <td>
                        <table style="width: 100%; margin-top: 1px;">
                            <tbody>
                                 
                                <tr>
								<td style="position: relative; text-align: left; width: 40px;"><img src="<?php echo  base_url(); ?>assets/logo2.png" class="common_document_logo2" /></td>
                                     
									<td style="width: 300px; text-align: right; font-size: 11px; line-height: 15px;">
										<span style="display: block; font-weight: bold;">AFG BANK</span>

										<span style="display: block; font-weight: bold;">GABON SA avec Conseil d’Administration </span>
										<span style="display: block;"></span>
										<span style="display: block;">Au capital de 18&nbsp;000&nbsp;000&nbsp;000 FCFA</span>
										<span style="display: block;">Siège Social&nbsp;: Avenue du Colonel Parant</span>
										<span style="display: block;">BP&nbsp;: 2241 Libreville - Gabon</span>
										<span style="display: block;">N° RCCM&nbsp;: 2002 B 01732 Libreville - NIF&nbsp;: 790027 A</span>
										<span style="display: block;">SWIFT&nbsp;: AFGGGALX</span>
									</td>

                                </tr>
								<tr>
                                    <td style="width: 100%; text-align: center;" colspan="2">
                                        <span style="font-weight: bold; font-size: 17px; padding: 10px;">ACTE DE PRET</span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>

                <tr>
                    <td>
                        <table style="width: 100%;">
                            <tbody>
                                <tr>
                                    <td style="width: 100%; vertical-align: top; padding-right: 10px;">
                                        <table style="width: 100%;">
                                           <tbody>
                                                <tr>
                                                    <td colspan="2" style="height: 3px; width: 100%;"></td>
                                                </tr>

                                                <tr>
                                                    <td colspan="2" style="font-size: 12px; font-weight: normal;">
                                                        <div style="display: flex;">
                                                            <span style="display: block;width: 140px;">Je soussigné (1) </span>
                                                            <span style="display: block; width: 100%; border-bottom: dashed 1px;"> <?php echo ucfirst($customer['last_name'])." " ?: '-';?><?php echo ucfirst($customer['middle_name'])." " ?: '';?><?php echo ucfirst($customer['first_name']) ?: '-';?></span>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="2" style="font-size: 12px; font-weight: normal;">
                                                        <div style="display: flex;">
                                                            <span style="display: block; width: 152px;">Né le <span style="     display: inline-block; margin: 0px 5px;  min-width:50px ; border-bottom: dashed 1px;"><?php echo date("d-m-Y",strtotime($customer['dob']));?> </span> 
                                                            <span style="display: block; width: 152px;">  à  <span style="     display: inline-block; margin: 0px 5px;  min-width:50px ; border-bottom: dashed 1px;"><?php echo $customer['birthplace'];?></span>
                                                            <span style="display: block; width: 100%; border-bottom: dashed 1px;">  </span>
                                                        </div>
                                                    </td>
                                                </tr>
												<tr>
                                                    <td colspan="2" style="height: 3px; width: 100%;"></td>
                                                </tr>
												<tr>
                                                    <td colspan="2" style="font-size: 12px; font-weight: normal;">
                                                        <div style="display: flex;">
                                                            <span style="display: block;width: 110px;">Demeurant à </span>
                                                            <span style="display: block; width: 100%; border-bottom: dashed 1px;"> <?php echo ucfirst($customer['resides_address'])." " ?: '-';?>, <?php echo ucfirst($customer['city_id'])." " ?: '-';?> </span>
                                                        </div>
                                                    </td>
                                                </tr>
												<tr>
                                                    <td colspan="2" style="height: 3px; width: 100%;"></td>
                                                </tr>
												<tr>
                                                    <td colspan="2" style="font-size: 12px; font-weight: normal;">
                                                        <div style="display: black;">
                                                            <span style="display: block; line-height: 18px; text-align: justify;">reconnais devoir à la AFG BANK GABON

La somme de <span style="     display: inline-block; margin: 0px 5px;  min-width:50px ; border-bottom: dashed 1px;"> <?php echo number_format($appformD['loan_amt'],0,',',' ');?></span>  F. CFA reçue à titre et portée au crédit de mon </span> 
                                                        </div>
                                                    </td>
                                                </tr>
												<tr>
                                                    <td colspan="2" style="height: 3px; width: 100%;"></td>
                                                </tr>
												<tr>
                                                    <td colspan="2" style="font-size: 12px; font-weight: normal;">
                                                        <div style="display: black;">
                                                            <span style="display: block;line-height: 18px;">compte N° <span style="display: inline-block; margin: 0px 5px;  min-width:50px ; border-bottom: dashed 1px;"> <?php echo $customer['flexcube_acct'] ;?> </span>  Chez son siège de <span style="     display: inline-block; margin: 0px 5px;  min-width:50px ; border-bottom: dashed 1px;"> <?php echo $appformD['branch_name'];?> </span> le <?php echo date("d-m-Y",strtotime($appformD['cdate'])) ;?></span> 
                                                        </div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table style="width: 100%; border-collapse: collapse;">
                            <tbody style="">
                                <tr>
                                    <td colspan="3" style="font-size: 12px; text-align: left; line-height: 18px;">
                                        <span style="font-weight: normal; display: block; text-align: justify;">
                                            La AFG BANK GABON ne sera pas tenue à l’égard de quiconque de surveiller l’emploi des fonds .Je m’engage à rembourser ce prêt en <span style="display: inline-block; margin: 0px 5px;  min-width:50px ; border-bottom: dashed 1px;"> <?php echo number_format($appformD['loan_term'],0,',',' ');?> </span> termes mensuels d’un montant constant de <span style="display: inline-block; margin: 0px 5px;  min-width:50px ; border-bottom: dashed 1px;"><?php echo number_format($appformD['pmnt'],0,',',' ');?> </span> francs décompté sur le montant en capital restant dû après chaque échéance, 
ce programme d’amortissement ne pourra en aucun cas être modifié.<br>
<?php

                                         $calcul_last_date = cal_days_in_month(CAL_GREGORIAN, $databinding[0]->month, $databinding[0]->years);
        							    if($databinding[0]->month == "02"){
        							        $prive_val = $calcul_last_date;
        							        $prive_txt = "Prive ".$prive_val;
        							        
        							    }
        							    else{
        							        $prive_val = '30';
        							        $prive_txt = "Prive 30";
        							    }
        							    
                                         if((($customer['cat_employeurs']) == "Public Civil 25") || (($customer['cat_employeurs']) == "Prive 25") || (($customer['cat_employeurs']) == "Public Corps 25")){
                                            $loandate= '25';
                                        }else if((($customer['cat_employeurs']) == "Prive 20") || (($customer['cat_employeurs']) == "Autres 20")){
                                            $loandate='20';
                                        }
                                         else if((($customer->cat_employeurs) == $prive_txt) || (($customer->cat_employeurs) == "Organisation internationales")){
        									$loandate=$prive_val;
        								}else{
        								    
        									$loandate=$prive_val;
        								}
                                        ?>
Le premier remboursement aura lieu  le <span style="display: inline-block; margin: 0px 5px;  border-bottom: dashed 1px;"><?php echo $loandate."-".$databinding[0]->month."-".$databinding[0]->years?> </span> ,le dernier le <span style="display: inline-block; margin: 0px 5px;    border-bottom: dashed 1px;"><?php echo $loandate."-".end($databinding)->month."-".end($databinding)->years?> </span>
                                        </span>
                                        <span style="font-weight: normal; display: block; height: 10;"></span>
                                        <span style="font-weight: normal; display: block; text-align: justify;">
                                           Le règlement de ces termes sera automatiquement effectué par le débit de mon compte sus-indiqué que je m’engage à approvisionner à cette fin. Je donne à cet effet mandat irrévocable permanent à la AFG BANK GABON.
                                        </span>
                                        <span style="font-weight: normal; display: block; height: 3px;"></span>
                                        <span style="font-weight: normal; display: block; text-align: justify;">
                                           Par ailleurs, je m’engage à supporter les frais, taxes et prélèvements de  toute nature, présents ou à venir dont pourrait être frappé le présent contrat, ainsi que les frais et honoraires des présentes et ceux qui en seront la conséquence.
                                        </span>
                                        <span style="font-weight: normal; display: block; height: 3px;"></span>
                                        <span style="font-weight: normal; display: block; text-align: justify;">
                                           En cas de non respect de l’une des quelconque des clauses du présent acte et notamment en cas de défaut d’un seul des règlements indiqués ci-dessus, la totalité de la créance en principal, intérêts et accessoires deviendrait immédiatement et de plein droit exigible, s’il convient à la AFG BANK GABON, et celle-ci aurait alors une entière liberté d’action pour recouvrer ladite créance par toutes voies et moyens de droit. En cas d’exigibilité anticipée ou atermoiement pour quelque cause que soit, les sommes devenues exigibles seront productives d’intérêts au taux du présent prêt. Les dits intérêts, échus et non payés, se  capitaliseront de plein droit à compter du jour où ils seront dus pour une année entière et porteront eux-mêmes intérêts aux taux du présent prêt.  
                                        </span>
                                        <span style="font-weight: normal; display: block; height: 3px;"></span>
                                        <span style="font-weight: normal; display: block; text-align: justify;">
                                            A peine d’exigibilité anticipée, je m’engage à première demande de la AFG BANK GABON, à lui consentir toutes garanties qu’elle jugera souhaitables.
Toutes les obligations résultant des présentes sont stipulées solidaires et indivisibles entre mes héritiers et ayants droit de telle sorte que leur exécution pourra être réclamée pour le tout à n’importe quel moment.
                                        </span>
                                        <span style="font-weight: normal; display: block; height: 3px;"></span>
                                        <span style="font-weight: normal; display: block; text-align: justify;">
                                           En outre je certifie, après avoir pris connaissance de l’article L113-8 du code des assurances :
                                        </span>
                                        
                                        <ul style="font-size: 12px; line-height: 18px; list-style: circle; margin: 0;">
                                            <li>Ne pas être en état d’incapacité temporaire de travail et exercer mon activité professionnelle de façon normale et effective ;</li>

                                            <li>N’être atteint d’aucune infirmité, invalidité, maladie aigüe ou chronique ;</li>

                                            <li>Ne suivre aucun traitement ou régime et ne pas être sous surveillance médicale</li>

                                         </ul>
                                    <span style="font-weight: normal; display: block; height: 3px;"></span>
                                        <span style="font-weight: normal; display: block; text-align: justify;">
                                           En cas de remboursement anticipé, après avoir fait la demande avec préavis d’un mois, je m’engage à reverser à la Banque une indemnité égale à <span style="display: inline-block; margin: 0px 5px;  min-width:50px;  border-bottom: dashed 1px;">05</span>% (taxe en sus) du capital effectivement rembourse par anticipation.
                                        </span>
										 <span style="font-weight: normal; display: block; height: 10px;"></span>
									</td>
									
                                </tr>
								<tr>
                                    <td colspan="2" style="width: 50%; font-size: 16px; font-weight: normal; line-height: 18px;"></td>
                                    <td colspan="1" style="width: 50%; font-size: 16px; font-weight: normal; line-height: 18px; text-align: center;">
                                        <span style="display: block; font-size: 12px; font-weight: 600;">
                                            Fait à <span style="display: inline-block; margin: 0px 5px;  min-width:50px;  border-bottom: dashed 1px;"></span> , le <span style="display: inline-block; margin: 0px 5px;  min-width:50px;  border-bottom: dashed 1px;"> </span>
                                        </span>
										<br>
                                        <span style="display: block; font-size: 13px; padding: 0; font-weight: 400;">
                                            Signature (2)
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="3" style="width: 100%; font-size: 12px; font-weight: normal; line-height: 16px; padding: 5px; height: 100px; vertical-align: top;">
                                        <span style="display: block; font-size: 12px; padding: 0; font-weight: 400; text-align: justify;">
                                            () Nom et prénoms dans l’ordre de l’Etat Civil.
                                        </span>
                                        <span style="display: block; font-size: 12px; padding: 0; font-weight: 400; text-align: justify; height: 3px;"></span>
                                        <span style="display: block; font-size: 12px; padding: 0; font-weight: 400; text-align: justify;">
                                            (2) La signature doit être précédée de la mention suivante :
                                        </span>
                                        
                                        <span style="display: block; font-size: 12px; padding: 0; font-weight: 400; text-align: justify; height: 3px;"></span>
                                        <span style="display: block; font-size: 12px; padding: 0; font-weight: 400; text-align: justify;">
                                            LU ET APPROUVE BON POUR F.CFA <span style="display: inline-block; margin: 0px 5px;  min-width:50px ; border-bottom: dashed 1px;"><strong><?php echo strtoupper($convert->Convert($appformD['tpmnt'])) ; ?></strong></span>(montant en toute lettres)
‘‘ EN PRINCIPAL PLUS INTERÊTS, FRAIS ET ACCESSOIRES’’
                                        </span>
                                    </td>
                                </tr>
								<tr>
                                    <td colspan="3" style="height: 10px;"></td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
        <center>
            <style type="text/css">
				@media print {
				  .hidden-print {
					visibility: hidden !important;
				  }
				}
			</style>
			<?php 
			if(isset($documentArray1) && $documentArray1 == $combine_doc){?>
				<button class="btn btn-primary hidden-print" id="printPageButton" onclick="myfunction()" style="position: relative;">Print Page</button>
			<?php }
			else if($documentArray1 == 0){?>
				<button class="btn btn-primary hidden-print" id="printPageButton" onclick="myfunction()" style="position: relative;">Print Page</button>
			<?php }?>
        </center>
    </body>
    <script type="text/javascript">
		function myfunction(){ window.print();}
	</script>
</html>
