<?php   
       $customer_data =  json_decode($loan_details['customer_data']);
       $databinding=(array) json_decode($amortizationdata[0]['databinding']);

                                    
        if($amortizationdata[0]['loan_schedule']=='Monthly'){
            $year=($amortizationdata[0]['loan_term']/12);
        }else if($amortizationdata[0]['loan_schedule']=='Yearly'){
            $year=$amortizationdata[0]['loan_term'];
        }
        else if($amortizationdata[0]['loan_schedule']=='Yearly'){
            $year=$amortizationdata[0]['loan_term'];
        }

        $loan_interest =$amortizationdata[0]['loan_interest'];
        // $rt=($loan_interest*(1+19.25/100));
        $vat_on_interest=$amortizationdata[0]['loan_tax'] ?: '19.25'; 
        $rt=($loan_interest*(1+$vat_on_interest/100));
        $curd=date("Y-m-d", strtotime($amortizationdata[0]['created']));
        $amount=$amortizationdata[0]['loan_amt'];
        $rate=$rt;
        $years=$year;
        $am=new Class_Amort();
        $am->amort($amount,$rate,$years,$curd, $loan_interest,$amortizationdata[0]['tva'],$amortizationdata[0]['css'],$fraisDosier,$age,$amount);
        // $am->amort($amount,$rate,$years,$curd, $loan_interest,$this->data['tax_interest'],$this->data['css_value'],'','','');
        // echo "<pre>", print_r($am),"</pre>";
    //   echo $ebal = $am->amount;
        $years=$years;
        if(($years*12) <12){
         $month=($years*12);
         $text="Months";
        }else{
          $month=($years);
          $text="years";
          
        }
        
        
         $calcul_last_date = cal_days_in_month(CAL_GREGORIAN, $databinding[0]->month, $databinding[0]->years);
	    if($databinding[0]->month == "02"){
	        $prive_val = $calcul_last_date;
	        $prive_txt = "Prive ".$prive_val;
	        
	    }
	    else{
	        $prive_val = '30';
	        $prive_txt = "Prive 30";
	    }
        							    
        							    
    if((($customer_data->cat_employeurs) == "Public Civil 25") || (($customer_data->cat_employeurs) == "Prive 25") || (($customer_data->cat_employeurs) == "Public Corps 25")){
                                            $loandate= '25';
        }else if((($customer_data->cat_employeurs) == "Prive 20") || (($customer_data->cat_employeurs) == "Autres 20")){
            $loandate='20';
        }
        else if((($customer->cat_employeurs) == $prive_txt) || (($customer->cat_employeurs) == "Organisation internationales")){
			$loandate=$prive_val;
		}else{
		    $loandate=$prive_val;
		}
                                //        else if((($customer['cat_employeurs']) == "Prive 28") || (($customer['cat_employeurs']) == "Organisation internationales")){
                                //            $loandate='28';
                                //        }else{
                                //            $loandate='28';
                                //        }
                                        


                    $age= date_diff(date_create($customer_data->dob), date_create('today'))->y;
                        //   print_r($loan_details);
if ($age <= 30) {
                        
                                 if ($amortizationdata[0]['loan_term'] <= 24) {
                              $insuranceRate = "0.42";
                            } else if ($amortizationdata[0]['loan_term'] <= 35) {
                              $insuranceRate = "0.42";
                            } else if ($amortizationdata[0]['loan_term'] <= 60) {
                              $insuranceRate = "0.52";
                            } else if ($amortizationdata[0]['loan_term'] <= 96) {
                              $insuranceRate = "0.95";
                            } else if ($amortizationdata[0]['loan_term'] <= 144){
                              $insuranceRate = "1.52";
                            } else{
                              $insuranceRate = "2.17"; 
                            }
                      
                    } else if ($age <= 40) {
                             if ($amortizationdata[0]['loan_term'] <= 24) {
                              $insuranceRate = "0.75";
                            } else if ($amortizationdata[0]['loan_term'] <= 35) {
                              $insuranceRate = "0.75";
                            } else if ($amortizationdata[0]['loan_term'] <= 60) {
                              $insuranceRate = "0.94";
                            } else if ($amortizationdata[0]['loan_term'] <= 96) {
                              $insuranceRate = "1.76";
                            } else if ($amortizationdata[0]['loan_term'] <= 144){
                              $insuranceRate = "2.85";
                            } else{
                              $insuranceRate = "4.12"; 
                            }
                    } else if ($age <= 50) {
                            if ($amortizationdata[0]['loan_term'] <= 24) {
                              $insuranceRate = "0.92";
                            } else if ($amortizationdata[0]['loan_term'] <= 35) {
                              $insuranceRate = "0.92";
                            } else if ($amortizationdata[0]['loan_term'] <= 60) {
                              $insuranceRate = "1.94";
                            } else if ($amortizationdata[0]['loan_term'] <= 96) {
                              $insuranceRate = "3.61";
                            } else if ($amortizationdata[0]['loan_term'] <= 144){
                              $insuranceRate = "5.84";
                            } else{
                              $insuranceRate = "8.36"; 
                            }
                    } else if ($age <= 60) {
                            if ($amortizationdata[0]['loan_term'] <= 24) {
                              $insuranceRate = "2.06";
                            } else if ($amortizationdata[0]['loan_term'] <= 35) {
                              $insuranceRate = "2.06";
                            } else if ($amortizationdata[0]['loan_term'] <= 60) {
                              $insuranceRate = "4.29";
                            } else if ($amortizationdata[0]['loan_term'] <= 96) {
                              $insuranceRate = "7.89";
                            } else if ($amortizationdata[0]['loan_term'] <= 144){
                              $insuranceRate = "12.46";
                            } else{
                              $insuranceRate = "17.32"; 
                            }
                    } else {
                      $insuranceRate = "0.00";
                    }

                     $insuranceAmount=($amount*$insuranceRate)/100;                     
                    
                    
                if($age > 60){
                    
                    $insuranceAmort= $loan_details['frais_de_assurance'] ? $loan_details['frais_de_assurance'] : "0.00" ;
                }else{
                    $insuranceAmort= number_format($insuranceAmount,0,',',' ') ;
                }
                
                // echo $insuranceAmort;
?>  
<html>
    <head>
	<style>
		@page {
			margin: 0;

		} 
		.label_class{
			width: 183px; display: inline-block;background-color: #ddd; border-radius: 3px; padding:2px 5px 2px 5px;
		} 
		@media print { 
			pagebreak {
				page-break-before:always !important;
			}
		}
    </style>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/compiled/document_css.css" type="text/css');?>" media='all'/>
	</head>
    <body translate="no" style="background-color: #ffffff; font-family: Arial, Helvetica, sans-serif, sans-serif; font-size: 100%; font-weight: 400; line-height: 1.4; color: #000; margin: 0;">
        <br><br><br>
		<table CELLSPACING=0 CELLPADDING=5 style="width: 703px; background-color: #fff; margin: 0px auto; padding: 0;>
            <tbody>
                <tr>
                    <td style="border-bottom: 1px solid #333333;">
                        <table style="width: 800px; margin: 0px 30px 5px 30px;" >
                            <tbody> 
								<tr>
                                    <td style="position: relative; text-align: left; width: 40px;"><img src="<?php echo  base_url(); ?>/assets/logo2.png" class="common_document_logo" /></td>
                                    <td style="color: #000000;width: 600px; text-align: center;">
                                        <span style="color: #000000; font-weight: bold; font-size: 20px;">TABLEAU D'AMORTISSEMENT</span>
                                    </td>
                                </tr> 
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table style="width: 800px; margin: 5px 30px 5px 30px;">
                            <tbody>
                            
                                <tr>
                                    <td width="15px"></td>
                                    <td style="width: 100%; vertical-align: top; padding-right: 5px;">
                                        <table style="width:100%;">
                                            <tbody>
                                                <tr>
                                                    <td style="font-size: 13px; font-weight: bold;">
														<span class="label_class">Nom Du Client</span>
														<span style="font-weight: normal;"> 
															<?php echo ucwords($customer_data->first_name.' '.$customer_data->middle_name.' '.$customer_data->last_name);?>
														</span>
													</td>
                                                    <td style="font-size: 13px; font-weight: bold;"><span class="label_class">Numéro de compte</span>  <span style="font-weight: normal;"><?php echo $customer_data->flexcube_acct." " ?: ''; ?></span></td>
                                                </tr>
                                                <tr>
                                                    <td style="font-size: 13px; font-weight: bold;">
														<span  class="label_class">Type de prêt</span> <span style="font-weight: normal;">
														Crédit aux Personnel
														</span>
													</td>
                                                    <td style="font-size: 13px; font-weight: bold;">
														<span  class="label_class">Montant du prêt</span>
														<span style="font-weight: normal;">CFA <?php echo number_format($am->amount,0,',',' ');?></span>
													</td>
                                                </tr>   
                                                <tr>
                                                    <td style="font-size: 13px; font-weight: bold;"><span  class="label_class">Nombre d'échéances</span> <span style="font-weight: normal;"><?php echo $am->npmts; ?></span></td>
                                                    <td style="font-size: 13px; font-weight: bold;"><span  class="label_class">Modalité d'échéance</span>  <span style="font-weight: normal;">Constante</span></td>

												</tr>
                                                <tr>
                                                    <td style="font-size: 13px; font-weight: bold;"><span  class="label_class">Date de première échéance</span>  <span style="font-weight: normal;"><?php echo $loandate."-".$databinding[0]->month."-".$databinding[0]->years?></span></td>
                                                    <td style="font-size: 13px; font-weight: bold;"><span  class="label_class">Taux D’Emprunt</span> <span style="font-weight: normal;"><?php echo number_format($amortizationdata[0]['loan_interest'],2)."%";?></span></td>
												</tr>
                                                <tr>
                                                    <td style="font-size: 13px; font-weight: bold;"><span  class="label_class">Taux TVA(TVA)</span> <span style="font-weight: normal;"><?php echo $amortizationdata[0]['tva'] ;?></span></td>
                                                    <td style="font-size: 13px; font-weight: bold;"><span  class="label_class">Périodicité</span> <span style="font-weight: normal;">Mensuelle</span></td>
												</tr>
												<tr>
                                                    <td style="font-size: 13px; font-weight: bold;"><span  class="label_class">Frais de Dossier TTC</span> <span style="font-weight: normal;">

                                                        <?php //echo number_format($loan_details['frais_de_dossier']*1.18,0,',',' ');?>
                                                        
                                                         <?php 

                                                        if($amortizationdata[0]['loan_type'] == "4"){

                                                           // echo $loan_details['loan_amt'];
                                                              if($am->amount <='1000000'){
                                                                    $ht = 42000;
                                                                }else{
                                                                    $ht = 67000;
                                                                }

                                                                 $tcc=$ht*1.18;

                                                                 echo number_format($tcc,0,',',' ');
                                                        }
                                                        else{
                                                             echo number_format($loan_details['frais_de_dossier']*1.18,0,',',' ');
                                                        }

                                                   ?>  


                                                        </span></td>

                                                        <?php if($amortizationdata[0]['loan_type'] == "1"){ ?>
                                                            <td style="font-size: 13px; font-weight: bold;"><span  class="label_class">Frais D’Enregistrement TTC</span> <span style="font-weight: normal;">0 00</span></td>
                                                        <?php  } else if($amortizationdata[0]['loan_type'] == "2") { ?>
                                                             <td style="font-size: 13px; font-weight: bold;"><span  class="label_class">Frais D’Enregistrement TTC</span> <span style="font-weight: normal;">0 00</span></td>
                                                        <?php }else{ ?>
                                                             <td style="font-size: 13px; font-weight: bold;"><span  class="label_class">Frais D’Enregistrement TTC</span> <span style="font-weight: normal;"><?php echo number_format($loan_details['frais_denregistrement_ttc'],0,',',' ');?></span></td>
                                                        <?php } ?>

                                                   
												</tr>
												<tr>
                                                    <td style="font-size: 13px; font-weight: bold;"><span  class="label_class">Prime d'Assurance/Assurance Personnelle</span> <span style="font-weight: normal;"><?php echo $insuranceAmort;?></span></td>
                                                    
												</tr>
                                            </tbody>
                                        </table>
                                    </td>
                                    <td width="15px"></td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table id="customers" style="width: 90%; border-collapse: collapse;margin-top: 4%; padding: 5px 30px 5px 30px; margin: auto; ">
                            <tbody style="">
                                <tr>
                                    <td style="font-size: 11px; font-weight: bold; border: 1px solid #ddd; padding: 5px 8px 5px 8px;width: 10%;">N° D'échéances</td>
                                    <td style="font-size: 11px; font-weight: bold; border: 1px solid #ddd;padding: 5px 8px 5px 8px;width: 10%;">
                                        Capital début période
                                    </td>
                                    <td style="font-size: 11px; font-weight: bold; border: 1px solid #ddd; padding: 5px 8px 5px 8px;width: 10%;">
                                        Capital fin  période
                                    </td>
                                    <td style="font-size: 11px; font-weight: bold; border: 1px solid #ddd;padding: 5px 8px 5px 8px;width: 10%;">
                                        Capital Amorti
                                    </td>
                                    <td style="font-size: 11px; font-weight: bold; border: 1px solid #ddd;padding: 5px 8px 5px 8px;width: 10%;">
                                        Intérêt TTC de la période
                                    </td>
                                    <td style="font-size: 11px; font-weight: bold; border: 1px solid #ddd;padding: 5px 8px 5px 8px;width: 10%;">Intérêt HT</td>
                                    <td style="font-size: 10px; font-weight: bold; border: 1px solid #ddd;padding: 5px 8px 5px 8px;width: 10%;">
                                        TVA Sur Intérêt
                                    </td>
                                    <td style="font-size: 10px; font-weight: bold; border: 1px solid #ddd;padding: 5px 8px 5px 8px;width: 10%;">
                                        CSS
                                    </td>
                                    <td style="font-size: 11px; font-weight: bold; border: 1px solid #ddd;padding: 5px 8px 5px 8px;width: 10%;">Montant De L'échéance
                                    </td>
                                    <td style="font-size: 11px; font-weight: bold; border: 1px solid #ddd;padding: 5px 8px 5px 8px;width: 10%;">Date De L'échéance</td>
                                </tr>

								<?php 
								//$am->postinterest;
								$ebal = $am->amount;
								$ccint =0.0;
								$cpmnt = 0.0;
								//$sum=array();
								$sumofMonthly =0;
								$sumofPrincipal =0;
								$sumofInterestPaidTaxIncl =0;
								$sumofInterestPaidbeforTax =0;
								$sumofVATonInterest=0;
								$MonthlyPayments=0;
								$cdate=$am->cdate;  
								for ($i = 1; $i <= $am->npmts; $i++){
									$bbal = $ebal;    
									$ipmnt = $bbal * $am->mrate;
									$ppmnt = $am->pmnt - $ipmnt;
									$ebal = $bbal - $ppmnt;
									$am->mrate;
									$ccint = $ccint + $ipmnt;
									$cpmnt = $am->pmnt;
									//$pbint = $bbal * $am->postinterest/100/12;
									// $pbint = $bbal*$am->postinterest/100/12;
									// $vbint = $pbint*$amortizationdata[0]['tva']/100; 
									
									// $vbint = $pbint*19.25/100;
									// $months=$am->npmts;
									
									$pbint = $ipmnt / 1.19;
									$vbint = $pbint*$amortizationdata[0]['tva']/100;
									$cssint = $pbint*$amortizationdata[0]['css']/100;
									
									//$vbint = $pbint*$vat_on_interest/100;
									$months=$am->npmts;
									if($i==27){?>
										<tr>
											<td colspan="10">
												<br><br><br><br>
											</td>
										</tr>
										<tr <?php if($i % 2 == 0){ ?> style="background-color: #f2f2f2;" <?php  } ?> >
											<td style="font-size: 12px; border: 1px solid #ddd;padding: 5px 8px 5px 8px;">
												<?php echo $i;?>
											</td>
											 <td style="font-size: 12px; border: 1px solid #ddd;padding: 5px 8px 5px 8px;">
												<?php echo number_format($bbal,0,',',' ') ;?>
											</td>
											 <td style="font-size: 12px; ">
												<?php echo number_format($ebal,0,',',' ');?>
											</td>
											 <td style="font-size: 12px; border: 1px solid #ddd;padding: 5px 8px 5px 8px;">
												<?php echo number_format($ppmnt,0,',',' ') ;?>
											</td>
											 <td style="font-size: 12px; border: 1px solid #ddd;padding: 5px 8px 5px 8px;">
												<?php echo number_format($ipmnt,0,',',' ');?>
											</td>
											 <td style="font-size: 12px; border: 1px solid #ddd;padding: 5px 8px 5px 8px;">
												<?php echo number_format($pbint,0,',',' ');?>
											</td>
											 <td style="font-size: 12px; border: 1px solid #ddd;padding: 5px 8px 5px 8px;">
												<?php echo number_format($vbint,0,',',' ');?>
											</td>
											<td style="font-size: 12px; border: 1px solid #ddd;padding: 5px 8px 5px 8px;">
												<?php echo number_format($cssint,0,',',' ');?>
											</td>
											 <td style="font-size: 12px; border: 1px solid #ddd; padding: 5px 8px 5px 8px;">
												<?php echo number_format($cpmnt,0,',',' ') ;?>
											</td>
											 <td style="font-size: 12px; border: 1px solid #ddd; ">
												<?php echo $loandate."-".date("m", strtotime( $cdate." +$i months"));?><?php echo "-".date("Y", strtotime( $cdate." +$i months"));?>
											</td>
										</tr>
									<?php }
									else{?> 
										<tr <?php if($i % 2 == 0){ ?> style="background-color: #f2f2f2;" <?php  } ?> >
											<td style="font-size: 12px; border: 1px solid #ddd;padding: 5px 8px 5px 8px;">
												<?php echo $i;?>
											</td>
											 <td style="font-size: 12px; border: 1px solid #ddd;padding: 5px 8px 5px 8px;">
												<?php echo number_format($bbal,0,',',' ') ;?>
											</td>
											 <td style="font-size: 12px; ">
												<?php echo number_format($ebal,0,',',' ');?>
											</td>
											 <td style="font-size: 12px; border: 1px solid #ddd;padding: 5px 8px 5px 8px;">
												<?php echo number_format($ppmnt,0,',',' ') ;?>
											</td>
											 <td style="font-size: 12px; border: 1px solid #ddd;padding: 5px 8px 5px 8px;">
												<?php echo number_format($ipmnt,0,',',' ');?>
											</td>
											 <td style="font-size: 12px; border: 1px solid #ddd;padding: 5px 8px 5px 8px;">
												<?php echo number_format($pbint,0,',',' ');?>
											</td>
											 <td style="font-size: 12px; border: 1px solid #ddd;padding: 5px 8px 5px 8px;">
												<?php echo number_format($vbint,0,',',' ');?>
											</td>
											<td style="font-size: 12px; border: 1px solid #ddd;padding: 5px 8px 5px 8px;">
												<?php echo number_format($cssint,0,',',' ');?>
											</td>
											 <td style="font-size: 12px; border: 1px solid #ddd; padding: 5px 8px 5px 8px;">
												<?php echo number_format($cpmnt,0,',',' ') ;?>
											</td>
											 <td style="font-size: 12px; border: 1px solid #ddd; ">
												<?php $new_loan_date =  $loandate."-".date("m", strtotime( $cdate." +$i months"))."-".date("Y", strtotime( $cdate." +$i months"));?>
											    <?php $split_date = explode('-',$new_loan_date);
											         $calcul_last_date = cal_days_in_month(CAL_GREGORIAN, $split_date[1], $split_date[2]);
                                                	    if($split_date[1] == "02"){
                                                	        $prive_val = $calcul_last_date;
                                                	        $prive_txt = "Prive ".$prive_val;
                                                	        
                                                	    }
                                                	    else{
                                                	        $prive_val = '30';
                                                	        $prive_txt = "Prive 30";
                                                	    }
                                                        							    
                                                        							    
                                                    if((($customer_data->cat_employeurs) == "Public Civil 25") || (($customer_data->cat_employeurs) == "Prive 25") || (($customer_data->cat_employeurs) == "Public Corps 25")){
                                                            $ldate= '25';
                                                        }else if((($customer_data->cat_employeurs) == "Prive 20") || (($customer_data->cat_employeurs) == "Autres 20")){
                                                            $ldate='20';
                                                        }
                                                        else if((($customer->cat_employeurs) == $prive_txt) || (($customer->cat_employeurs) == "Organisation internationales")){
                        									$ldate=$prive_val;
                        								}else{
                        								    
                        									$ldate=$prive_val;
                        								}
                        								
                        								echo $ldate."-".$split_date[1]."-".$split_date[2];
											    
											    ?>
											
											</td>
										</tr>
									<?php }
									$sumofMonthly += $cpmnt;
									$sumofPrincipal +=$ppmnt;
									$sumofInterestPaidTaxIncl +=$ipmnt;                     
									$sumofInterestPaidbeforTax +=$pbint;
									$sumofVATonInterest +=$vbint;
									$sumofCSSonInterest +=$cssint;
									$MonthlyPayments +=$cpmnt;
								}?>
								<tr>
									 <td colspan="2" style="font-size: 13px;  border: solid 1px #ddd; padding: 5px; text-align: right; line-height: 18px; border-spacing: 0;">
										<span style="font-weight: bold;">TOTAL</span>
									</td>
									<td style="font-size: 13px; border: solid 1px #ddd; padding: 5px; text-align: left; line-height: 18px; border-spacing: 0;">
										 
									</td>
								   <td style="font-size: 13px; border: solid 1px #ddd; padding: 5px; text-align: left; line-height: 18px; border-spacing: 0;">
										<span style="font-weight: bold;"><?php echo number_format($sumofPrincipal,0,',',' ');?></span>
									</td>
									<td style="font-size: 13px; border: solid 1px #ddd; padding: 5px; text-align: left; line-height: 18px; border-spacing: 0;">
										<span style="font-weight: bold;"><?php echo number_format($sumofInterestPaidTaxIncl,0,',',' ');?></span>
									</td>
									<td style="font-size: 13px; border: solid 1px #ddd; padding: 5px; text-align: left; line-height: 18px; border-spacing: 0;">
										<span style="font-weight: bold;"><?php echo number_format($sumofInterestPaidbeforTax,0,',',' ');?></span>
									</td>
									<td style="font-size: 13px; border: solid 1px #ddd; padding: 5px; text-align: left; line-height: 18px; border-spacing: 0;">
										<span style="font-weight: bold;"><?php echo number_format($sumofVATonInterest,0,',',' ');?></span>
									</td>
									<td style="font-size: 13px; border: solid 1px #ddd; padding: 5px; text-align: left; line-height: 18px; border-spacing: 0;">
										<span style="font-weight: bold;"><?php echo number_format($sumofCSSonInterest,0,',',' ');?></span>
									</td>
									<td style="font-size: 13px; border: solid 1px #ddd; padding: 5px; text-align: left; line-height: 18px; border-spacing: 0;">
										<span style="font-weight: bold;"><?php echo number_format($MonthlyPayments,0,',',' ');?></span>
									</td>
									<td style="font-size: 13px;border: solid 1px #ddd; padding: 5px; text-align: left; line-height: 18px;"></td>
								</tr>
							</tbody> 
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
        <center>
             <style type="text/css">
				@media print {
				  .hidden-print {
					visibility: hidden !important;
				  }
				}
			</style>
            <button class="btn btn-primary hidden-print" id="printPageButton" onclick="myfunction()" style="position: relative;">Print Page</button>
        </center>
    </body>
	<p style="page-break-after: always;">&nbsp;</p>
	<script type="text/javascript">
		function myfunction(){
			window.print();
		}
	</script>
</html>
