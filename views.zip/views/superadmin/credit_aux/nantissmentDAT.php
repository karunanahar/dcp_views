<?php 
$documentArray1 = 0;
if(isset($documentArray))
	$documentArray1 = sizeof($documentArray); 
$customer=(array) json_decode($appformD['customer_data']); 
$databinding=(array) json_decode($appformD['databinding']); 

$convert=new ConvertNumberToText();
?>

<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8"/>

	<style type="text/css">
		@page { size: 8.27in 11.69in; margin-left: 0.39in; margin-right: 0.39in; margin-top: 0.2in; margin-bottom: 0.49in }
		p { line-height: 100%; text-align: justify; orphans: 2; widows: 2; margin-bottom: 0in; direction: ltr; background: transparent }
		p.western { font-family: "Tahoma", serif; font-size: 10pt }
		p.cjk { font-family: "Times New Roman"; font-size: 10pt }
		p.ctl { font-family: "Times New Roman"; font-size: 12pt }
		a.sdfootnoteanc { font-size: 57% }
	</style>
</head>
<body lang="fr-FR" link="#000080" vlink="#800000" dir="ltr">
<div id="TextSection" dir="ltr">
    <img src="<?php echo  base_url(); ?>/assets/logo2.png" style="width: 40px;" />
	<center>
		<table width="527" cellpadding="7" cellspacing="0" style="page-break-before: always">
			<col width="511"/>

			<tr>
				<td width="511" style="border-top: 1.00pt solid #000000; border-bottom: 2.25pt solid #000000; border-left: 1.00pt solid #000000; border-right: 1.00pt solid #000000; padding: 0in 0.08in"><p class="western" align="center" style="orphans: 0; widows: 0">
					<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font face="Candara, serif"><font size="4" style="font-size: 14pt"><b>CONVENTION
					DE NANTISSEMENT DE COMPTE DEPOT A TERME</b></font></font></font></font></p>
					<p class="western" align="center" style="orphans: 0; widows: 0"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font face="Candara, serif"><font size="1" style="font-size: 8pt"><b>(PERSONNE
					PHYSIQUE)</b></font></font></font></font></p>
				</td>
			</tr>
		</table>
	</center>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt"><u><b>ENTRE
	LES SOUSSIGNE(E)S&nbsp;:</b></u></font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<br/>

	</p>
	<table width="708" cellpadding="7" cellspacing="0">
		<col width="692"/>

		<tr>
			<td width="692" valign="top" style="border: 1px solid #000000; padding: 0in 0.08in"><p class="western" align="justify" style="orphans: 2; widows: 2; margin-right: 0.1in; margin-top: 0.08in"><a name="permission-for-group:96149505:everyone"></a><a name="permission-for-group:1712722233:everyone"></a><a name="permission-for-group:263920081:everyone"></a><a name="permission-for-group:695082133:everyone"></a>
				<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="1" style="font-size: 8pt">La
				</font><font size="1" style="font-size: 8pt"><b>BANQUE
				INTERNATIONALE POUR LE COMMERCE ET L’INDUSTRIE DU GABON</b></font><font size="1" style="font-size: 8pt">
				en abrégé «</font><font size="1" style="font-size: 8pt"><b>BICIG</b></font><font size="1" style="font-size: 8pt">»,
				Société Anonyme avec Conseil d’Administration, au capital de
				18.000.000.000 (dix-huit milliards) de F.CFA dont le siège
				social est à Libreville, 714 Avenue du Colonel Parant, boite
				postale 2241, immatriculée au Registre du Commerce et du Crédit
				Mobilier de ladite ville sous le numéro 2002 B 01732, identifiée
				fiscalement sous le numéro 790 027 A, inscrite sur la liste
				banques sous le numéro 40001 et dont l’adresse électronique
				est bicignet@bicig.ga, représentée par _____________________ et
				______________, agissant respectivement en qualité de
				________________ et de  __________________________,</font></font></font></p>
				<p class="western" align="right" style="orphans: 2; widows: 2; margin-right: 0.1in; margin-top: 0.08in">
				 <font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="1" style="font-size: 8pt">Ci-après
				désignée la&nbsp;«&nbsp;</font><font size="1" style="font-size: 8pt"><b>BANQUE</b></font><font size="1" style="font-size: 8pt">&nbsp;»
				ou le «&nbsp;</font><font size="1" style="font-size: 8pt"><b>BENEFICIAIRE</b></font><font size="1" style="font-size: 8pt">&nbsp;»,</font></font></font></p>
			</td>
		</tr>
	</table>
	<p class="western" align="right" style="line-height: 100%; margin-right: 0.1in; margin-top: 0.08in"><a name="OLE_LINK2"></a><a name="OLE_LINK1"></a>
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="1" style="font-size: 8pt"><b>D’UNE
	PART,</b></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-right: 0.1in; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="1" style="font-size: 8pt"><b>ET&nbsp;:</b></font></font></font></p>
	<table width="709" cellpadding="7" cellspacing="0">
		<col width="693"/>

		<tr>
			<td width="693" valign="top" style="border: 1px solid #000000; padding: 0in 0.08in"><p class="western" align="justify" style="orphans: 2; widows: 2; margin-right: 0.1in"><a name="permission-for-group:1007187366:everyone"></a>
				<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font face="Arial Narrow, serif"><font size="1" style="font-size: 8pt"><b>M/Mme
				_____________________________________________________________________________________________________________________</b></font></font></font></font></p>
				<p class="western" align="justify" style="orphans: 2; widows: 2; margin-right: 0.1in"><a name="permission-for-group:1721187380:everyone"></a><a name="permission-for-group:2135689946:everyone"></a><a name="permission-for-group:1619676884:everyone"></a><a name="permission-for-group:1415530152:everyone"></a>
				<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font face="Arial Narrow, serif"><font size="1" style="font-size: 8pt">Né
				le ___________________________ à _________________________ de
				_____________________________ et de __________________________</font></font></font></font></p>
				<p class="western" align="justify" style="orphans: 2; widows: 2; margin-right: 0.1in"><a name="permission-for-group:2127369403:everyone"></a><a name="permission-for-group:1353794829:everyone"></a><a name="permission-for-group:1755338443:everyone"></a><a name="permission-for-group:1090131253:everyone"></a><a name="permission-for-group:346191202:everyone"></a><a name="permission-for-group:646728092:everyone"></a><a name="permission-for-group:177210381:everyone"></a>
				<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font face="Arial Narrow, serif"><font size="1" style="font-size: 8pt">Demeurant
				à __________________________&nbsp;; Contact téléphonique&nbsp;:
				__________________________ Fonction&nbsp;:
				________________________ Employeur&nbsp;:
				____________________________________________ BP&nbsp;:
				__________, _____________________&nbsp;; Matricule
				______________________ </font></font></font></font>
				</p>
				<p class="western" align="justify" style="orphans: 2; widows: 2; margin-right: 0.1in"><a name="permission-for-group:930245960:everyone"></a><a name="permission-for-group:2035176863:everyone"></a><a name="permission-for-group:2141352557:everyone"></a><a name="permission-for-group:1383609062:everyone"></a>
				<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font face="Arial Narrow, serif"><font size="1" style="font-size: 8pt">Titre
				d’Identification&nbsp;: </font></font><font face="Arial Narrow, serif"><font size="1" style="font-size: 8pt">______________
				; N° _________________________ délivré(e) le
				__________________ à  _______________________</font></font></font></font></p>
				<p class="western" align="right" style="orphans: 2; widows: 2; margin-right: 0.1in">
				<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font face="Arial Narrow, serif"><font size="1" style="font-size: 8pt"><i>Ci-dénommé(e)
				‘‘&nbsp;</i></font></font><font face="Arial Narrow, serif"><font size="1" style="font-size: 8pt"><i><b>l’EMPRUNTEUR’’</b></i></font></font><font face="Arial Narrow, serif"><font size="1" style="font-size: 8pt"><i>
				d’autre part&nbsp;;</i></font></font></font></font></p>
			</td>
		</tr>
	</table>
	<p class="western" align="justify" style="line-height: 100%; margin-right: 0.1in; margin-top: 0.08in">
	<br/>

	</p>
	<p class="western" align="right" style="line-height: 100%; margin-right: 0.1in; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="1" style="font-size: 8pt"><b>D’AUTRE
	PART.</b></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="1" style="font-size: 8pt">La
	BANQUE et le CONSTITUANT étant ci-après désignés
	individuellement la «&nbsp;</font><font size="1" style="font-size: 8pt"><b>Partie</b></font><font size="1" style="font-size: 8pt">&nbsp;»
	et collectivement les «&nbsp;</font><font size="1" style="font-size: 8pt"><b>Parties</b></font><font size="1" style="font-size: 8pt">&nbsp;»,</font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-left: 0.25in; margin-right: 0.1in; margin-top: 0.08in">
	<br/>

	</p>
	<p class="western" align="left" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt"><u><b>IL
	A ETE PREALABLEMENT EXPOSE CE QUI SUIT&nbsp;:</b></u></font></font></font></font></p>
	<p class="western" align="center" style="line-height: 100%; margin-top: 0.08in">
	<br/>

	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in"><a name="_Hlk133581502"></a><a name="permission-for-group:697055279:everyone"></a>
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="1" style="font-size: 8pt">Le
	CONSTITUANT a sollicité et obtenu de la BANQUE un  ___________ </font></font></font>
	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in"><a name="permission-for-group:286529267:everyone"></a>
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="1" style="font-size: 8pt">En
	garantie du remboursement</font><font color="#000000"><font size="1" style="font-size: 8pt">
	du Crédit sus-rappelé</font></font><font size="1" style="font-size: 8pt">,
	le CONSTITUANT a accepté d’affecter en nantissement au profit de
	la BANQUE, </font><font color="#000000"><font size="1" style="font-size: 8pt">les
	créances</font></font><font size="1" style="font-size: 8pt">
	disponibles sur le (s) compte (s) numéro _______________ ouvert
	dans les livres de la BANQUE à son nom. </font></font></font>
	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">La
	BANQUE s’y étant disposée, les Parties se sont rapprochées pour
	matérialiser leur accord dans les termes de la présente Convention
	de nantissement, notamment en conformité avec les dispositions de
	l’Acte Uniforme OHADA portant organisation des sûretés, avec
	laquelle ce préambule forme un tout indivisible&nbsp;: </font></font></font></font>
	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<br/>

	</p>
	<p class="western" align="left" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt"><u><b>CECI
	EXPOSE, IL A ETE CONVENU ET ARRETE CE QUI SUIT&nbsp;:</b></u></font></font></font></font></p>
	<p class="western" align="center" style="line-height: 100%; margin-top: 0.08in">
	<br/>

	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<br/>

	</p>
</div>
<div id="Section1" dir="ltr" gutter="19" style="column-count: 2"><p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt"><b>ARTICLE
	1 : DEFINITIONS ET INTERPRETATION</b></font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt"><b>1.1.	Définitions</b></font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Sauf
	stipulation expresse contraire dans la présente Convention, en plus
	des mots et des expressions déjà définis dans le préambule, les
	termes et expressions suivants auront le sens qui leur est donné
	ci-dessous :</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">«&nbsp;</font></font><font color="#000000"><font size="1" style="font-size: 8pt"><b>Acte
	Uniforme OHADA sur les Sûretés&nbsp;»</b></font></font><font color="#000000"><font size="1" style="font-size: 8pt">
	désigne l'Acte Uniforme OHADA portant organisation des sûretés
	adopté le 15 décembre 2010 ;</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">«&nbsp;</font></font><font color="#000000"><font size="1" style="font-size: 8pt"><b>Convention</b></font></font><font color="#000000"><font size="1" style="font-size: 8pt">&nbsp;»
	désigne la présente Convention de nantissement&nbsp;;</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in"><a name="permission-for-group:1752325318:everyone"></a><a name="_Hlk69974499"></a>
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">«&nbsp;</font></font><font color="#000000"><font size="1" style="font-size: 8pt"><b>Convention
	de Compte Courant</b></font></font><font color="#000000"><font size="1" style="font-size: 8pt">&nbsp;»
	désigne la convention portant ouverture du compte bancaire numéro
	_____________________ dans les livres de la BANQUE au nom du
	CONSTITUANT destiné à la mise à disposition et au remboursement
	du Crédit&nbsp;;</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in"><a name="_Hlk69137918"></a><a name="permission-for-group:551904533:everyone"></a>
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">«&nbsp;</font></font><font color="#000000"><font size="1" style="font-size: 8pt"><b>Compte
	Dépôt à Terme ou Compte DAT&nbsp;»</b></font></font><font color="#000000"><font size="1" style="font-size: 8pt">
	désigne le(s) compte(s) bancaire(s) numéro ___________ouvert par
	le CONSTITUANT dans les livres de la BANQUE et dont la somme a été
	bloquée pour une durée de [(</font></font><font color="#000000"><font size="1" style="font-size: 8pt"><i><b>préciser
	la durée du DAT</b></i></font></font><font color="#000000"><font size="1" style="font-size: 8pt">)]
	moyennant des intérêts, suivant la convention de DAT signée entre
	les Parties&nbsp;;</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in"><a name="permission-for-group:291445454:everyone"></a>
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">«&nbsp;</font></font><font color="#000000"><font size="1" style="font-size: 8pt"><b>Compte
	Nanti&nbsp;»</b></font></font><font color="#000000"><font size="1" style="font-size: 8pt">
	fait référence au Compte DAT n° [____________] dont les sommes
	sont rendues indisponibles à hauteur d‘un montant déterminé
	d’accord Parties, en garantie du Crédit consenti au profit du
	DEBITEUR&nbsp;;</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font color="#000000"> <font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="1" style="font-size: 8pt">«&nbsp;</font></font><font color="#000000"><font size="1" style="font-size: 8pt"><b>Créances
	Garanties</b></font></font><font color="#000000"><font size="1" style="font-size: 8pt">&nbsp;»
	ou «&nbsp;</font></font><font color="#000000"><font size="1" style="font-size: 8pt"><b>Obligations
	Garanties</b></font></font><font color="#000000"><font size="1" style="font-size: 8pt">&nbsp;»
	désigne toutes sommes en principal, intérêts, intérêts de
	retard, frais, commissions et accessoires, de toute nature,
	présentes ou à venir, dues ou encourues par le CONSTITUANT envers
	le BENEFICIAIRE aux termes des Documents de Financement, tels que
	modifiés par tout avenant, dans tous les cas, que ces dettes et
	obligations soient dues par anticipation ou autrement, qu’elles
	soient expresses ou implicites, dues initialement au BENEFICIAIRE ou
	dues par transfert à ce dernier par quelque moyen que ce soit,
	qu'elles aient été encourues en tant que débiteur principal,
	caution ou autrement et qu’elles soient libellées en Francs CFA,
	en Euros, en Dollars US ou dans toute autre devise (étant précisé
	que les Obligations Garanties au titre des Documents de Financement,
	à la date de la présente Convention comprennent notamment les
	obligations décrites dans la Convention de Compte Courant) ;</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">«&nbsp;</font></font><font color="#000000"><font size="1" style="font-size: 8pt"><b>Créances
	Nanties</b></font></font><font color="#000000"><font size="1" style="font-size: 8pt">&nbsp;»
	a le sens donné à ce terme à l’Article 4 ci-dessous&nbsp;;</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in"><a name="_Hlk77876995"></a><a name="permission-for-group:1680296833:everyone"></a>
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">«&nbsp;</font></font><font color="#000000"><font size="1" style="font-size: 8pt"><b>Crédit&nbsp;»</b></font></font><font color="#000000"><font size="1" style="font-size: 8pt">&nbsp;
	désigne le __________ d’un montant total de</font></font><font size="1" style="font-size: 8pt"><b>_____________
	(_____________) de F.CFA</b></font><font color="#4f81bd"><font size="1" style="font-size: 8pt"><b>
	</b></font></font><font color="#000000"><font size="1" style="font-size: 8pt">consenti
	au profit du CONSTITUANT ; </font></font></font></font>
	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">«&nbsp;</font></font><font color="#000000"><font size="1" style="font-size: 8pt"><b>Documents
	de Financement&nbsp;»</b></font></font><font color="#000000"><font size="1" style="font-size: 8pt">
	désigne la convention de Compte Courant, le présent document de
	Sûreté, la lettre de demande de financement, tout Avis de Tirage,
	tout billet à ordre souscrit par le CONSTITUANT, tout autre
	document de Sûreté, ainsi que tout document requis pour le Crédit
	tels que définis par la Convention de Compte Courant et tout autre
	document désigné comme tel par La BANQUE et le CONSTITUANT ;</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">«&nbsp;</font></font><font color="#000000"><font size="1" style="font-size: 8pt"><b>Nantissement&nbsp;»</b></font></font><font color="#000000"><font size="1" style="font-size: 8pt">
	a le sens donné à ce terme à l'Article 3 ci-dessous ;</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">«&nbsp;</font></font><font color="#000000"><font size="1" style="font-size: 8pt"><b>OHADA</b></font></font><font color="#000000"><font size="1" style="font-size: 8pt">&nbsp;»
	désigne l'Organisation pour l'Harmonisation en Afrique du Droit des
	Affaires, instituée par le Traité de Port Louis en date du 17
	octobre 1993 révisé par le Traité de Québec du 17 octobre 2008 ;</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">«&nbsp;</font></font><font color="#000000"><font size="1" style="font-size: 8pt"><b>Période
	de Garantie&nbsp;</b></font></font><font color="#000000"><font size="1" style="font-size: 8pt">»
	désigne la période débutant à la date de la  présente
	Convention et finissant à la date à laquelle la BANQUE aura
	notifié au CONSTITUANT que toutes les Obligations Garanties ont été
	intégralement et irrévocablement payées et que le BENEFICIAIRE
	n’a plus aucun engagement au titre des Documents de Financement ;</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">«&nbsp;</font></font><font color="#000000"><font size="1" style="font-size: 8pt"><b>RCCM&nbsp;</b></font></font><font color="#000000"><font size="1" style="font-size: 8pt">»
	signifie le Registre du Commerce et du Crédit Mobilier ;</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">«&nbsp;</font></font><font color="#000000"><font size="1" style="font-size: 8pt"><b>Sûretés&nbsp;</b></font></font><font color="#000000"><font size="1" style="font-size: 8pt">»
	désigne les Sûretés Personnelles et les Sûretés Réelles ;</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">«&nbsp;</font></font><font color="#000000"><font size="1" style="font-size: 8pt"><b>Sûreté
	Personnelle&nbsp;</b></font></font><font color="#000000"><font size="1" style="font-size: 8pt">»
	désigne tout cautionnement, aval, garantie autonome ou autre sûreté
	personnelle ou garantie mis en place en garantie de dettes ou
	d'emprunts présents ou futurs ; et </font></font></font></font>
	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">«&nbsp;</font></font><font color="#000000"><font size="1" style="font-size: 8pt"><b>Sûreté
	Réelle</b></font></font><font color="#000000"><font size="1" style="font-size: 8pt">&nbsp;»
	désigne tout gage, hypothèque, nantissement, privilège,
	servitude, ou autre sûreté réelle ou droit sur les actions,
	autres titres, biens, revenus et droits, présents ou futurs mis en
	place en garantie de dettes ou d’emprunts présents ou futurs.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt"><b>1.2.	Interprétation
	</b></font></font></font></font>
	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Dans
	la présente Convention, toute référence à la «&nbsp;Convention
	de Compte Courant&nbsp;» s'entend de la Convention de crédit en
	compte courant telle que modifiée par tout avenant. De même :</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Toute
	référence à un «&nbsp;Document de Financement&nbsp;» s'entend
	de ce Document de Financement tel que modifié par tout avenant.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Sauf
	stipulations contraires, les termes non définis aux présentes et
	portant une majuscule auront la même signification que celle qui
	leur est donnée dans la Convention de Compte Courant.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Les
	références à toute partie à la présente Convention doivent être
	considérées, le cas échéant, comme des références à ou
	inclure, leurs cessionnaires, successeurs et /ou ayants droits.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt"><b>ARTICLE
	2 : OBJET ET EFFETS DU NANTISSEMENT  </b></font></font></font></font>
	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt"><b>2.1.	Objet
	du Nantissement</b></font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in"><a name="permission-for-group:279249039:everyone"></a>
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Le
	CONSTITUANT nantit irrévocablement le Compte DAT n°__________, au
	profit de la BANQUE, conformément aux dispositions de l’Acte
	Uniforme OHADA sur les Sûretés. Ce Nantissement vise à garantir
	le paiement des Créances Garanties telles que désignées
	ci-dessous.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt"><b>2.2.	Effets
	du Nantissement</b></font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Le
	Nantissement résultant de la présente Convention aura notamment
	pour effet de rendre inopérante toute action ou saisie effectuée
	par tous tiers sur le Compte Nanti. </font></font></font></font>
	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Le
	Nantissement constitué au titre de la présente Convention
	s’ajoutera à toutes Sûretés dont bénéficie la BANQUE, et ne
	pourra en aucun cas porter atteinte, ni être compromis ou affecté,
	par lesdites Sûretés.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Le
	CONSTITUANT renonce à se prévaloir des droits dont il pourrait
	être investi aux fins d’exiger de la BANQUE qu’elle procède ou
	exerce toute Sûreté à l’encontre de toute autre personne avant
	de procéder à l’exercice des droits constitués aux termes de la
	présente Convention et de tout droit qu’il pourrait avoir
	d’exiger que la BANQUE exerce ses droits dans un ordre spécifique
	au titre de la présente Convention. </font></font></font></font>
	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Le
	présent Nantissement ne fait pas novation, mais s’ajoute à tous
	les autres privilèges, garanties et sûretés que le CONSTITUANT,
	ou tout tiers, a consenti ou pourra consentir à la BANQUE au titre
	des Créances Garanties.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Le
	Nantissement s’ajoute aux Sûretés Personnelles ou Réelles qui
	ont pu ou qui pourraient être fournies, soit par le CONSTITUANT,
	soit par tout tiers.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt"><b>ARTICLE
	3&nbsp;: DESIGNATION DES CREANCES GARANTIES</b></font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Le
	présent Nantissement est affecté en garantie et sureté de toutes
	les </font></font><font color="#000000"><font size="1" style="font-size: 8pt">sommes
	que le </font></font><font size="1" style="font-size: 8pt">CONSTITUANT
	</font><font color="#000000"><font size="1" style="font-size: 8pt">doit,
	peut ou pourra devoir à la BANQUE en raison de tous engagements, de
	toutes opérations et d’une façon générale, de toutes les
	obligations nées, sans aucune exception, directement ou
	indirectement à l’égard de la BANQUE pour quelque cause que ce
	soit. En sont compris&nbsp;: </font></font></font></font>
	</p>
	<ul>
		<li><p align="justify" style="margin-top: 0.08in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font color="#000000"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">tous
		crédits par caisse ou par signature, des soldes exigibles en
		faveur de la BANQUE de tous comptes courants ouverts au nom du
		CONSTITUANT, des opérations de bourse traitées par lui, de tous
		chèques, billets ou effets comportant sa signature à quelque
		titre que ce soit et pour lesquels la BANQUE aura été dispensée
		ou non de tout protêt ou de tout avis de non-paiement, des
		négociations de lettres de change relevé, d’actes de cession de
		créances, de tous engagements d’aval, de caution ou de garantie
		de paiement fournis par le CONSTITUANT&nbsp;;</font></font></font></font></font></p>
		<li><p align="justify" style="margin-top: 0.08in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font color="#000000"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">tous
		engagements d’avals, de caution, de garantie ou de contre
		garantie ou encore de toute acceptation données par la BANQUE pour
		le compte du CONSTITUANT ou sur son ordre, et</font></font></font></font></font></p>
		<li><p align="justify" style="margin-top: 0.08in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font color="#000000"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">notamment
		le (s) Crédit (s) suivant&nbsp;:</font></font></font></font></font></p>
	</ul>
	<p class="western" align="left" style="line-height: 100%"><br/>

	</p>
	<p class="western" align="left" style="line-height: 100%"><a name="_Hlk58328320"></a>
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Nature	:
	_____________________________________</font></font></font></font></p>
	<p class="western" align="left" style="line-height: 100%"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Objet	:
	_____________________________________</font></font></font></font></p>
	<p class="western" align="left" style="line-height: 100%"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">N°
	de compte	:______________________________________</font></font></font></font></p>
	<p class="western" align="left" style="line-height: 100%"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Montant	:
	_________________________________ F CFA</font></font></font></font></p>
	<p class="western" align="left" style="line-height: 100%"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Echéance	:
	_____________________________________</font></font></font></font></p>
	<p class="western" align="left" style="line-height: 100%"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Taux
	d’intérêts	: _______________ HT par mois/trimestre (</font></font><font color="#000000"><font size="1" style="font-size: 8pt"><i><b>à
	préciser</b></i></font></font><font color="#000000"><font size="1" style="font-size: 8pt">).</font></font></font></font></p>
	<p class="western" align="left" style="line-height: 100%"><a name="permission-for-group:1944085029:everyone"></a>
	<font color="#000000"> </font>
	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt"><b>ARTICLE
	4&nbsp;: DESIGNATION DES CREANCES NANTIES</b></font></font></font></font></p>
	<ul>
		<li><p align="justify" style="margin-top: 0.08in"><a name="_Hlk108691060"></a><a name="permission-for-group:981936088:everyone"></a>
		<font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font color="#000000"><font size="1" style="font-size: 8pt">Tous
		droits détenus par le CONSTITUANT sur toutes sommes versées au
		crédit du (des) Compte(s) DAT n° [___________], ouvert dans les
		livres de la BANQUE, sont automatiquement compris dans l’assiette
		du Nantissement.</font></font></font></font></p>
	</ul>
	<p align="justify" style="margin-left: 0.5in; margin-top: 0.08in"><br/>

	</p>
	<ul>
		<li><p align="justify" style="margin-top: 0.08in"><a name="permission-for-group:2035576585:everyone"></a>
		<font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font color="#000000"><font size="1" style="font-size: 8pt">L’assiette
		du Nantissement portera sur la (les) somme (s) de </font></font><font color="#000000"><font size="1" style="font-size: 8pt"><b>_____________
		(_____________) de F.CFA.</b></font></font></font></font></p>
	</ul>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in"><a name="permission-for-group:1430092913:everyone"></a><a name="_Hlk108690993"></a>
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Etant
	indiqué que ledit (lesdits) compte (s) présente (nt) à ce jour un
	(des) solde (s) créditeur de </font></font><font color="#000000"><font size="1" style="font-size: 8pt"><b>_____________
	(_____________) de F.CFA  </b></font></font></font></font>
	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<br/>

	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Tant
	qu’une somme quelconque restera due par le CONSTITUANT à la
	BANQUE au titre du Crédit consenti, le Compte Nanti demeurera comme
	tel en faveur de la BANQUE, et son solde ne pourra être payé par
	la BANQUE que dans les conditions définies par les Parties.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Conformément
	aux dispositions de l’Acte Uniforme OHADA sur les Sûretés, la
	BANQUE s'engage à bloquer et conserver toutes sommes inscrites au
	crédit du Compte Nanti, dans la limite des Créances Garanties. </font></font></font></font>
	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt"><b>ARTICLE
	5 : FORMALITES D'INSCRIPTION ET DE RENOUVELLEMENT DU NANTISSEMENT –
	FRAIS, DROITS ET TAXES</b></font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt"><b>5.1.
	Formalités d’inscription et de renouvellement du Nantissement</b></font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">La
	BANQUE procèdera, aux frais du CONSTITUANT qui s’y engage, à
	toutes les formalités nécessaires à la constitution, à la
	validité, à l’opposabilité et à l’efficacité du
	Nantissement, notamment par son inscription auprès du RCCM
	compétent.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">La
	BANQUE procèdera en outre, à tout moment pendant la durée de la
	convention, aux frais du CONSTITUANT qui s’y engage, autant que
	nécessaire, au renouvellement de l’inscription du Nantissement
	objet de la Convention, et à toute autre formalité nécessaire
	pour en assurer à tout moment la validité, l’opposabilité et
	l’efficacité dans les conditions et délais légaux en vigueur.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in"><a name="_Hlk68087576"></a>
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">De
	convention expresse, conformément aux dispositions de l’Acte
	Uniforme OHADA sur les Sûretés, l’inscription du Nantissement
	conservera les droits de la BANQUE pendant une durée de Dix (10)
	ans et tant que le CONSTITUANT sera susceptible de devoir une
	quelconque somme.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Tous
	pouvoirs sont donnés au porteur d’un original, d’une copie ou
	d’un extrait de la Convention pour l’accomplissement de toute
	formalité conformément aux dispositions légales.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt"><b>5.2.
	Frais, droits et taxes</b></font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Le
	CONSTITUANT prend à sa charge les impôts, droits, taxes et autres
	frais liés à la conclusion et à l’exécution de la présente
	Convention ; notamment ceux qui sont liés à son enregistrement, et
	autorise la BANQUE à débiter son Compte Courant pour le règlement
	desdits frais.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">La
	BANQUE fait son affaire de l’accomplissement des formalités
	d’enregistrement.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt"><b>ARTICLE
	6 : DECLARATIONS, GARANTIES ET ENGAGEMENTS</b></font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Le
	CONSTITUANT déclare à la BANQUE ce qui suit :</font></font></font></font></p>
	<ul>
		<li><p align="justify" style="margin-top: 0.08in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font color="#000000"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">il
		détient tous les droits sur les Créances Nanties et a la pleine
		capacité pour jouir desdits droits et d’en disposer ainsi que de
		signer et exécuter la présente Convention&nbsp;;</font></font></font></font></font></p>
		<li><p align="justify" style="margin-top: 0.08in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font color="#000000"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">le
		Compte Nanti n’a fait l’objet d’aucune cession ou délégation
		ni d’aucune affectation en nantissement autre que celle consentie
		par les présentes et  n’est sont frappé à ce jour d’aucune
		opposition. En conséquence, le présent Nantissement sera inscrit
		en 1er rang au Registre du Commerce et di Crédit Mobilier
		compétent&nbsp;;</font></font></font></font></font></p>
		<li><p align="justify" style="margin-top: 0.08in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font color="#000000"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">il
		est suffisamment informé des effets du Nantissement consenti, et
		s'y engage librement et sans contrainte&nbsp;;</font></font></font></font></font></p>
		<li><p align="justify" style="margin-top: 0.08in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font color="#000000"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">il
		a, de son plein gré, consenti à nantir le Compte Nanti au profit
		de la BANQUE, à charge pour celle-ci d'exercer ses droits et
		privilèges jusqu'à l'extinction des Créances Garanties&nbsp;;</font></font></font></font></font></p>
		<li><p align="justify" style="margin-top: 0.08in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font color="#000000"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">Il
		comprend que la BANQUE peut être amenée à utiliser des données
		à caractère personnel telles que précisées à l’article 11
		ci-dessous, et donne son consentement pour l’éventuel
		transmission à des tiers&nbsp;;</font></font></font></font></font></p>
		<li><p align="justify" style="margin-top: 0.08in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font color="#000000"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">le
		cas échéant, il a obtenu toutes les autorisations et agréments
		requis pour la conclusion de la présente Convention.</font></font></font></font></font></p>
	</ul>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Le
	CONSTITUANT s'engage, pendant toute la durée de la Convention et
	jusqu’à la date de libération consécutive à l’extinction de
	ses engagements, à :</font></font></font></font></p>
	<ul>
		<li><p align="justify" style="margin-top: 0.08in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font color="#000000"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">ne
		pas céder, transférer ou autrement disposer, ou permettre ou
		consentir que soit cédé, transféré ou qu'il soit disposé du
		Compte Nanti, du Solde, ou de l'un quelconque de ses droits y
		afférents, au bénéfice d'une autre partie que la BANQUE sans
		l'accord préalable et écrit de cette dernière ;</font></font></font></font></font></p>
		<li><p align="justify" style="margin-top: 0.08in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font color="#000000"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">signer
		et produire tous les actes nécessaires à la validité, au
		maintien de la validité, à l’efficacité et à l’opposabilité
		du Nantissement et, notamment, tout acte qui s’avèrerait
		nécessaire pour effectuer toute formalité au RCCM compétent ;</font></font></font></font></font></p>
		<li><p align="justify" style="margin-top: 0.08in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font color="#000000"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">supporter
		sur simple demande de la BANQUE, l'ensemble des dépenses et frais
		raisonnables, y compris sans caractère limitatif, les frais de
		conseils que la BANQUE aurait exposé au titre de la Convention ou
		à l'occasion de la constitution, défense, préservation ou de la
		réalisation du Nantissement ; </font></font></font></font></font>
		</p>
		<li><p align="justify" style="margin-top: 0.08in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font color="#000000"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">maintenir
		le Compte Nanti ouvert dans les livres de la BANQUE aussi longtemps
		que l’intégralité des Obligations Garanties ne sera pas
		éteinte&nbsp;;</font></font></font></font></font></p>
		<li><p align="justify" style="margin-top: 0.08in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font color="#000000"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">ne
		pas consentir, sauf accord préalable écrit de la BANQUE, une
		Sûreté (autre que le Nantissement ci-constaté), un privilège ni
		autre droit sur le Compte DAT, ni permettre qu’un privilège, une
		Sûreté ou un autre droit soit pris ou inscrit sur le Compte Nanti
		et le Solde ;</font></font></font></font></font></p>
		<li><p align="justify" style="margin-top: 0.08in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font color="#000000"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">sous
		réserve des lois applicables, à ne pas consentir à ce qu'une
		personne autre que la BANQUE exerce une réclamation ou autre
		demande à l'égard d'une somme figurant sur le Compte Nanti ou à
		l'égard du Solde&nbsp;;</font></font></font></font></font></p>
		<li><p align="justify" style="margin-top: 0.08in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font color="#000000"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">ne
		rien faire ni entreprendre une quelconque action ayant, ou
		susceptible d'avoir un effet défavorable sur le Nantissement ou
		les droits de la BANQUE, ou qui serait de quelque manière que ce
		soit incompatible avec le Nantissement ou le remettrait en cause&nbsp;;</font></font></font></font></font></p>
	</ul>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">La
	BANQUE s'engage de manière diligente&nbsp;à : </font></font></font></font>
	</p>
	<ul>
		<li><p align="justify" style="margin-top: 0.08in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font color="#000000"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">rendre
		compte au CONSTITUANT des encaissements effectués conformément à
		la convention de Crédit&nbsp;;</font></font></font></font></font></p>
		<li><p align="justify" style="margin-top: 0.08in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font color="#000000"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">donner
		mainlevée du Nantissement dès lors que toutes les sommes dues au
		titre des Obligations Garanties auront été intégralement
		remboursées ou payées.</font></font></font></font></font></p>
	</ul>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt"><b>ARTICLE
	7 : REALISATION DU NANTISSEMENT</b></font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">La
	BANQUE est fondée à exercer sur le Nantissement, dans la limite
	des Obligations Garanties, les droits qui lui sont conférés en sa
	qualité de créancier nanti, dans les conditions et limites de
	l'Acte Uniforme OHADA sur les Sûretés. </font></font></font></font>
	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">A
	défaut de paiement de l’une quelconque des Créances Garanties
	par le CONSTITUANT, la BANQUE pourra exercer sur le Compte DAT tous
	les droits, actions et privilèges dont elle est investie en vertu
	de la Convention, sans préjudice de tout autre droit ou action qui
	pourrait être exercé ou engagé indépendamment ou concurremment,
	et, notamment poursuivre la réalisation du Nantissement,
	conformément aux dispositions légales. </font></font></font></font>
	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">La
	BANQUE deviendra de plein droit propriétaire du Compte DAT en cas
	d’impayés dans le remboursement des Créances Garanties, huit (8)
	jours après une mise en demeure de payer adressée au CONSTITUANT
	et demeurée sans effet, ce, sans avoir à épuiser préalablement
	les autres recours dont elle pourrait disposer, ni à mettre en
	œuvre d’autres Sûretés ou garanties dont elle pourrait
	bénéficier par ailleurs.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Conformément
	à l’article 134 de l’Acte Uniforme, la Banque aura la faculté,
	à tout moment, de percevoir le Solde par débit du Compte Nanti et
	de l'affecter au paiement de toute somme exigible au titre des
	Obligations Garanties.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">A
	cet effet, le Constituant autorise à tout moment, le Bénéficiaire
	à débiter ledit Compte Nanti en vue du remboursement des sommes
	dues.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt"><b>ARTICLE
	8 : ENTREE EN VIGUEUR - DUREE - MAINLEVEE</b></font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">La
	présente Convention de Nantissement prend effet à compter de sa
	signature et demeurera en vigueur en toutes ses stipulations jusqu'à
	la prise d’effet de la mainlevée.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">La
	mainlevée du Nantissement est effectuée par la BANQUE ou par le
	Constituant suite à la remise d’une attestation de remboursement
	des Créances Garanties et prend effet le deuxième jour ouvrable
	suivant celui de la réception du document l’en informant.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">La
	mainlevée ou toute attestation délivrée à cette fin, permettra
	au CONSTITUANT de recouvrer la pleine possession de ses droits, et
	notamment, de poursuivre la radiation de l’inscription au RCCM à
	ses frais.&nbsp; </font></font></font></font>
	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">A
	cet effet, il est précisé qu’à l’échéance du Compte DAT,
	celui-ci sera, sans nouvelles instructions du CONSTITUANT, renouvelé
	en principal et intérêts </font></font><font color="#000000"><font size="1" style="font-size: 8pt">et
	demeurera Nanti tant que les engagements du DEBITEUR envers la
	BANQUE ne seront pas intégralement éteints.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt"><b>ARTICLE
	9 : VALEUR JURIDIQUE </b></font></font></font></font>
	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">La
	présente Convention ainsi que son préambule ont la même valeur
	juridique que la convention de Crédit dont elle fait partie
	intégrante.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt"><b>ARTICLE
	10 : DISPOSITIONS DIVERSES</b></font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Les
	modifications à la présente Convention doivent être faites par
	écrit entre les Parties. </font></font></font></font>
	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Au
	cas où une quelconque stipulation de la Convention serait
	considérée comme nulle ou inopposable ou le deviendrait par
	l'effet d'une loi quelconque ou en raison de l'interprétation qui
	en serait donnée par une quelconque juridiction, la Convention
	serait interprétée comme si elle ne contenait pas ladite
	stipulation et l'invalidité de ladite stipulation n'affectera pas
	la validité de toutes autres stipulations de la Convention qui
	resteront par ailleurs légales et valables et demeureront
	pleinement en vigueur. </font></font></font></font>
	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Le
	cas échéant, les clauses invalides seront remplacées, à la
	diligence des Parties par des stipulations conformes à la
	législation et aux usages bancaires.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Le
	fait que la BANQUE omette d'exercer un quelconque droit, recours ou
	option conformément à la Convention ou accuse un retard à
	l'exercice desdits droits, recours ou option, ne sera pas considéré
	comme une renonciation à ce droit, recours ou option. Ne sera pas
	non plus considéré comme une renonciation, l'exercice isolé ou
	partiel d'un quelconque droit, recours ou option ou un tel exercice
	ne préjugera en rien de l'exercice renouvelé ou futur desdits
	droits, recours ou options ou de tout autre droit. </font></font></font></font>
	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Aucune
	renonciation par la BANQUE ne sera valable si elle n'est pas
	expressément faite par acte écrit faisant spécifiquement
	référence à la présente Convention.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="1" style="font-size: 8pt"><b>ARTICLE
	11 : PROTECTION DES DONNEES A CARACTERE PERSONNEL</b></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="1" style="font-size: 8pt">Les
	Parties conviennent que les informations transmises à l’occasion
	de la négociation ou de la mise en œuvre des présentes, ou qui
	contiendraient, à quelque titre que ce soit, des éléments
	reconnus par la loi ou la jurisprudence comme liés à la vie privée
	ou ayant un caractère personnel au regard du CONSTITUANT ou du
	tiers, ne pourront être utilisées qu’aux seules fins </font><font color="#000000"><font size="1" style="font-size: 8pt">de
	la conclusion et de la mise en œuvre de la présente Convention et
	pour la durée nécessaire</font></font><font size="1" style="font-size: 8pt">,
	conformément aux lois en vigueur au Gabon.</font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Les
	données à caractère personnel susvisées pourront être partagées
	avec le personnel de la BANQUE ayant le besoin d’en connaître
	ainsi que, le cas échéant, avec les prestataires de la BANQUE et
	leur personnel ayant besoin d’en connaître. En effet, </font></font><font size="1" style="font-size: 8pt">pour
	les besoins de la présente Convention, la BANQUE pourra être
	amenée à faire appel aux services de prestataires pouvant être
	situés sur le territoire ou en dehors de celui-ci, pour la
	fourniture de services administratifs, d’infrastructure
	informatique ainsi que de services intervenant en support de son
	activité. La BANQUE demeure seule responsable de ces prestataires,
	qui sont soumis à des obligations de confidentialité et de
	sécurité similaires à celles contenues dans la présente
	Convention.</font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="1" style="font-size: 8pt">Par
	ailleurs, le CONSTITUANT dispose, </font><font color="#000000"><font size="1" style="font-size: 8pt">conformément
	aux lois en vigueur au Gabon en la matière, </font></font><font size="1" style="font-size: 8pt">d’un
	droit </font><font color="#000000"><font size="1" style="font-size: 8pt">d’un
	droit d’accès aux données à caractère personnel ainsi que, le
	cas échéant, d’un droit de rectification et de suppression
	desdites données. Dans ce cas, la BANQUE sera tenue de donner suite
	à une telle demande dans un délai de quinze (15) jours suivant la
	réception de ladite demande.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt"><b>ARTICLE
	12 : CONFIDENTIALITE</b></font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="1" style="font-size: 8pt">Les
	Parties s’engagent à respecter une stricte confidentialité dans
	le domaine visé par la présente Convention.</font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="1" style="font-size: 8pt">Elles
	reconnaissent que l’existence même de la présente Convention et
	toutes informations échangées à l’occasion de la conclusion et
	de l’exécution de la présente Convention, doivent être
	considérées comme des informations confidentielles.</font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt"><b>ARTICLE
	13 : DROIT APPLICABLE - REGLEMENT DES DIFFERENDS</b></font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">La
	présente Convention est soumise au droit gabonais.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Pour
	l’exécution des présentes et de leurs suites, pour tous
	différends pouvant survenir entre la BANQUE et le CONSTITUANT dans
	leurs rapports d’affaires, et pour toute difficulté à laquelle
	la présente Convention pourrait donner lieu pour son
	interprétation, sa validité et son exécution, les Parties
	s’accordent pour rechercher une solution amiable dans un délai de
	trente (30) jours à compter de la notification du différend par
	l’une des Parties à l’autre Partie.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">A
	défaut d’accord amiable dans le délai susvisé, la Partie la
	plus diligente en réfèrera aux tribunaux compétents.</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt"><b>ARTICLE
	14 : NOTIFICATIONS - ELECTION DE DOMICILE</b></font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Pour
	l’exécution des présentes et de leurs suites, domicile est élu
	:</font></font></font></font></p>
	<p align="justify" style="margin-left: 0.2in"><br/>

	</p>
	<ul>
		<li><p align="justify"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font color="#000000"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">pour
		le CONSTITUANT, à son adresse ci-dessus ;</font></font></font></font></font></p>
		<li><p align="justify"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font color="#000000"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">pour
		la BANQUE, en son siège social susmentionné.</font></font></font></font></font></p>
	</ul>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<br/>

	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<br/>

	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<br/>

	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<br/>

	</p>
</div>
<div id="Section2" dir="ltr"><p class="western" align="justify" style="line-height: 100%">
	<br/>

	</p>
	<p class="western" align="left" style="line-height: 100%; margin-top: 0.08in">
	<br/>

	</p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Fait
	à __________ le _________________</font></font></font></font></p>
	<p class="western" align="justify" style="line-height: 100%; margin-top: 0.08in">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt">Convention
	dressée en cinq (05) exemplaires</font></font></font></font></p>
	<p class="western" align="left" style="line-height: 100%; margin-top: 0.08in">
	<br/>

	</p>
	<p class="western" align="center" style="line-height: 100%; margin-top: 0.08in"><a name="_Hlk68092933"></a>
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#000000"><font size="1" style="font-size: 8pt"><u><b>POUR
	LA BANQUE </b></u></font></font><font color="#000000"><font size="1" style="font-size: 8pt"><b>				
	                                            </b></font></font><font color="#000000"><font size="1" style="font-size: 8pt"><u><b>POUR
	LE CONSTITUANT<a class="sdfootnoteanc" name="sdfootnote1anc" href="#sdfootnote1sym" sdfixed><sup>(1)</sup></a>(1)</b></u></font></font></font></font></p>
	<p class="western" align="left" style="line-height: 100%; margin-top: 0.08in">
	<br/>

	</p>
	<p class="western" align="left" style="line-height: 100%; margin-top: 0.08in">
	<br/>

	</p>
	<p class="western" align="left" style="line-height: 100%; margin-top: 0.08in">
	<br/>

	</p>
	<p class="western" align="left" style="line-height: 100%; margin-top: 0.08in">
	<br/>

	</p>
	<p class="western" align="left" style="line-height: 115%; margin-bottom: 0.14in">
	<br/>
<br/>

	</p>
	<p class="western" align="left" style="line-height: 115%; margin-bottom: 0.14in">
	<br/>
<br/>

	</p>
	<p class="western" align="left" style="line-height: 115%; margin-bottom: 0.14in">
	<br/>
<br/>

	</p>
	<p align="left" style="margin-left: 0.5in"><br/>

	</p>
</div>
<div id="sdfootnote1">
	<ol><li><p align="left"><font face="Times New Roman, serif"><font size="3"><a class="sdfootnotesym" name="sdfootnote1sym" href="#sdfootnote1anc">(1)</a><font face="Calibri, serif"><font size="1" style="font-size: 8pt">Signature
		à faire précéder de la mention manuscrite « </font></font><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><i>Lu
		et approuvé, bon pour Nantissement de Compte DAT à hauteur de (en
		chiffres et en lettres) ................. F.cfa, augmentés des
		intérêts, frais, commissions et accessoires</i></font></font><font face="Calibri, serif"><font size="1" style="font-size: 8pt">
		».</font></font></font></font></p>
	</ol>
</div>
<div title="footer"><p align="left"><br/>

	</p>
</div>
		<center>
			<style type="text/css">
				@media print {
				  .hidden-print {
					visibility: hidden !important;
				  }
				}
			</style>
			<?php 
			if(isset($documentArray1) && $documentArray1 == $combine_doc){?>
				<button class="btn btn-primary hidden-print" id="printPageButton" onclick="myfunction()" style="position: relative;">Print Page</button>
			<?php }
			else if($documentArray1 == 0){?>
				<button class="btn btn-primary hidden-print" id="printPageButton" onclick="myfunction()" style="position: relative;">Print Page</button>
			<?php }?>
        </center> 
</body>
    <script type="text/javascript">
function myfunction(){
window.print();
}
</script>
</html>