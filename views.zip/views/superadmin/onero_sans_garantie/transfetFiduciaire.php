<?php 
$documentArray1 = 0;
if(isset($documentArray))
	$documentArray1 = sizeof($documentArray); 
$customer=(array) json_decode($appformD['customer_data']); 
$databinding=(array) json_decode($appformD['databinding']); 

$convert=new ConvertNumberToText();
?>

<!DOCTYPE html>
<html>
<head>

	<style type="text/css">
		@page { size: 8.27in 11.69in; margin-left: 0.59in; margin-right: 0.39in; margin-top: 0.59in; margin-bottom: 0.5in }
		p { text-align: justify; orphans: 2; widows: 2; margin-bottom: 0in; direction: ltr; background: transparent }
		p.western { font-size: 12pt }
		p.cjk { font-size: 12pt }
	</style>
</head>
<body lang="fr-FR" link="#000080" vlink="#800000" dir="ltr">
<center>
	<table width="466" cellpadding="7" cellspacing="0">
		<col width="450"/>

		<tr>
			<td width="450" style="border-top: 1.00pt solid #000000; border-bottom: 2.25pt solid #000000; border-left: 1.00pt solid #000000; border-right: 1.00pt solid #000000; padding: 0in 0.08in"><p align="center" style="orphans: 2; widows: 2; margin-bottom: 0.08in">
				<font face="Arial, serif"><font size="2" style="font-size: 10pt"><b><font face="Calibri, serif"><font size="4" style="font-size: 14pt">CONVENTION
				DE TRANSFERT FIDUCIAIRE </font></font></b></font></font>
				</p>
				<p align="center" style="orphans: 2; widows: 2"><font face="Arial, serif"><font size="2" style="font-size: 10pt"><b><font face="Calibri, serif"><font size="1" style="font-size: 8pt">(PERSONNE
				PHYSIQUE)</font></font></b></font></font></p>
			</td>
		</tr>
	</table>
</center>
<p style="margin-left: 0.2in; margin-top: 0.17in; margin-bottom: 0.08in">
<font size="2" style="font-size: 11pt"><font face="Arial Narrow, serif"><font size="2" style="font-size: 9pt"><b>Entre
les soussignés </b></font></font></font>
</p>
<table width="708" cellpadding="7" cellspacing="0">
	<col width="692"/>

	<tr>
		<td width="692" valign="top" style="border: 1px solid #000000; padding: 0in 0.08in"><p class="western" align="left" style="orphans: 2; widows: 2; margin-right: 0.1in; margin-top: 0.08in; margin-bottom: 0.14in">
			<font face="Calibri, serif"><font size="2" style="font-size: 10pt"><font size="1" style="font-size: 8pt">La
			</font><font size="1" style="font-size: 8pt"><b>AFG BANK GABON</b></font><font size="1" style="font-size: 8pt">
			en abrégé «</font><font size="1" style="font-size: 8pt"><b>AFG BANK GA</b></font><font size="1" style="font-size: 8pt">»,
			Société Anonyme avec Conseil d’Administration, au capital de
			18.000.000.000 (dix-huit milliards) de F.CFA dont le siège social
			est à Libreville, 714 Avenue du Colonel Parant, boite postale
			2241, immatriculée au Registre du Commerce et du Crédit Mobilier
			de ladite ville sous le numéro 2002 B 01732, identifiée
			fiscalement sous le numéro 790 027 A, inscrite sur la liste
			banques sous le numéro 40001 et dont l’adresse électronique
			est bicignet@bicig.ga, représentée par 
			_________________________ et ______________, agissant
			respectivement en qualité de ________________ et de 
			__________________________,</font></font></font></p>
			<p class="western" align="right" style="orphans: 2; widows: 2; margin-right: 0.1in; margin-top: 0.08in">
			<font face="Calibri, serif"><font size="2" style="font-size: 10pt"><font size="1" style="font-size: 8pt">Ci-après
			désignée la&nbsp;«&nbsp;</font><font size="1" style="font-size: 8pt"><b>BANQUE</b></font><font size="1" style="font-size: 8pt">&nbsp;»
			ou le «&nbsp;</font><font size="1" style="font-size: 8pt"><b>BENEFICIAIRE</b></font><font size="1" style="font-size: 8pt">&nbsp;»,</font></font></font></p>
		</td>
	</tr>
</table>
<p class="western" align="right" style="margin-right: 0.1in; margin-top: 0.08in">
<font size="2" style="font-size: 10pt"><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><b>D’UNE
PART,</b></font></font></font></p>
<p class="western" align="justify" style="margin-right: 0.1in; margin-top: 0.08in">
<font size="2" style="font-size: 10pt"><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><b>ET&nbsp;:</b></font></font></font></p>
<p class="western" align="justify" style="margin-right: 0.1in; margin-top: 0.08in">
<br/>

</p>
<table width="699" cellpadding="7" cellspacing="0">
	<col width="683"/>

	<tr>
		<td width="683" valign="top" style="border: 1px solid #000000; padding: 0in 0.08in"><p class="western" align="left" style="orphans: 2; widows: 2; margin-right: 0.1in; margin-top: 0.08in; margin-bottom: 0.14in">
			<font face="Calibri, serif"><font size="2" style="font-size: 10pt"><font size="1" style="font-size: 8pt">M/Mme
			_____________________________________________________________________________________________________________________</font></font></font></p>
			<p class="western" align="left" style="orphans: 2; widows: 2; margin-right: 0.1in; margin-top: 0.08in; margin-bottom: 0.14in">
			<font face="Calibri, serif"><font size="2" style="font-size: 10pt"><font size="1" style="font-size: 8pt">Né(e)
			le ___________________________ à _________________________ </font></font></font>
			</p>
			<p class="western" align="left" style="orphans: 2; widows: 2; margin-right: 0.1in; margin-top: 0.08in; margin-bottom: 0.14in">
			<font face="Calibri, serif"><font size="2" style="font-size: 10pt"><font size="1" style="font-size: 8pt">Demeurant
			à __________________________ ; Contact téléphonique :
			__________________________ Fonction : ________________________
			Employeur : ____________________________________________ BP :
			__________, _____________________ ; Matricule
			______________________ </font></font></font>
			</p>
			<p class="western" align="left" style="orphans: 2; widows: 2; margin-right: 0.1in; margin-top: 0.08in; margin-bottom: 0.14in">
			<font face="Calibri, serif"><font size="2" style="font-size: 10pt"><font size="1" style="font-size: 8pt">Justificatif
			d’identité : ______________ ; N° _________________________
			délivré(e) le __________________ à  _______________________</font></font></font></p>
			<p class="western" align="right" style="orphans: 2; widows: 2; margin-right: 0.1in; margin-top: 0.08in">
			<font face="Calibri, serif"><font size="2" style="font-size: 10pt"><font size="1" style="font-size: 8pt">Ci-après
			dénommé (e) le ‘‘</font><font size="1" style="font-size: 8pt"><b>CEDANT
			ou L’EMPRUNTEUR</b></font><font size="1" style="font-size: 8pt">’’
			d’autre part&nbsp;;</font></font></font></p>
		</td>
	</tr>
</table>
<p class="western"><br/>

</p>
<p class="western"><br/>

</p>
<p class="western" align="left"><font face="Arial Narrow, serif"><font size="2" style="font-size: 10pt">		</font></font></p>
<p align="center" style="line-height: 100%; page-break-inside: avoid; margin-left: 0.59in; text-indent: -0.34in; margin-top: 0.08in; margin-bottom: 0.08in; page-break-after: avoid">
<font face="Arial, serif"><font size="2" style="font-size: 10pt"><b><font face="Arial Narrow, serif"><font size="2" style="font-size: 10pt"><u>ÉTANT
PRÉALABLEMENT RAPPELÉ QUE</u></font></font><font face="Arial Narrow, serif"><font size="2" style="font-size: 10pt">
:</font></font></b></font></font></p>
<p style="margin-bottom: 0.08in"><font size="2" style="font-size: 11pt"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">La
banque a été sollicitée par le Cédant (Emprunteur), pour
l’ouverture, en compte courant,_____________________</font></font><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><b>.</b></font></font></font></p>
<p style="margin-top: 0.08in; margin-bottom: 0.08in"><font size="2" style="font-size: 11pt"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">S’y
étant disposée, la Banque a requis, en sûreté et à la garantie
du remboursement, la constitution préalable, dans ses livres, </font></font><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><b>d’un
cash Collatéral sous</b></font></font><font face="Calibri, serif"><font size="1" style="font-size: 8pt">
forme de transfert fiduciaire à hauteur de </font></font><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><b>FCFA
__________________(________________________________).</b></font></font></font></p>
<p style="margin-top: 0.08in; margin-bottom: 0.08in"><font size="2" style="font-size: 11pt"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">Les
parties se sont donc approchées et au terme de leurs discussions et
négociations, ont arrêté, ainsi qu’il suit les conditions et
modalités du transfert fiduciaire, en remboursement de la facilité
accordée par la BANQUE à l’Emprunteur.</font></font></font></p>
<p lang="en-GB" align="center" style="line-height: 100%; margin-left: 0.2in; text-indent: -0.34in; margin-top: 0.08in">
<font face="Arial, serif"><font size="2" style="font-size: 10pt"><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span lang="fr-FR"><u><b>CECI
EXPOSE, IL A ETE CONVENU CE QUI SUIT&nbsp;:</b></u></span></font></font></font></font></p>
<p align="center" style="line-height: 100%; page-break-inside: avoid; margin-left: 0.59in; text-indent: -0.34in; margin-bottom: 0.08in; page-break-after: avoid">
<font face="Arial, serif"><font size="2" style="font-size: 10pt"><b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><u>_______________________________________________________________________________________________________________</u></font></font></b></font></font></p>
<div id="TextSection" dir="ltr" gutter="19" style="column-count: 2">
	<ol><li><p align="justify" style="margin-top: 0.17in; margin-bottom: 0.08in">
		<b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">Définitions
		et interprétation</span></font></font></b></p>
	</ol>
	<p align="justify" style="margin-left: 0.2in; margin-top: 0.08in; margin-bottom: 0.08in">
	<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">Aux
	fins de la présente Convention :</span></span></font></font></p>
	<ol>
		<ol>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">&quot;</span></font></font><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">Acte
			Uniforme Portant Organisation des Sûretés</span></font></font><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">&quot;</span></font></font><u><font face="Calibri, serif"><font size="1" style="font-size: 8pt">
			</font></font></u></b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">désigne
			l’acte uniforme révisé en date du 15 décembre 2010 portant
			organisation des sûretés publié au Journal Officiel de l’OHADA
			le 15 février 2011&nbsp;;</span></span></font></font></p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">&quot;</span></span></font></font><b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">Bénéficiaire</span></font></font></b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">&quot;
			ou ‘‘Prêteur’’ désigne AFG BANK GABON, AFG BANK GA), Société Anonyme avec
			Conseil d’Administration au capital de FCFA 18.000.000.000
			(dix-huit milliards), dont le siège social est au numéro 714,
			Avenue du Colonel Parant, B. P. 2241 Libreville, immatriculée au
			RCCM de ladite ville sous le n° 2002 B 01732, identifiée
			fiscalement sous le numéro 790027/A, et inscrite sur la liste des
			banques sous le numéro 40001 et dont l’adresse électronique
			est bicignet@bicig.ga</span></span></font></font></p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">&quot;</span></span></font></font><b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">CEDANT</span></font></font></b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">&quot;
			</span></span></font></font><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">
			__________.</span></span></font></font></p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">&quot;</span></span></font></font><b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">Compte
			de fiducie</span></font></font></b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">&quot;
			désigne, le(s) compte(s) numéro(s) ________&nbsp;Ouvert(s) dans
			ses livres par le BENEFICIAIRE pour la gestion fiduciaire des
			sommes d’argent transportées et cédés à son profit par le
			CEDANT en exécution de la présente convention.</span></span></font></font></p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">&quot;</span></span></font></font><b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">Convention
			de Crédit</span></font></font></b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">&quot;
			désigne la convention de compte courant signée par les parties,
			telle qu'elle pourra être modifiée ou amendée&nbsp;;</span></span></font></font></p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">&quot;</span></span></font></font><b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">Documents
			de Financement</span></font></font></b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">
			&quot; désigne tous documents requis pour la formalisation la
			mise en place ou l’utilisation du Crédit tel que ce terme est
			défini dans la Convention de Crédit.</span></span></font></font></p>
		</ol>
	</ol>
	<p style="margin-left: 0.2in; margin-top: 0.08in; margin-bottom: 0.08in">
	<font size="2" style="font-size: 11pt"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">&quot;</font></font><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><b>Fonds
	Cédés</b></font></font><font face="Calibri, serif"><font size="1" style="font-size: 8pt">&quot;
	désigne la (les) somme(s) de </font></font><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><b>FCFA___________
	</b></font></font><font face="Calibri, serif"><font size="1" style="font-size: 8pt">que
	le CEDANT se dispose à transférer en vertu du présent acte.</font></font></font></p>
	<ol>
		<ol start="7">
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">&quot;</span></span></font></font><b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">Obligations
			Garanties</span></font></font></b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">&quot;
			désigne les obligations de paiement et de remboursement
			contractées par  l’EMPRUNTEUR envers la Banque aux termes des
			Documents de Financement (tels que ceux-ci pourraient, le cas
			échéant, être modifiés ultérieurement), y compris au titre de
			futures mises à disposition de fonds conformément aux termes des
			Documents de Financement, inconditionnellement ou non,
			immédiatement ou à terme, dans chaque cas augmentées de tout
			intérêt, intérêt de retard, commission, frais et accessoire
			quelconque calculé conformément aux Documents de Financement&nbsp;;</span></span></font></font></p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">&quot;Crédit
			&quot; désigne _____________________________</span></span></font></font></p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">&quot;</span></span></font></font><b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">OHADA</span></font></font></b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">&quot;
			désigne l’Organisation pour l’Harmonisation en Afrique du
			Droit des Affaires créée par le Traité relatif à
			l'Harmonisation du Droit des Affaires en Afrique signé le 17
			octobre 1993, tel que modifié&nbsp;;</span></span></font></font></p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">&quot;</span></span></font></font><b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">Partie</span></font></font></b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">&quot;
			désigne une partie à la présente Convention&nbsp;;</span></span></font></font></p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">&quot;</span></span></font></font><b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">Transfert
			Fiduciaire</span></font></font></b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">
			d’une somme d’argent&quot;&nbsp;: Désigne la présente
			Convention par laquelle</span></span></font></font><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">
			</span></span></font></font><b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">M/Mme_________</span></font></font></b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">
			</span></span></font></font><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">cède
			des fonds en garantie de l’exécution de ses obligations
			souscrites au titre de la Convention de Crédit, conformément aux
			termes des articles 87 à 91 de l’Acte Uniforme Portant
			Organisation des Sûretés.</span></span></font></font></p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">Les
			termes et expressions utilisés dans la présente Convention
			auront, sauf stipulation contraire, la signification qui leur est
			donnée dans la Convention de Crédit.</span></span></font></font></p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">En
			cas de contradiction ou de divergence entre l'une quelconque des
			stipulations de la présente Convention et l'une quelconque des
			stipulations de la Convention de Crédit, les termes de la
			Convention de Crédit prévaudront, hormis les cas où les
			stipulations de la présente Convention deviendraient nulles et/ou
			inopposables.</span></span></font></font></p>
		</ol>
		<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
		<b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">TRANSFERT
		FIDUCIAIRE</span></font></font></b></p>
	</ol>
	<ol>
		<li><p align="justify" style="display: none; margin-top: 0.08in; margin-bottom: 0.08in; page-break-after: avoid">
		</p>
	</ol>
	<ol>
		<ol>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">M/Mme
			___________________</span></font></font><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">
			</span></font></font></b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">cède
			et abandonne par les présentes au profit de La Banque qui
			l’accepte, à titre de garantie du remboursement de toutes
			sommes en principal, intérêts, frais, commissions, taxes et
			accessoires que&nbsp;le Cédant pourrait devoir à la Banque en
			raison du financement ci-dessus mentionné, la (les) somme (s) de
			</span></span></font></font><b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">FCFA
			_______________ </span></font></font></b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">dont
			il autorise le prélèvement dans son compte courant, et la
			conservation en fiducie sur le Compte Bloqué jusqu’à
			l’extinction des engagements bancaires.</span></span></font></font></p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">Les
			fonds cédés à la banque seront bloqués sur le(s) compte (s) de
			fiducie </span></span></font></font><b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">N°_________
			 </span></font></font></b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">
			   ouvert(s) dans les livres de la BICIG et en son nom en qualité
			de créancière de l’obligation du Cédant.</span></span></font></font></p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">De
			commun accord entre les parties, le Compte Bloqué constitue un
			compte de fiducie au sens des dispositions de l’acte uniforme de
			l’OHADA relatif aux sûretés encadrant le mécanisme de
			transfert fiduciaire&nbsp;; il n’est ouvert dans l’environnement
			comptable du Cédant que pour une meilleure gestion des
			Obligations Garanties.</span></span></font></font></p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">Le
			CEDANT ne peut disposer de cette somme bloquée de quelque manière
			que ce soit, tant qu’elle demeurera affectée en fiducie à la
			garantie des Obligations Garanties envers&nbsp;Le BENEFICIAIRE.</span></span></font></font></p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">Les
			fonds cédés au profit de la banque, en vertu de la présente
			convention, ne produisent pas d’intérêt.</span></span></font></font></p>
		</ol>
		<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
		<b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">Durée-Effets</span></font></font></b></p>
		<ol>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">Le
			présent Transfert Fiduciaire est constitué pour toute la durée
			du financement, et devra produire plein effet jusqu’au
			remboursement intégral du crédit spot en principal, intérêts,
			frais et accessoires. </span></span></font></font>
			</p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">Le
			Transfert Fiduciaire résultant du présent acte aura notamment
			pour effet de rendre inopérantes&nbsp;toute action ou saisie
			effectuée par tous tiers sur les dépôts transférés au profit
			de la Banque</span></span></font></font></p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">Le
			Transfert Fiduciaire constitué au titre de la présente
			convention s'ajoutera à toutes sûretés dont bénéficie la
			Banque, et ne pourra en aucun cas porter atteinte à, ni être
			compromis ou affecté, par lesdites sûretés.</span></span></font></font></p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">Le
			Cédant renonce à se prévaloir des droits dont il pourrait être
			investi aux fins d’exiger de la Banque qu’elle procède ou
			exerce toute sûreté à l’encontre de toute autre personne
			avant de procéder à l’exercice des droits constitués aux
			termes de la présente convention et de tout droit qu’elle
			pourrait avoir d’exiger que la Banque exerce ses droits dans un
			ordre spécifique au titre de la présente convention. </span></span></font></font>
			</p>
		</ol>
		<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
		<b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">Réalisation</span></font></font></b></p>
	</ol>
	<p align="justify" style="margin-left: 0.2in; margin-top: 0.08in; margin-bottom: 0.08in">
	<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">En
	cas de défaillance de l’Emprunteur et huit jours après que le
	Cédant en ait été dûment averti, la banque pourra, si bon lui
	semble, affecter les fonds cédés à l’apurement des engagements
	du Cédant, dans la limite du montant des créances garanties
	demeurant impayées.</span></span></font></font></p>
	<ol start="5">
		<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
		<b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">Restitution</span></font></font></b></p>
	</ol>
	<p align="justify" style="margin-left: 0.2in; margin-top: 0.08in; margin-bottom: 0.08in">
	<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">A
	l'échéance stipulée à l’article 3.1 ci-dessus, et en cas de
	complète extinction des facilités, les fonds inscrits sur le
	compte de fiducie sont restitués au Cédant.</span></span></font></font></p>
	<ol start="6">
		<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
		<b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">Déclarations
		et garanties</span></font></font></b></p>
		<ol>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">Le
			Cédant déclare et garantit, qu’à la date de la présente
			Convention, et aussi longtemps que la présente Convention sera en
			vigueur :</span></span></font></font></p>
		</ol>
	</ol>
	<ol type="a">
		<li value="1"><p class="western" align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
		<font size="2" style="font-size: 10pt"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">Que
		les sommes cédées aient une origine légale et leur provenance
		est conforme à la réglementation en vigueur sur la lutte contre
		le blanchiment des capitaux et le financement du terrorisme ;</font></font></font></p>
		<li><p class="western" align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
		<font size="2" style="font-size: 10pt"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">Il
		a pleine autorité et capacité pour conclure et signer le Contrat
		et pour exécuter ses obligations à ce titre ;</font></font></font></p>
	</ol>
	<ol>
		<ol>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">Le
			Cédant déclare en outre&nbsp;:</span></span></font></font></p>
		</ol>
	</ol>
	<ol type="a">
		<li><p class="western" align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
		<font size="2" style="font-size: 10pt"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">Aucun
		accord, consentement, enregistrement ou dépôt n’est nécessaire
		ou utile à la validité, à l’opposabilité, à l’efficacité
		et à la bonne constitution du Transfert Fiduciaire ;</font></font></font></p>
		<li><p class="western" align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
		<font size="2" style="font-size: 10pt"><font face="Calibri, serif"><font size="1" style="font-size: 8pt">Le
		Cédant déclare en outre qu’à sa connaissance, aucune mesure
		d’exécution forcée n’affecte les sommes transférées à la
		date de la présente Convention.</font></font></font></p>
	</ol>
	<ol start="7">
		<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
		<b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">Ambiguïté
		et exercice des droits</span></font></font></b></p>
		<ol>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">Ambiguïté</span></font></font></b></p>
		</ol>
	</ol>
	<p align="justify" style="margin-left: 0.2in; margin-top: 0.08in; margin-bottom: 0.08in">
	<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">En
	cas d'ambiguïté ou de conflit entre les droits prévus par la loi
	et ceux stipulés aux termes de la présente Convention, les termes
	de la Convention prévaudront dans toute la mesure permise par la
	loi.</span></span></font></font></p>
	<ol>
		<ol start="2">
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">Exercice
			des droits</span></font></font></b></p>
		</ol>
	</ol>
	<p align="justify" style="margin-left: 0.2in; margin-top: 0.08in; margin-bottom: 0.08in">
	<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">Le
	fait pour le Bénéficiaire de ne pas exercer un droit, une option
	ou un privilège quelconque dont il est titulaire au titre de la
	présente Convention ou le fait pour lui d'exercer un tel droit, une
	telle option ou un tel privilège avec retard ne vaudra pas
	renonciation à ce droit, à cette option ou à ce privilège. Les
	droits et recours du Bénéficiaire aux termes de la présente
	Convention sont cumulatifs et non exclusifs d'autres droits ou
	recours prévus par la loi.</span></span></font></font></p>
	<ol start="8">
		<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
		<b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">Opposabilité
		de la Convention aux tiers</span></font></font></b></p>
	</ol>
	<p align="justify" style="margin-left: 0.2in; margin-top: 0.08in; margin-bottom: 0.08in">
	<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">En
	raison du fait que le Bénéficiaire et l’Etablissement teneur de
	compte bloqué sont une seule et même personne, et aussi pour
	s’aménager la preuve de l’exactitude de la date de notification
	qui commande la sécurité de la sureté par son opposabilité au
	tiers, les parties conviennent que la formalité de notification de
	la présente convention à l'établissement teneur du compte sera
	faite par voie d’huissier, à l’initiative de la partie la plus
	diligente.</span></span></font></font></p>
	<ol start="9">
		<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
		<b><font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none">Stipulations
		Générales</span></font></font></b></p>
		<ol>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">Le
			présent transfert fiduciaire n'affecte point, ni ne pourra
			affecter, en aucune manière, la nature et l'étendue de tous
			engagements et de toutes garanties quelconques qui ont pu ou
			pourront être contractés ou fournis soit par le Cédant, soit
			par tous tiers, auxquels il s'ajoute et s'ajoutera.</span></span></font></font></p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">Le
			Cédant déclare expressément dispenser la Banque de protêts
			pour tous les effets portant sa signature.</span></span></font></font></p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">Il
			s'engage à ne se prévaloir vis-à-vis de la Banque, ni de la
			présentation tardive desdits effets, ni de l'envoi des avis de
			non-paiement les concernant dans un délai excédant le délai
			légal.</span></span></font></font></p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">Tous
			droits, impôts, taxes, pénalités et frais auxquels le présent
			transfert fiduciaire ainsi que son exécution pourront donner lieu
			seront à la charge du Cédant qui s’y oblige expressément.</span></span></font></font></p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">Pour
			l'exécution des présentes, élection de domicile est faite à
			savoir&nbsp;:</span></span></font></font></p>
		</ol>
	</ol>
	<ul>
		<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
		<font face="Calibri, serif"><font size="1" style="font-size: 8pt">Le
		Cédant en son adresse sus indiqué.</font></font></p>
		<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
		<font face="Calibri, serif"><font size="1" style="font-size: 8pt">La
		Banque en son siège social sus indiqué.</font></font></p>
	</ul>
	<ol>
		<ol start="6">
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">Et
			spécialement pour la validité du transfert fiduciaire, domicile
			est élu au siège social de la Banque sus indiqué.</span></span></font></font></p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">La
			convention est régie pour sa conclusion, sa validité, son
			interprétation et son exécution, par la réglementation en
			vigueur au Gabon, et notamment par les articles 87 à 91 de l’acte
			uniforme relatif au droit des sûretés.</span></span></font></font></p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">En
			cas de survenance de tout différend ayant trait à la validité,
			l’interprétation, l’exécution ou l’inexécution de la
			présente convention, les Parties s’obligent à se concerter et
			à rechercher un règlement amiable dans un délai de trente (30)
			jours suivant la notification adressée à l’autre par la partie
			la plus diligente. </span></span></font></font>
			</p>
			<li><p align="justify" style="margin-top: 0.08in; margin-bottom: 0.08in">
			<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">En
			cas d’échec de la médiation, le différend sera dévolu aux
			juridictions compétentes par la partie la diligente.</span></span></font></font></p>
		</ol>
	</ol>
	<p align="left" style="font-weight: normal; margin-left: 0.2in; text-indent: -0.34in; text-decoration: none">
	<br/>

	</p>
	<p align="justify" style="margin-left: 0.3in; text-indent: -0.3in; margin-top: 0.08in; margin-bottom: 0.08in">
	<font face="Calibri, serif"><font size="1" style="font-size: 8pt"><span style="text-decoration: none"><span style="font-weight: normal">Fait
	à Libreville, le ________________________________</span></span></font></font></p>
</div>
<div id="Section1" dir="ltr"><p align="justify" style="font-weight: normal; line-height: 115%; text-decoration: none">
	<br/>

	</p>
	<p class="western" align="center" style="line-height: 115%"><font size="2" style="font-size: 10pt"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><u><b>_______________________________________________________________________________________</b></u></font></font></font></p>
	<p class="western" align="center" style="line-height: 115%"><font size="2" style="font-size: 10pt"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><u><b>P/
	LE CÉDANT</b></u></font></font><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><b>		</b></font></font><font face="Calibri, serif"><font size="2" style="font-size: 11pt">				</font></font><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><u><b>P/
	LA BANQUE</b></u></font></font></font></p>
	<p class="western" align="justify" style="line-height: 115%"><br/>

	</p>
	<p class="western" align="justify" style="line-height: 115%"><br/>

	</p>
	<p class="western" align="justify" style="line-height: 115%"><br/>

	</p>
	<p align="left" style="line-height: 115%"><b><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><span style="text-decoration: none">		</span></font></font></b></p>
	<p class="western" align="justify" style="line-height: 115%; margin-left: 0.49in; text-indent: 0.49in">
	<font size="2" style="font-size: 10pt"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><b>	</b></font></font><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><i><b>	</b></i></font></font></font></p>
	<p class="western" align="justify" style="line-height: 115%; margin-left: 3.44in">
	<br/>

	</p>
	<p class="western" align="left"><br/>

	</p>
	<p class="western" align="left"><br/>

	</p>
	<p class="western" align="left"><br/>

	</p>
	<p class="western" align="left"><br/>

	</p>
	<p class="western" align="left"><br/>

	</p>
	<p class="western" align="left"><br/>

	</p>
	<p class="western" align="left"><br/>

	</p>
	<p class="western" align="left"><br/>

	</p>
	<p class="western" align="left"><br/>

	</p>
	<p class="western" align="left"><br/>

	</p>
	<p class="western" align="left"><br/>

	</p>
	<p class="western" align="left"><font size="2" style="font-size: 10pt"><font face="Calibri, serif"><font size="2" style="font-size: 11pt">	</font></font></font></p>
</div>

		<center>
			<style type="text/css">
				@media print {
				  .hidden-print {
					visibility: hidden !important;
				  }
				}
			</style>
			<?php 
			if(isset($documentArray1) && $documentArray1 == $combine_doc){?>
				<button class="btn btn-primary hidden-print" id="printPageButton" onclick="myfunction()" style="position: relative;">Print Page</button>
			<?php }
			else if($documentArray1 == 0){?>
				<button class="btn btn-primary hidden-print" id="printPageButton" onclick="myfunction()" style="position: relative;">Print Page</button>
			<?php }?>
        </center> 
</body>
    <script type="text/javascript">
function myfunction(){
window.print();
}
</script>
</html>