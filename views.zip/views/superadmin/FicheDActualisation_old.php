<?php

// $customer=(array) json_decode($appformD['customer_data']);

$databinding=(array) json_decode($appformD['databinding']);

// echo "<pre>";

// print_r($changeArray);

// echo "</pre>";
$unique=array();
foreach ($changeArray as $value)
    {
        foreach ($value as $value1=>$key1)
    {
        
        array_push($unique,$key1);
    }
    }
    
   
// array_push($a,"blue","yellow");

?>
<style> 
			@page { 
				margin: 0;

			}
			table td span{
				display: block;
				margin-bottom: 3px;
			}
			ul{
				margin: 10px 0;
			}
			ul li{
				color: #222222;
				font-size: 12px;
				margin-top: 3px;
			}
			@media print {
				.pagebreak { page-break-before: always; } /* page-break-after works, as well */
			
			
			.colorstrip{
			        border-color: green;
    
                    height: 18px;
                    border-style: solid;
    
                    background-color: #11da33
			}
			}
				.colorstrip{
			        border-color: green;
    
                    height: 18px;
                    border-style: solid;
    
                    background-color: #11da33
		</style>

    <body translate="no" style="background-color: #fff; font-family: Open Sans, sans-serif; font-size: 100%; font-weight: 400; line-height: 1.3; color: #444444; margin: 0;">
        
          <div id="content-wrapper">

    <div class="row">
      <div class="col-lg-12">
        <div id="content-header" class="clearfix">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap/bootstrap.min.css');?>"/> 
	<script src="<?php echo base_url('assets/js/demo-rtl.js');?>"></script> 
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/libs/font-awesome.css');?>"/>
 <div class="main-box-body clearfix" >
                  <center><h2 id="tab-title" ><span>Fiche d'actualisation</span></h2></center>
                   <div class="detail_section" style="margin: 30;">
<form id="addnewcustomer" action=''  method="post"> 

            
              <div class="row">
                <div class="col-xs-12 response-msg"></div>
              </div>
           
                   <h3 id="tab-title"><span>Renseignements Personnels</span></h3>
            <div class="row">

              <?php // echo '<pre>'; print_r($customer);?>
                
                
            <div class="col-xs-3">
                <div class="form-group">
                  <label>Titre</label>
                  <div id="tab-details" class="<?php if (in_array("title", $unique)){echo "colorstrip"; }?>"> 
                   <?= $customer->title ; ?>
                     
                 
                  </div>
                </div>
              </div>
              
              <div class="col-xs-3">
                <div class="form-group">
                  <label> Prénoms</label>
                  <div id="tab-details" class="<?php if (in_array("first_name", $unique)){echo "colorstrip"; }?>"> 
                    <?= $customer->first_name ; ?>
                    

                  </div>
                </div>
              </div>                  
              <div class="col-xs-3 hidden">
                <div class="form-group">
                  <label>2ième Prénoms </label>
                  <div id="tab-details" class="<?php if (in_array("middle_name", $unique)){echo "colorstrip"; }?>"> 
                  <?= $customer->middle_name ; ?>

                    


                   </div>
                </div>
              </div>
              <div class="col-xs-3">
                <div class="form-group">
                  <label> Nom Patronymique</label>
                  <div id="tab-details" class="<?php if (in_array("last_name", $unique)){echo "colorstrip"; }?>"> 
                  <?= $customer->last_name ; ?>
                    
                  </div>
                </div>
              </div>

              <div class="col-xs-3">
                <div class="form-group">
                  <label>Genre </label>
                  <div id="tab-details" class="<?php if (in_array("gender", $unique)){echo "colorstrip"; }?>"> 
                        <?= $customer->gender ; ?>
                     
                 </div>
                </div>
              </div>
              
            </div>

            <div class="row">
              
              <div class="col-xs-3">
                <div class="form-group" >
                  <label>Date de naissance </label>
                  <div id="tab-details" class="<?php if (in_array("dob", $unique)){echo "colorstrip"; }?>"> 
                    <?= date("d-m-Y", strtotime($customer->dob));?>
                     
                  </div>
                </div>
              </div>

              <div class="col-xs-3">
                <div class="form-group" >
                  <label>Lieu de naissance</label>
                  <div id="tab-details" class="<?php if (in_array("birthplace", $unique)){echo "colorstrip"; }?>">
                      <?= $customer->birthplace ; ?>
                  
                  </div>
                </div>
              </div>

              <div class="col-xs-3 hidden">
                <div class="form-group">
                  <label>Dipôme ou Niveau étude </label>
                  <div id="tab-details" class="<?php if (in_array("education", $unique)){echo "colorstrip"; }?>"> 
                        <?= $customer->education ; ?>
                    
                  </div>
                </div>
              </div>
              <div class="col-xs-3">
                <div class="form-group">
                  <label>Situation Matrimoniale </label>
                  <div id="tab-details" class="<?php if (in_array("marital_status", $unique)){echo "colorstrip"; }?>"> 
                        <?= $customer->marital_status ; ?>
                    
                   </div>
                </div>
              </div>
              <div class="col-xs-3">
                <div class="form-group">
                  <label>Email </label>
                  <div id="tab-details" class="<?php if (in_array("email", $unique)){echo "colorstrip"; }?>"> 
                        <?= $customer->email ; ?>
                   
                  </div>
                </div>
              </div>
             <div class="col-xs-3">
                <div class="form-group">
                  <label>Lieu d'habitation</label>
                  <div id="tab-details" class="<?php if (in_array("resides_address", $unique)){echo "colorstrip"; }?>"> 
                    <?= $customer->resides_address ; ?>
                    
                  </div>
                </div>
              </div>
              <div class="col-xs-3">
                <div class="form-group">
                  <label>Adresse postale</label>
                  <div id="tab-details" class="<?php if (in_array("street", $unique)){echo "colorstrip"; }?>">  
                    <?= $customer->street ; ?>
                    
                  </div>
                </div>
              </div>

              <div class="col-xs-3">
                <div class="form-group">
                  <label>Adresse Complémentaire</label>
                  <div id="tab-details" class="<?php if (in_array("alternateAddress", $unique)){echo "colorstrip"; }?>">  
                    <?= $customer->alternateAddress ; ?>
                    
                  </div>
                </div>
              </div>


              <div class="col-xs-3">
                <div class="form-group">
                  <label>Ville </label>
                  <div id="tab-details" class="<?php if (in_array("city_id", $unique)){echo "colorstrip"; }?>"> 
                    <?= $customer->city_id ; ?>
                    
                 </div>
                </div>
              </div>

               <div class="col-xs-3 hidden">
                <div class="form-group">
                  <label>Pays de résidence <span style="color:red">*</span></label>
                  <div id="tab-details" class="<?php if (in_array("state_id", $unique)){echo "colorstrip"; }?>"><span> 
                    <?= $customer->state_id ; ?>
                    
                  </div>
                </div>
              </div>

                <div class="col-xs-3">
                        <div class="form-group">
                          <label>Capacite Juridique</label> 
                           <div id="tab-details" class="<?php if (in_array("legalCapacity", $unique)){echo "colorstrip"; }?>">
                                <?= $customer->legalCapacity ; ?>
                          
                          </div>  
                
                </div>
              </div>
             
      </div>

          

            <h3 id="tab-title" style="margin-top: 2%;"><span>Informations Additionnelles</span></h3>
            <div class="row">
              <div class="col-xs-3">
                <div class="form-group">
                  <label>Nature de la Pièce d’ Identité </label>                
                 

                    <div id="tab-details"  class="<?php if (in_array("type_id", $unique)){echo "colorstrip"; }?>">
                        
                        <?php echo $customer->type_id;?>
                   

                     </div>                  
                </div>
              </div>
              
              <div class="col-xs-3 ">
                <div class="form-group">
                  <label>Numéro de la Pièce d’Identité </label>
                  <div id="tab-details" class="<?php if (in_array("id_number", $unique)){echo "colorstrip"; }?>"> 
                  <?= $customer->id_number;?>
                     
                  </div>
                </div>
              </div>
              
               <div class="col-xs-3 ">
                <div class="form-group">
                  <label>Date etablissement type de piece</label>
                  <div id="tab-details" class="<?php if (in_array("dateId", $unique)){echo "colorstrip"; }?>">  
                  <?= date("d-m-Y", strtotime($customer->dateId));?>
                    
                  </div>
                </div>
              </div>

               <div class="col-xs-3">
                <div class="form-group">
                  <label>Pays Res. Fiscale</span></label>
                  <div id="tab-details" class="<?php if (in_array("state_of_issue", $unique)){echo "colorstrip"; }?>"> 
                  <?= $customer->state_of_issue;?>
                     
                 </div>
                </div>
              </div>

             
            </div>
            <div class="row">
                
               <div class="col-xs-3">
                <div class="form-group">
                  <label>Numéro de téléphone Portable 1</label>
                  <div id="tab-details" class="<?php if (in_array("main_phone", $unique)){echo "colorstrip"; }?>">  
                  <?= $customer->main_phone;?>
                   
                  
                </div>
                </div>
              </div>



              <div class="col-xs-3">
                  <div class="form-group">
                    <label>Numéro de téléphone Portable 2</label>
                    <div id="tab-details" class="<?php if (in_array("main_phone2", $unique)){echo "colorstrip"; }?>">
                        <?= $customer->main_phone2;?>
                     
                    </div>  
                
                </div>
              </div>
             
              <div class="col-xs-3">
                <div class="form-group">
                  <label>Second Numéro de téléphone Domicile 1 </label>
                  <div id="tab-details" class="<?php if (in_array("alternative_phone", $unique)){echo "colorstrip"; }?>"> 
                  <?= $customer->alternative_phone;?>
                      
                  </div>
                    
                </div>
              </div>

              <div class="col-xs-3">
                <div class="form-group">
                  <label>Second Numéro de téléphone Domicile 2</label>
                  <div id="tab-details" class="<?php if (in_array("alter_phone2", $unique)){echo "colorstrip"; }?>">
                      <?= $customer->alter_phone2;?>
                     
                  </div>
                  
                </div>
              </div>



             
              
              <div class="col-xs-3">
                <div class="form-group">
                  <label>Date d’Expiration de la Pièce d’Identité </label>
                  <div id="tab-details" class="<?php if (in_array("expiration_date_id", $unique)){echo "colorstrip"; }?>"> 
                  <?= $customer->expiration_date_id;?>
                    
                  </div>
                </div>
              </div>

              


              <div class="col-xs-3">
              <div class="form-group">
                <label>Prénoms du Pere </label>
                <div id="tab-details" class="<?php if (in_array("father_firstname", $unique)){echo "colorstrip"; }?>"> 
                <?= $customer->father_firstname;?>
                  
                </div>
              </div>
            </div>
            <div class="col-xs-3">
              <div class="form-group">
                <label>Nom Pere </label>
                <div id="tab-details" class="<?php if (in_array("father_fullname", $unique)){echo "colorstrip"; }?>"> 
                <?= $customer->father_fullname;?>
                   
                </div>
              </div>
            </div>
            <div class="col-xs-3">
              <div class="form-group">
                <label>Prénoms du Mere </label>
                <div id="tab-details" class="<?php if (in_array("mother_firstname", $unique)){echo "colorstrip"; }?>"> 
                <?= $customer->mother_firstname;?>
                   
                </div>
              </div>
            </div>

           
              
            </div>
            <div class="row">
                
            <div class="col-xs-3">
              <div class="form-group">
                <label>Nom Mere </label>
                <div id="tab-details" class="<?php if (in_array("mother_fullname", $unique)){echo "colorstrip"; }?>"> 
                <?= $customer->mother_fullname;?>
                  
                </div>
              </div>
            </div>

               <div class="col-xs-3">
                 <div class="form-group">
                <label>Nationalité</label>
                 <div id="tab-details" class="<?php if (in_array("nationality", $unique)){echo "colorstrip"; }?>">
                     <?= $customer->nationality;?>
                 </div>
              </div>
              </div>
              <div class="col-xs-3">
                <div class="form-group">
                <label>Lieu Etablissement Pièce</label>
                <div id="tab-details" class="<?php if (in_array("insurance_place_id", $unique)){echo "colorstrip"; }?>"> 
                <?= $customer->insurance_place_id;?>
                

                </div>
              </div>
              </div>
                                
             
          

            </div>


            <h3 id="tab-title" style="margin-top: 2%;"><span>Information Sur l'Emploi</span></h3>
            <div class="row">
              <div class="col-xs-3">
                <div class="form-group">
                  <label>Type Emploi </label>
                  <div  id="tab-details" class="<?php if (in_array("employeeStatus", $unique)){echo "colorstrip"; }?>"> 
                  <?= $customer->employeeStatus;?>

                    </div>
                </div>
              </div>
               <div class="col-xs-3">
                <div class="form-group">
                <label>Nom de l’employeur</label>
                <div id="tab-details" class="<?php if (in_array("employer_name", $unique)){echo "colorstrip"; }?>"> 
                <?= $customer->employer_name;?>
                </div>
              </div>
              </div>

              <div class="col-xs-3">
                <div class="form-group" style="margin-bottom:5px;">
                  <label>Secteur d’activité</label> 
                  <div id="tab-details" class="<?php if (in_array("secteurs_id", $unique)){echo "colorstrip"; }?>"> 
                  <?= $customer->secteurs_id;?>
                
                </div>
                </div>
              </div>

              <div class="col-xs-3">
                <div class="form-group">
                    <label>Categ. Socio-Prof</label>
                    <div id="tab-details" class="<?php if (in_array("categ", $unique)){echo "colorstrip"; }?>"> 
                    <?= $customer->categ;?>
                   
                    </div>
                        
                </div>
              </div>


            
            </div>
            <div class="row">


              <div class="col-xs-3">
                <div class="form-group" style="margin-bottom:5px;">
                  <label>Type Employeur </label>
                  <div id="tab-details" class="<?php if (in_array("cat_employeurs", $unique)){echo "colorstrip"; }?>">
                      <?= $customer->cat_employeurs;?>
                  

                 </div>
                </div>
              </div>


              <div class="col-xs-3">

                 <div class="form-group" style="margin-bottom:5px;">
                   
                    <label>Type de Contrat </label>
                     <div id="tab-details" class="<?php if (in_array("contract_type_id", $unique)){echo "colorstrip"; }?>">
                         <?= $customer->contract_type_id;?>
                    
                    </div>
                  </div>  
              </div>

              <div class="col-xs-3">
                <div class="form-group" style="margin-bottom:5px;">
                  <label>Adresse de l'employeur</label> 
                  <div id="tab-details" class="<?php if (in_array("address_employer", $unique)){echo "colorstrip"; }?>"> 
                  <?= $customer->address_employer;?>
                
                </div>
                </div>
              </div>

              <div class="col-xs-3">
                <div class="form-group">
                  <label>Numéro Professionel 1</label>
                  <div id="tab-details" class="<?php if (in_array("numero1", $unique)){echo "colorstrip"; }?>">
                      <?= $customer->numero1;?>
                  
                  </div>
                </div>
              </div>


             
             
            </div>

            <div class="row">

              <div class="col-xs-3">
                <div class="form-group">
                  <label>Numéro Professionel 2</label>
                  <div id="tab-details" class="<?php if (in_array("numero2", $unique)){echo "colorstrip"; }?>">
                      <?= $customer->numero2;?>
                     
                  </div>
                </div>
              </div>

               <div class="col-xs-3">
                <div class="form-group">
                  <label>Date d’embauche </label>
                  <div id="tab-details" class="<?php if (in_array("employment_date", $unique)){echo "colorstrip"; }?>"> 
                  <?php
                  if($customer->employment_date){
                  echo date("d-m-Y", strtotime($customer->employment_date));
                  }?>
                 
                  </div>
                </div>
              </div>
              <div class="col-xs-3">
                <div class="form-group">
                  <label>Date De Fin de Contrat/Départ à la Retraite</label>
                  <div id="tab-details" class="<?php if (in_array("sate_end_contract_cdd", $unique)){echo "colorstrip"; }?>"> 
                  
                    <?php
                  if($customer->sate_end_contract_cdd){
                  echo date("d-m-Y", strtotime($customer->sate_end_contract_cdd));
                  }?>
                 </div>
                </div>
              </div>

              <div class="col-xs-3">
                <div class="form-group">
                  <label>Date de présence chez l’employeur actuel </label>
                  <div id="tab-details" class="<?php if (in_array("how_he_is_been_with_current_employer", $unique)){echo "colorstrip"; }?>"> 
                  
                  <?php if($customer->how_he_is_been_with_current_employer) echo date('d-m-Y', strtotime($customer->how_he_is_been_with_current_employer)); ?>
                  </div>
                </div>
              </div>

              <div class="col-xs-3 hidden">
                <div class="form-group">
                  <label>Nombre d’année d’expérience professionnelle </label>
                  <div id="tab-details" class="<?php if (in_array("years_professionel_experience", $unique)){echo "colorstrip"; }?>"> 
                  <?= $customer->years_professionel_experience;?>
                                                 
                    </div>
                </div>
              </div>
            

           </div>
            <div class="row">

             
               <div class="col-xs-3">
                <div class="form-group">
                  <label>Salaire net </label>
                  <div id="tab-details" class="<?php if (in_array("emp_net_salary", $unique)){echo "colorstrip"; }?>">  
                  <?= $customer->emp_net_salary;?>

                  
                       </div>
                </div>
              </div>

              <div class="col-xs-3 hidden">
                <div class="form-group">
                  <label>Age de retraite prévu </label>
                  <div id="tab-details" class="<?php if (in_array("retirement_age_expected", $unique)){echo "colorstrip"; }?>"> 
                  <?= $customer->retirement_age_expected;?>

                 
                      </div>
                </div>
              </div>


           
              
              <div class="col-xs-3">
                <div class="form-group">
                  <label>Emploi exercé </label>
                  <div id="tab-details" class="<?php if (in_array("employeeOccupation", $unique)){echo "colorstrip"; }?>"> 
                  <?= $customer->employeeOccupation;?>

                 
                      </div>
                </div>
              </div>


               <div class="col-xs-3">
                  <div class="form-group">
                    <label>Nom Ancien Employeur</label>
                    <div id="tab-details" class="<?php if (in_array("ancianemployer", $unique)){echo "colorstrip"; }?>">
                        <?= $customer->ancianemployer;?>
                       
                    </div>
                  </div>
                </div>
              
              </div>

              <div class="row">

               
              </div>

           
            <h3 id="tab-title" style="margin-top: 2%;"><span>Information Sur le Compte Bancaire</span></h3>
            <div class="row">
              <div class="col-xs-3">
                 <div class="form-group">
                  <label>Type de compte </label>
              <div id="tab-details" class="<?php if (in_array("account_type", $unique)){//echo "colorstrip"; 
              }?>">
                   <?= $customer->account_type;?>
              </div>                                 
              </div>   
           </div>
              <div class="col-xs-3">
                <div class="form-group">
                  <label> Agence bancaire </label>
                  <div id="tab-details" class="<?php if (in_array("bank_name", $unique)){//echo "colorstrip"; 
                  }?>">  
                  <?= $customer->bank_name;?>
                </div>
              </div>
              </div>
              <div class="col-xs-3">
                <div class="form-group">
                  <label>Téléphone agence bancaire</label>
                  <div id="tab-details" class="<?php if (in_array("bank_phone", $unique)){//echo "colorstrip";
                  }?>">  
                  <?= $customer->bank_phone;?>

                    
                  </div>
                </div>
              </div>
              <div class="col-xs-3">
                <div class="form-group">
                  <label>Date ouverture de compte </label>
                  <div id="tab-details" class="<?php if (in_array("opening_date", $unique)){//echo "colorstrip"; 
                  }?>"> 
                  <?php
                  
                  if($customer->opening_date){
                  echo date("d-m-Y", strtotime($customer->opening_date));
                  }?>
                    
                   </div>
                </div>
              </div>
               
            </div>
            <div class="row">

               <div class="col-xs-3">
                <div class="form-group">
                  <label>Code Bqe</label>
                  <div id="tab-details" class="<?php if (in_array("code_bqe", $unique)){//echo "colorstrip";
                  }?>"> 
                  <?= $customer->code_bqe;?>
                  
                  </div>
                </div>
              </div>

               <div class="col-xs-2">
                <div class="form-group">
                  <label>Code Agc</label>    
                  <div id="tab-details" class="<?php if (in_array("code_agence", $unique)){//echo "colorstrip";
                  }?>">
                      <?= $customer->code_agence;?>
                 
                  </div>
                </div>
              </div>

              
              <div class="col-xs-3">
                <div class="form-group">
                  <label>Numéro de compte</label>
                  <div id="tab-details" class="<?php if (in_array("account_no", $unique)){//echo "colorstrip";
                  }?>"> 
                  <?= $customer->account_no;?>
                  </div>
                </div>
              </div>

             
               <div class="col-xs-2">
                <div class="form-group">
                  <label>RIB </label>
                  <div id="tab-details" class="<?php if (in_array("rib4", $unique)){//echo "colorstrip"; 
                  }?>"> 
                  <?= $customer->rib4;?>
                    </div>
                </div>
              </div>

             
              <div class="col-xs-2">
                <div class="form-group">
                  <label>Devise</label>
                  <div id="tab-details" class="<?php if (in_array("devise", $unique)){//echo "colorstrip"; 
                  }?>">
                      <?= $customer->devise;?>
                   
                  </div>
                </div>
              </div>
              
             

              
              
             
            </div>

            <div class="row">

               <div class="col-xs-3">
                        <div class="form-group">
                          <label>N° Carte Bancaire</label>  
                           <div id="tab-details" class="<?php if (in_array("carte_bancaire", $unique)){echo "colorstrip";
                           }?>"> 
                           <?= $customer->carte_bancaire;?>
                   
                  </div>
                
              </div>

                  </div>


              <div class="col-xs-3">
                <div class="form-group">
                  <label>Identifiant National </label>
                  <div id="tab-details" class="<?php if (in_array("ibu", $unique)){//echo "colorstrip";
                  }?>">  
                  <?= $customer->ibu;?>
                    
                  </div>
                </div>
              </div>
           
            
              <div class="col-xs-3">
                <div class="form-group">
                  <label>Nature de la Relation </label>
                  <div id="tab-details" class="<?php if (in_array("nature_relation", $unique)){//echo "colorstrip";
                  }?>">  
                  <?= $customer->nature_relation;?>
                    
                 </div>
                </div>
              </div>
              <div class="col-xs-3">
                <div class="form-group">
                  <label>Categorie Clientèle </label>
                  <div id="tab-details" class="<?php if (in_array("cat_client", $unique)){//echo "colorstrip";
                  }?>"> 
                  <?= $customer->cat_client;?>
                    
                    </div>
                </div>
              </div>
              
             

                    
            </div>

            <div class="row">

              <div class="col-xs-3">
                <div class="form-group">
                  <label> Type De Clientele</label>
                  <div id="tab-details" class="<?php if (in_array("typeDeClientele", $unique)){//echo "colorstrip"; 
                  }?>">
                      <?= $customer->typeDeClientele;?>
                     
                  </div>
                </div>
              </div>


              <div class="col-xs-3">
                <div class="form-group">
                  <label>Etat Dossier KYC </label> 
                  <div id="tab-details" class="<?php if (in_array("dossierkyc", $unique)){//echo "colorstrip";
                  }?>">
                      <?= $customer->dossierkyc;?>
                    
                  </div>
                </div>
              </div>
               

                <div class="col-xs-3">
                  <div class="form-group">
                      
                    <label>Date Prochaine Revision </label>
                    <div id="tab-details" class="<?php if (in_array("prochaineRevision", $unique)){//echo "colorstrip";
                    }?>"> 
                    <?php
                  
                  if($customer->prochaineRevision){
                  echo date("d-m-Y", strtotime($customer->prochaineRevision));
                  }?>
                     
                      </div>
          
                  </div>
                </div>
              
              <div class="col-xs-3">
                <div class="form-group">
                  <label>Selection Clientelle</label>
                  <div id="tab-details" class="<?php if (in_array("segmentation", $unique)){//echo "colorstrip"; 
                  }?>">  
                  <?= $customer->segmentation;?>
                    
                  </div>
                </div>
              </div>
              <div class="col-xs-3">
                <div class="form-group">
                  <label>Cotation Risque</label>
                  <div id="tab-details" class="<?php if (in_array("risk_level", $unique)){//echo "colorstrip";
                  }?>"> 
                  <?= $customer->risk_level;?>
                  
                 </div>
                </div>
              </div>
              <div class="col-xs-3">
                <div class="form-group">
                    <?php 
                    // print_r($customer)
                    ;?>
                  <label>Date de Cotation</label>
                  <div id="tab-details" class="<?php if (in_array("risk_level_date", $unique)){//echo "colorstrip"; 
                  }?>"> 
                  <?= $customer->risk_level_date;?>
                    
                 </div>
                </div>
              </div>
              
              
              <div class="col-xs-3">
                        <div class="form-group">
                          <label>Montant Autorisation en Code Atlas</label>
                          <div id="tab-details" class="<?php if (in_array("authCode", $unique)){//echo "colorstrip"; 
                          }?>"> 
                          <?= $customer->authCode;?>
                    
                    </div>
              
                        </div>
                      </div>

                      <div class="col-xs-3">
                        <div class="form-group">
                          <label>Date Echeance Autorisation</label>
                          <div id="tab-details" class="<?php if (in_array("authDate", $unique)){//echo "colorstrip"; 
                          }?>"> 
                          <?= $customer->authDate;?>
                    
                    </div>
                
                        </div>
                      </div>
            </div>


            <div class="row">

              <div class="col-xs-3">
                <div class="form-group">
                  <label>Nom Gestionnaire</label>
                  <div id="tab-details" class="<?php if (in_array("nomGestionnaire", $unique)){//echo "colorstrip";
                  }?>"> 
                  <?= $customer->nomGestionnaire;?>
                    
                  </div>
                </div>
              </div>

              <div class="col-xs-3">
                <div class="form-group">
                  <label>Code Gestionnaire</label>
                  <div id="tab-details" class="<?php if (in_array("codeGestionnaire", $unique)){//echo "colorstrip"; 
                  }?>"> 
                  <?= $customer->codeGestionnaire;?>
                     
                  </div>
                </div>
              </div>

              <div class="col-xs-3">
                <div class="form-group">
                  <label>État Autorisation </label>
                  <div id="tab-details" class="<?php if (in_array("etatAutorisation", $unique)){//echo "colorstrip"; 
                  }?>"> 
                  <?= $customer->etatAutorisation;?>
                     
                  </div>
        
                </div>
              </div>

              <div class="col-xs-3">
                <div class="form-group">
                  <label> Surveillance </label>
                  <div id="tab-details" class="<?php if (in_array("Surveillance", $unique)){//echo "colorstrip";
                  }?>">
                      <?= $customer->Surveillance;?>
                   
                  </div>
        
                </div>
              </div>


            </div>

            <div class="row">
              <div class="col-xs-3">
                <div class="form-group">
                  <label>Deces </label>
                  <div id="tab-details" class="<?php if (in_array("Deces", $unique)){//echo "colorstrip";
                  }?>"> 
                  <?= $customer->Deces;?>
                     
                  </div>
        
                </div>
              </div>

              <div class="col-xs-3">
                <div class="form-group">
                  <label>Contentieux</label>
                  <div id="tab-details" class="<?php if (in_array("Contexntieux", $unique)){//echo "colorstrip"; 
                  }?>"> 
                  <?= $customer->Contexntieux;?>
                    
                  </div>
                </div>
              </div>

              <div class="col-xs-3">
                <div class="form-group">
                  <label> Interdit </label>
                  <div id="tab-details" class="<?php if (in_array("Interdit", $unique)){//echo "colorstrip"; 
                  }?>"> 
                  <?= $customer->Interdit;?>
                    
                  </div>
                </div>
              </div>

              <div class="col-xs-3">
                <div class="form-group">
                  <label>Indicateur Pep</label>
                  <div id="tab-details" class="<?php if (in_array("pep", $unique)){//echo "colorstrip"; 
                  }?>"> 
                  <?= $customer->pep;?>
                    
                  </div>  
      
                </div>
              </div>

            </div>

            <div class="row">

              <div class="col-xs-3">
                <div class="form-group">
                  <label>Niveau De Vigilance</label>
                  <div id="tab-details" class="<?php if (in_array("niveiu", $unique)){//echo "colorstrip"; 
                  }?>"> 
                  <?= $customer->niveiu;?>
                   
                  </div>
                 </div>
              </div>

              <div class="col-xs-3">
                <div class="form-group">
                <label> Date De Derniere Evaluation</label>
                  <div id="tab-details" class="<?php if (in_array("datedernier", $unique)){//echo "colorstrip";
                  }?>"> 
                    <?= $customer->datedernier;?>
                    
                  </div>
                </div>
              </div>


            </div>

              
             
            
          
             <!--  </form>     -->                   
       <!--  </div> -->
    </form>
      </div>
  </div>
  </div>
   </div>
  </div>
  </div>
  </div>
<center>
    <style type="text/css">
        @media print {
  .hidden-print {
    visibility: hidden !important;
  }
}
    </style>
            <button class="btn btn-primary hidden-print" id="printPageButton" onclick="myfunction()" style="position: relative;">Print Page</button>
        </center>    



</body>
    <script type="text/javascript">
function myfunction(){
window.print();
}
</script>
</html>
