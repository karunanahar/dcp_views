<?php 
$documentArray1 = 0;
if(isset($documentArray))
	$documentArray1 = sizeof($documentArray); 
$customer=(array) json_decode($appformD['customer_data']); 
$databinding=(array) json_decode($appformD['databinding']); 
// echo "<pre>"; 
// print_r($appformD); 
// die;
// print_r($riskcurrentmonthlyvrefit); 
$convert=new ConvertNumberToText();

							
								if((($customer['cat_employeurs']) == "Public Civil 25") || (($customer['cat_employeurs']) == "Prive 25") || (($customer['cat_employeurs']) == "Public Corps 25")){
									$loandate= '25';
								}else if((($customer['cat_employeurs']) == "Prive 20") || (($customer['cat_employeurs']) == "Autres 20")){
									$loandate='20';
								}else if((($customer['cat_employeurs']) == "Prive 30") || (($customer['cat_employeurs']) == "Organisation internationales")){
									$loandate='30';
								}else{
									$loandate='30';
								}
								
								
?>

<html>
<head>
<style type="text/css">
<!--
body { font-family: Arial; font-size: 17.6px }
.pos { position: absolute; z-index: 0; left: 0px; top: 0px }
-->
</style>
<link rel="stylesheet" href="<?php echo base_url('assets/css/compiled/document_css.css" type="text/css');?>" media='all'/>
</head>
<body>
<nobr><nowrap>
<div class="pos" id="_0:0" style="top:0">
<img name="_1180:826" class="common_document_logo1" src="<?php echo  base_url(); ?>/assets/logo2.png" style="margin-left: 9%; margin-top: 3%;" ></div>
<!--<div class="pos" id="_110:76" style="top:76;left:110">-->
<!--<span id="_14.1" style=" font-family:Arial; font-size:14.1px; color:#222222">-->
<!--BANQUE INTERNATIONALE</span>-->
<!--</div>-->
<!--<div class="pos" id="_110:90" style="top:90;left:110">-->
<!--<span id="_13.0" style=" font-family:Arial; font-size:13.0px; color:#282828">-->
<!--POUR LE COMMERCE</span>-->
<!--</div>-->
<!--<div class="pos" id="_110:105" style="top:105;left:110">-->
<!--<span id="_13.7" style=" font-family:Arial; font-size:13.7px; color:#2f2f2f">-->
<!--ET L'INDUSIRIE DU GABON</span>-->
<!--</div>-->
<div class="pos" id="_544:186" style="top:186;left:544">

</div>
<div class="pos" id="_333:213" style="top:213;left:333">
<span id="_19.2" style="font-weight:bold; font-family:Arial; font-size:19.2px; color:#1f1f1f">
ACTE DE PRET N&#176; 3</span>
</div>
<div class="pos" id="_57:258" style="top:258;left:57">
<span id="_11.4" style=" font-family:Arial; font-size:11.4px; color:#3b3b3b">
Je soussign&#233; (1) &#133;&#133;&#133;&#133;&#133;&#133;<span style="font-weight:bold; color:#595959"> </span><span style=" color:"> <?php echo ucfirst($customer['first_name'])." " ?: '-';?><?php echo ucfirst($customer['middle_name'])." " ?: '';?><?php echo ucfirst($customer['last_name']) ?: '-';?> &#133;&#133;&#133;&#133;&#133;&#133;&#133;&#133;&#133;&#133;&#133;.</span></span>
</div>
<div class="pos" id="_60:284" style="top:284;left:60">
<span id="_11.4" style=" font-family:Arial; font-size:11.4px; color:#4f4f4f">
N&#233; le &#133;&#133;&#133;&#133;&#133;&#133;<span style=" font-family:Times New Roman; color:#000000"> </span><span style=" color:"> <?php  echo ($customer['dob']) ? (date("d-m-Y", strtotime($customer['dob']))) : ""; ?>  &#133;&#133;&#133;&#133;.. &#224; &#133;&#133;&#133;&#133;&#133;&#133;&#133;&#133;</span><span style=" font-family:Times New Roman; color:#000000"> </span><span style=" color:"> <?php  echo ($customer['birthplace']);?> &#133;&#133;&#133;&#133;&#133; </span></span>
</div>
<div class="pos" id="_59:316" style="top:316;left:59">
<span id="_12.6" style=" font-family:Arial; font-size:12.6px; color:#2b2b2b">
D&#233;murant &#224; &#133;&#133;&#133;&#133;&#133;&#133;&#133;<span id="_13.2" style="font-weight:bold; font-size:13.2px; color:#595959"> </span><span id="_13.2" style=" font-size:13.2px; color:"> <?php  echo ($customer['resides_address']);?> <?php  echo ($customer['city_id']);?>  </span> &#133;&#133;&#133;&#133;&#133;&#133;&#133;&#133;&#133;&#133;&#133;&#133;&#133;&#133;&#133;&#133;&#133;..</span>
</div>
<div class="pos" id="_59:336" style="top:336;left:59">
<span id="_11.4" style=" font-family:Arial; font-size:11.4px; color:#333333">
reconnais devoir &#224;la AFG BANK GABON</span>
</div>
<div class="pos" id="_58:367" style="top:367;left:58">
<span id="_11.8" style=" font-family:Arial; font-size:11.8px; color:#333333">
La somme de<span id="_11.2" style="font-weight:bold; font-size:11.2px; color:#595959"> </span><span id="_11.2" style=" font-size:11.2px; color:#595959"> &#133;&#133;<?php echo number_format($appformD['amount'],0,',',' ');?>&#133;&#133;&#133;&#133;&#133;&#133;</span><span style=" color:#2a2a2a"> F. CFA re&#231;ue &#224; titre de pr&#234;t et port&#233;e au cr&#233;dit de mon</span></span>
</div>
<div class="pos" id="_58:385" style="top:385;left:58">
<span id="_12.9" style=" font-family:Arial; font-size:12.9px; color:#353535">
compte N&#176;</span>
</div>
<div class="pos" id="_132:385" style="top:385;left:132">
<span id="_11.9" style=" font-family:Arial; font-size:11.9px; color:#3a3a3a">
<span id="_11.3" style="font-weight:bold; font-size:11.3px; color:#595959"> </span><span id="_11.3" style=" font-size:11.3px; color:"> <?php  echo ($customer['flexcube_acct']);?></span> ........chez son Si&#232;ge de.<span id="_11.3" style="font-weight:bold; font-size:11.3px; color:#595959"> </span><span id="_11.3" style=" font-size:11.3px; color:"> <?php echo $appformD['branch_name'];?> </span><span style=" color:#202020"> &#133;
<span style="text-align: center;display: inline-block;">le</span>
<span style="border-bottom: dashed 1px;display: inline-block;"><?php echo ($appformD['cdate']) ? (date("d-m-Y", strtotime($appformD['cdate']))) : "";?> </span>
</div>
<div class="pos" id="_59:416" style="top:416;left:59">
<span id="_11.6" style=" font-family:Arial; font-size:11.6px; color:#2d2d2d">
La AFG BANK GABON ne sera pas tenue &#224; l'&#233;gard</span>
</div>
<div class="pos" id="_58:434" style="top:434;left:58">
<span id="_11.9" style=" font-family:Arial; font-size:11.9px; color:#323232">
de quiconque de surveiller l&#146;emploi des fonds. Je m'engage &#224; rembourser ce pr&#234;t en &#133;.. <?php echo $appformD['loan_term']?> &#133;..termes mensuels.</span>
</div>
<div class="pos" id="_58:452" style="top:452;left:58">
<span id="_11.9" style=" font-family:Arial; font-size:11.9px; color:#2b2b2b">
d&#146;un montant constant de &#133;..<?php echo number_format($appformD['pmnt'],0,',',' ')?>.. francs d&#233;compt&#233; sur le montant en capital restant d&#251; apr&#232;s chaque &#233;ch&#233;ance,</span>
</div>
<div class="pos" id="_58:471" style="top:471;left:58">
<span id="_11.9" style=" font-family:Arial; font-size:11.9px; color:#323232">
ce programme d'amortissement ne pourra en aucun cas &#234;tre modifi&#233;.</span>
</div>
<div class="pos" id="_59:489" style="top:489;left:59">
<span id="_11.9" style=" font-family:Arial; font-size:11.9px; color:#353535">
Le premier remboursement aura lieu le .... &#133;.. <?php echo  $loandate."-".$databinding[0]->month."-".$databinding[0]->years?><span style="font-weight:bold; color:"> </span><span style=" color:#434343"> &#133;.., le dernier le &#133;&#133;</span><span style=" font-family:Times New Roman; color:#000000"> </span><span style=" color:"> <?php echo $loandate."-".end($databinding)->month."-".end($databinding)->years;?> &#133;&#133;...</span></span>
</div>
<div class="pos" id="_58:520" style="top:520;left:58">
<span id="_11.9" style=" font-family:Arial; font-size:11.9px; color:#383838">
Le <span style=" color:#222222"> r&#232;glement </span><span style=" color:#333333"> de </span><span style=" color:#353535"> ces </span><span style=" color:#2a2a2a"> termes </span><span style=" color:#2b2b2b"> sera </span><span style=" color:#202020"> automatiquement </span><span style=" color:#252525"> effectu&#233; </span><span style=" color:#2b2b2b"> par </span><span style=" color:#2d2d2d"> le </span><span style=" color:#2a2a2a"> d&#233;bit </span><span style=" color:#353535"> de </span><span style=" color:#3b3b3b"> mon </span><span style=" color:#2a2a2a"> compte </span><span style=" color:#202020"> sus-indiqu&#233; </span><span style=" color:#1f1f1f"> que </span> je <span style=" color:#3a3a3a"> m'engage </span><span style=" color:#3a3a3a"> &#224; </span></span>
</div>
<div class="pos" id="_58:538" style="top:538;left:58">
<span id="_12.4" style=" font-family:Arial; font-size:12.4px; color:#282828">
approvisionner &#224; cette fin. Je donne &#224; cet effet mandat irr&#233;vocable permanent &#224; la AFG BANK GABON </span>
</div>
<!--<div class="pos" id="_58:557" style="top:557;left:58">-->
<!--<span id="_11.5" style=" font-family:Arial; font-size:11.5px; color:#2f2f2f">-->
<!--ET L'INDUSTRIE DU GABON.</span>-->
<!--</div>-->
<div class="pos" id="_59:575" style="top:575;left:59">
<span id="_12.2" style=" font-family:Arial; font-size:12.2px; color:#2f2f2f">
Par ailleurs, je m'engage &#224; supporter les frais, taxes et pr&#233;l&#232;vements de toute nature, pr&#233;sents ou &#224; venir dont pourrait &#234;tre frapp&#233; </span>
</div>
<div class="pos" id="_59:593" style="top:593;left:59">
<span id="_12.2" style=" font-family:Arial; font-size:12.2px; color:#3d3d3d">
le pr&#233;sent contras, ainsi que les frais et honoraires des pr&#233;sentes et ceux qui en seront la cons&#233;quence.</span>
</div>
<div class="pos" id="_58:612" style="top:612;left:58">
<span id="_12.2" style=" font-family:Arial; font-size:12.2px; color:#353535">
En cas de non-respect de l'une quelconque des clauses du pr&#233;sent acte et notamment en cas de d&#233;faut d'un seul des r&#232;glements </span>
</div>
<div class="pos" id="_58:630" style="top:630;left:58">
<span id="_12.2" style=" font-family:Arial; font-size:12.2px; color:#303030">
indiqu&#233;s ci-dessus, la totalit&#233; de la cr&#233;ance en principal, int&#233;r&#234;ts et accessoires deviendrait imm&#233;diatement et de plein droit exigible, </span>
</div>
<div class="pos" id="_58:648" style="top:648;left:58">
<span id="_11.7" style=" font-family:Arial; font-size:11.7px; color:#2d2d2d">
s'il convient &#224; la AFG BANK GABON et celle-ci aurait alors une enti&#232;re libert&#233; </span>
</div>
<div class="pos" id="_58:667" style="top:667;left:58">
<span id="_12.2" style=" font-family:Arial; font-size:12.2px; color:#252525">
d'action pour recouvrer ladite cr&#233;ance par toutes voies et moyens de droit.</span>
</div>
<div class="pos" id="_59:685" style="top:685;left:59">
<span id="_12.2" style=" font-family:Arial; font-size:12.2px; color:#2a2a2a">
En cas d'exigibilit&#233; anticip&#233;e ou d'atermoiement pour quelque cause que ce soit, les sommes devenues exigibles seront productives </span>
</div>
<div class="pos" id="_58:703" style="top:703;left:58">
<span id="_12.2" style=" font-family:Arial; font-size:12.2px; color:#4f4f4f">
d'int&#233;r&#234;ts au taux du pr&#233;sent pr&#234;t. Les dits int&#233;r&#234;ts &#233;chus et non pay&#233;s, se capitaliseront de plein droit &#224; compter du jour o&#249; ils seront </span>
</div>
<div class="pos" id="_58:721" style="top:721;left:58">
<span id="_12.2" style=" font-family:Arial; font-size:12.2px; color:#2f2f2f">
dus pour une ann&#233;e enti&#232;re et porteront eux-m&#234;mes int&#233;r&#234;ts au taux du pr&#233;sent pr&#234;t.</span>
</div>
<div class="pos" id="_58:739" style="top:739;left:58">
<span id="_12.2" style=" font-family:Arial; font-size:12.2px; color:#656565">
A peine d'exigibilit&#233; anticip&#233;e, je m'engage &#224; consentir &#224; la AFG BANK GABON </span>
</div>
<div class="pos" id="_58:758" style="top:758;left:58">
<span id="_12.2" style=" font-family:Arial; font-size:12.2px; color:#2a2a2a">
 une <span style="font-weight:bold; color:#252525"> provision </span><span style=" color:#1f1f1f"> de 10 % du montant du pr&#233;sent pr&#234;t &#224; titre de </span><span style="font-weight:bold; color:#1a1a1a"> revenue </span><span style=" color:#1d1d1d"> de </span><span style="font-weight:bold; color:#222222"> garantie. </span><span style=" color:#1f1f1f"> Lesquels seront log&#233;s dans un compte </span></span>
</div>
<div class="pos" id="_58:776" style="top:776;left:58">
<span id="_12.2" style=" font-family:Arial; font-size:12.2px; color:#222222">
AFG BANK GA identifiable &#224; tout moment. II est express&#233;ment convenu que dans le cas o&#249; pour quelque cause que ce soit, le pr&#233;sent pr&#234;t ne </span>
</div>
<div class="pos" id="_58:794" style="top:794;left:58">
<span id="_11.8" style=" font-family:Arial; font-size:11.8px; color:#1f1f1f">
serait pas rembours&#233; &#224; son &#233;ch&#233;ance, la provision restera acquise de plein droit &#224; la AFG BANK GABON </span>
</div>
<div class="pos" id="_58:813" style="top:813;left:58">
<span id="_11.8" style=" font-family:Arial; font-size:11.8px; color:#121212">
, quelque soit le montant des sommes impay&#233;es et  sans pr&#233;judice pour la AFG BANK GA d'une part, d'agir en </span>
</div>
<div class="pos" id="_58:831" style="top:831;left:58">
<span id="_12.2" style=" font-family:Arial; font-size:12.2px; color:#000000">
recouvrement &#224; mon encontre au titre des sommes impay&#233;es n'&#233;tant pas couvertes par la retenue de garantie et d'autre part d'agir </span>
</div>
<div class="pos" id="_58:849" style="top:849;left:58">
<span id="_12.2" style=" font-family:Arial; font-size:12.2px; color:#222222">
en dommages-int&#233;r&#234;ts au titre du pr&#233;judice subi du fait du non remboursement &#224; &#233;ch&#233;ance. En cas de <span style="font-weight:bold"> remboursement int&#233;gral sans </span></span>
</div>
<div class="pos" id="_58:868" style="top:868;left:58">
<span id="_12.2" style="font-weight:bold; font-family:Arial; font-size:12.2px; color:#222222">
incident du pr&#233;sent pr&#234;t, <span style="font-weight:normal"> cette </span><span style=" color:#202020"> revenue de garantie sera restitu&#233;e en totalit&#233; &#224; l'emprunteur </span><span style="font-weight:normal; color:#5d5d5d"> &#224; </span> l'&#233;ch&#233;ance. <span style="font-weight:normal; color:#2f2f2f"> Toutes les obligations </span></span>
</div>
<div class="pos" id="_58:886" style="top:886;left:58">
<span id="_12.2" style=" font-family:Arial; font-size:12.2px; color:#282828">
r&#233;sultant des pr&#233;sentes sont stipul&#233;es solidaires et indivisibles entre mes h&#233;ritiers et ayants droits de telle sorte que leur ex&#233;cution </span>
</div>
<div class="pos" id="_58:904" style="top:904;left:58">
<span id="_12.2" style=" font-family:Arial; font-size:12.2px; color:#2a2a2a">
pourra &#234;tre r&#233;clam&#233;e pour le tout &#224; n&#146;importe quel moment.</span>
</div>
<div class="pos" id="_59:935" style="top:935;left:59">
<span id="_12.2" style=" font-family:Arial; font-size:12.2px; color:#2b2b2b">
En outre je certifie, apr&#232;s avoir pris connaissance de l'article L 113-8 du code des assurances :</span>
</div>
<div class="pos" id="_78:953" style="top:953;left:78">
<span id="_12.2" style=" font-family:Arial; font-size:12.2px; color:#2f2f2f">
<li type="square">Ne pas &#234;tre actuellement en &#233;tat d'incapacit&#233; temporaire de travail, exercer mon activit&#233; professionnelle de fa&#231;on normale et </span>
</div>
<div class="pos" id="_87:971" style="top:971;left:87">
<span id="_12.2" style=" font-family:Arial; font-size:12.2px; color:#282828">
effective ;</span>
</div>
<div class="pos" id="_78:989" style="top:989;left:78">
<span id="_12.2" style=" font-family:Arial; font-size:12.2px; color:#2d2d2d">
<li type="square"><span style=" color:#5f5f5f"> N'&#234;tre atteint d'aucune infirmit&#233;, invalidit&#233;, maladie aigu&#235; ou chronique</span></span>
</div>
<div class="pos" id="_78:1007" style="top:1007;left:78">
<span id="_12.2" style=" font-family:Arial; font-size:12.2px; color:#2b2b2b">
<li type="square"><span style=" color:#404040"> Ne suivre aucun traitement ou r&#233;gime et ne pas &#234;tre sous surveillance m&#233;dicale.</span></span>
</div>
<div class="pos" id="_59:1039" style="top:1039;left:59">
<span id="_12.2" style=" font-family:Arial; font-size:12.2px; color:#484848">
En cas de remboursement anticip&#233;, apr&#232;s avoir fait la demande avec pr&#233;avis d&#146;un mois, je m&#146;engage &#224; reverser &#224; la Banque une </span>
</div>
<div class="pos" id="_59:1057" style="top:1057;left:59">
<span id="_12.2" style=" font-family:Arial; font-size:12.2px; color:#222222">
indemnit&#233; &#233;gale &#224; 5% (hors taxe) du capital effectivement rembours&#233; par anticipation.</span>
</div>
<div class="pos" id="_450:1092" style="top:1092;left:450">
<span id="_11.7" style=" font-family:Arial; font-size:11.7px; color:#000000">
Fait &#224; &#133;&#133;&#133;&#133;&#133;&#133;&#133;&#133;&#133;..&#133;&#133;&#133;&#133;, le &#133;&#133;/&#133;&#133;./&#133;&#133;&#133;</span>
</div>
<div class="pos" id="_450:1110" style="top:1110;left:450">
<span id="_12.4" style="font-style:italic; font-family:Arial; font-size:12.4px; color:#000000">
  Signature (2) </span>
</div>
<div class="pos" id="_446:1126" style="top:1165;left:59">
<span id="_10.3" style=" font-family:Arial; font-size:10.3px; color:#383838">
</span>
</div>
<div class="pos" id="_59:1133" style="top:1133;left:59">
<span id="_8.9" style=" font-family:Arial; font-size:8.9px; color:#4b4b4b">
(1) Nom et Pronoms dans l'ordre de I &#146;&#233;tat civil</span>
</div>
<div class="pos" id="_59:1145" style="top:1145;left:59">
<span id="_8.9" style=" font-family:Arial; font-size:8.9px; color:#323232">
(2) La signature doit &#234;tre pr&#233;c&#233;d&#233;e de la mention suivante :</span>
</div></br>
<div class="pos" id="_446:1138" style="top:1181;left:59">
<span id="_9.5" style=" font-family:Arial; font-size:9.5px; color:#3b3b3b">
"EN PRINCIPAL PLUS INTERETS, FRAIS ET ACCESSOIRES&#146;</span>
</div>
<div class="pos" id="_59:1156" style="top:1156;left:59">
<span id="_9.6" style=" font-family:Arial; font-size:9.6px; color:#3d3d3d">
LU ET APPROUVE BON POUR F. CFA - <?php echo strtoupper($convert->Convert($appformD['tpmnt'])) ; ?></span>

<style type="text/css">
          @media print {
            .hidden-print {
              visibility: hidden !important;
            }
          }
        </style>
        <center>
          <button class="btn btn-primary hidden-print" id="page-container" onclick="myfunction()" style="padding: 5px 10px; font-size: 15px;">Print Page</button>
        </center>
        <script type="text/javascript">
          function myfunction() {
            window.print();
          }
        </script>
</div>
</nowrap></nobr>
</body>
</html>
