<html>
<head><meta http-equiv=Content-Type content="text/html; charset=UTF-8">
<style type="text/css">
<!--
span.cls_007{font-family:"Trebuchet MS Bold Italic",serif;font-size:8.1px;color:rgb(0,0,0);font-weight:bold;font-style:italic;text-decoration: none}
div.cls_007{font-family:"Trebuchet MS Bold Italic",serif;font-size:8.1px;color:rgb(0,0,0);font-weight:bold;font-style:italic;text-decoration: none}
span.cls_011{font-family:Times,serif;font-size:10.0px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
div.cls_011{font-family:Times,serif;font-size:10.0px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
span.cls_017{font-family:Arial,serif;font-size:8.1px;color:rgb(0,0,0);font-weight:bold;font-style:normal;text-decoration: none}
div.cls_017{font-family:Arial,serif;font-size:8.1px;color:rgb(0,0,0);font-weight:bold;font-style:normal;text-decoration: none}
span.cls_022{font-family:Times,serif;font-size:8.1px;color:rgb(0,0,0);font-weight:bold;font-style:normal;text-decoration: none}
div.cls_022{font-family:Times,serif;font-size:8.1px;color:rgb(0,0,0);font-weight:bold;font-style:normal;text-decoration: none}
span.cls_003{font-family:"Trebuchet MS",serif;font-size:15.0px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
div.cls_003{font-family:"Trebuchet MS",serif;font-size:15.0px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
span.cls_010{font-family:Arial,serif;font-size:9.0px;color:rgb(0,0,0);font-weight:bold;font-style:normal;text-decoration: none}
div.cls_010{font-family:Arial,serif;font-size:9.0px;color:rgb(0,0,0);font-weight:bold;font-style:normal;text-decoration: none}
span.cls_023{font-family:Arial,serif;font-size:6.0px;color:rgb(0,0,0);font-weight:bold;font-style:normal;text-decoration: none}
div.cls_023{font-family:Arial,serif;font-size:6.0px;color:rgb(0,0,0);font-weight:bold;font-style:normal;text-decoration: none}
span.cls_024{font-family:Arial,serif;font-size:8.1px;color:rgb(0,0,0);font-weight:normal;font-style:italic;text-decoration: none}
div.cls_024{font-family:Arial,serif;font-size:8.1px;color:rgb(0,0,0);font-weight:normal;font-style:italic;text-decoration: none}
span.cls_012{font-family:Arial,serif;font-size:9.0px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
div.cls_012{font-family:Arial,serif;font-size:9.0px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
span.cls_013{font-family:Arial,serif;font-size:8.1px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
div.cls_013{font-family:Arial,serif;font-size:8.1px;color:rgb(0,0,0);font-weight:normal;font-style:normal;text-decoration: none}
span.cls_021{font-family:Arial,serif;font-size:10.0px;color:rgb(0,0,0);font-weight:normal;font-style:italic;text-decoration: none}
div.cls_021{font-family:Arial,serif;font-size:10.0px;color:rgb(0,0,0);font-weight:normal;font-style:italic;text-decoration: none}
span.cls_026{font-family:Arial,serif;font-size:10.0px;color:rgb(0,0,0);font-weight:bold;font-style:italic;text-decoration: none}
div.cls_026{font-family:Arial,serif;font-size:10.0px;color:rgb(0,0,0);font-weight:bold;font-style:italic;text-decoration: none}
span.cls_020{font-family:Arial,serif;font-size:9.0px;color:rgb(0,0,0);font-weight:bold;font-style:italic;text-decoration: none}
div.cls_020{font-family:Arial,serif;font-size:9.0px;color:rgb(0,0,0);font-weight:bold;font-style:italic;text-decoration: none}
-->
</style>
<script type="text/javascript" src="3ef98bda-40bc-11ea-a5fd-0cc47a792c0a_id_3ef98bda-40bc-11ea-a5fd-0cc47a792c0a_files/wz_jsgraphics.js"></script>
</head>
<body>
<div style="position:absolute;left:50%;margin-left:-297px;top:0px;width:595px;height:842px;border-style:outset;overflow:hidden">
<div style="position:absolute;left:0px;top:0px">
<img src="3ef98bda-40bc-11ea-a5fd-0cc47a792c0a_id_3ef98bda-40bc-11ea-a5fd-0cc47a792c0a_files/background1.jpg" width=595 height=842></div>
<div style="position:absolute;left:409.68px;top:36.84px" class="cls_007"><span class="cls_007">CADRE RESERVE A LA BANQUE</span></div>
<div style="position:absolute;left:400.44px;top:55.20px" class="cls_011"><span class="cls_011">CONDITIONS D’ELIGIBILITE</span></div>
<div style="position:absolute;left:363.84px;top:72.00px" class="cls_017"><span class="cls_017">L’emprunteur travaille dans une</span></div>
<div style="position:absolute;left:500.28px;top:73.08px" class="cls_022"><span class="cls_022">OBSERVATIONS</span></div>
<div style="position:absolute;left:363.84px;top:81.12px" class="cls_017"><span class="cls_017">entreprise éligible pour ce programme</span></div>
<div style="position:absolute;left:436.67px;top:90.36px" class="cls_017"><span class="cls_017">O/N:     I__I</span></div>
<div style="position:absolute;left:111.00px;top:99.72px" class="cls_003"><span class="cls_003">ATLANTIQUE PRET SCOLAIRE</span></div>
<div style="position:absolute;left:363.84px;top:108.72px" class="cls_017"><span class="cls_017">L’emprunteur  a au moins 12 mois</span></div>
<div style="position:absolute;left:135.72px;top:117.24px" class="cls_011"><span class="cls_011">CONDITIONS PARTICULIERES</span></div>
<div style="position:absolute;left:363.84px;top:117.84px" class="cls_017"><span class="cls_017">d’ancienneté chez son employeur</span></div>
<div style="position:absolute;left:363.84px;top:127.08px" class="cls_017"><span class="cls_017">actuel</span></div>
<div style="position:absolute;left:436.67px;top:136.20px" class="cls_017"><span class="cls_017">O/N:     I__I</span></div>
<div style="position:absolute;left:33.96px;top:140.64px" class="cls_010"><span class="cls_010">IDENTIFICATION</span></div>
<div style="position:absolute;left:363.84px;top:154.56px" class="cls_017"><span class="cls_017">Salaire mensuel : minimum</span><span class="cls_023"> </span><span class="cls_024">CFA</span></div>
<div style="position:absolute;left:33.96px;top:163.80px" class="cls_012"><span class="cls_012">N</span><span class="cls_013">OM(S) et PRENOM(S)</span><span class="cls_012">: I__________________________________________________________I</span></div>
<div style="position:absolute;left:363.84px;top:163.80px" class="cls_024"><span class="cls_024">50 000 (pas de minimum exigé pour les</span></div>
<div style="position:absolute;left:363.84px;top:172.92px" class="cls_024"><span class="cls_024">fonctionnaires)</span></div>
<div style="position:absolute;left:436.68px;top:182.16px" class="cls_017"><span class="cls_017">O/N:     I__I</span></div>
<div style="position:absolute;left:33.96px;top:184.44px" class="cls_012"><span class="cls_012">D</span><span class="cls_013">ATE DE NAISSANCE</span><span class="cls_012">: I__I__I I__I__I I__I__I__I__I</span></div>
<div style="position:absolute;left:363.84px;top:200.52px" class="cls_017"><span class="cls_017">L’emprunteur a un CDI/CDD couvrant</span></div>
<div style="position:absolute;left:33.96px;top:202.80px" class="cls_012"><span class="cls_012">A</span><span class="cls_013">DRESSE</span><span class="cls_012">: I___________________________________________________________________I</span></div>
<div style="position:absolute;left:363.84px;top:209.64px" class="cls_017"><span class="cls_017">la période de remboursement</span></div>
<div style="position:absolute;left:436.68px;top:218.88px" class="cls_017"><span class="cls_017">O/N:     I__I</span></div>
<div style="position:absolute;left:33.96px;top:223.44px" class="cls_012"><span class="cls_012">N° </span><span class="cls_013">PIECE IDENTITE</span><span class="cls_012">:   I_______________________I</span></div>
<div style="position:absolute;left:363.84px;top:237.24px" class="cls_017"><span class="cls_017">Relation avec la banque</span><span class="cls_013"> : Le compte</span></div>
<div style="position:absolute;left:363.84px;top:246.36px" class="cls_013"><span class="cls_013">est ouvert à la BACM depuis au moins 1</span></div>
<div style="position:absolute;left:33.96px;top:249.84px" class="cls_012"><span class="cls_012">PROFESSION: I_______________________________________________________________I</span></div>
<div style="position:absolute;left:363.84px;top:255.60px" class="cls_013"><span class="cls_013">mois et virement d’au moins un salaire</span></div>
<div style="position:absolute;left:363.84px;top:264.72px" class="cls_013"><span class="cls_013">reçu</span><span class="cls_017">.</span></div>
<div style="position:absolute;left:33.96px;top:270.48px" class="cls_012"><span class="cls_012">N°TELEPHONE: I__I__I I__I__I I__I__I I__I__I I__I</span></div>
<div style="position:absolute;left:436.67px;top:273.96px" class="cls_017"><span class="cls_017">O/N:     I__I</span></div>
<div style="position:absolute;left:363.84px;top:283.08px" class="cls_017"><span class="cls_017">Le client n’a ni engagement impayés</span></div>
<div style="position:absolute;left:363.84px;top:292.32px" class="cls_017"><span class="cls_017">ni douteux à la banque ou chez les</span></div>
<div style="position:absolute;left:33.96px;top:296.88px" class="cls_012"><span class="cls_012">EMPLOYEUR: I_______________________________________________________________I</span></div>
<div style="position:absolute;left:363.84px;top:301.44px" class="cls_017"><span class="cls_017">confrères</span></div>
<div style="position:absolute;left:436.67px;top:310.68px" class="cls_017"><span class="cls_017">O/N:     I__I</span></div>
<div style="position:absolute;left:33.96px;top:317.52px" class="cls_012"><span class="cls_012">ADRESSE: I______________________________I</span></div>
<div style="position:absolute;left:396.48px;top:336.48px" class="cls_021"><span class="cls_021">PIECES JOINTES AU DOSSIER</span></div>
<div style="position:absolute;left:33.96px;top:343.92px" class="cls_012"><span class="cls_012">DATE D’EMBAUCHE: I__I__I I__I__I I__I__I__I__I</span></div>
<div style="position:absolute;left:500.28px;top:356.52px" class="cls_022"><span class="cls_022">OBSERVATIONS</span></div>
<div style="position:absolute;left:363.84px;top:362.64px" class="cls_017"><span class="cls_017">Conditions générales (convention)</span></div>
<div style="position:absolute;left:33.96px;top:364.56px" class="cls_012"><span class="cls_012">NUMERO DE MATRICULE: I_________________I</span></div>
<div style="position:absolute;left:447.59px;top:371.76px" class="cls_017"><span class="cls_017">O/N:     I__I</span></div>
<div style="position:absolute;left:363.84px;top:381.00px" class="cls_017"><span class="cls_017">Bulletin d’adhésion assurance décès</span></div>
<div style="position:absolute;left:33.96px;top:387.24px" class="cls_010"><span class="cls_010">REVENUS / CHARGES</span></div>
<div style="position:absolute;left:447.59px;top:390.12px" class="cls_017"><span class="cls_017">O/N:     I__I</span></div>
<div style="position:absolute;left:363.84px;top:399.36px" class="cls_017"><span class="cls_017">Billet à ordre</span></div>
<div style="position:absolute;left:447.59px;top:408.48px" class="cls_017"><span class="cls_017">O/N:     I__I</span></div>
<div style="position:absolute;left:33.96px;top:412.44px" class="cls_012"><span class="cls_012">MONTANT SALAIRE NET MENSUEL (en FCFA) :</span></div>
<div style="position:absolute;left:363.84px;top:417.72px" class="cls_017"><span class="cls_017">Pièce d’identité en cours de validité</span></div>
<div style="position:absolute;left:33.96px;top:422.76px" class="cls_012"><span class="cls_012">I__________________________________________________________I</span></div>
<div style="position:absolute;left:447.59px;top:426.84px" class="cls_017"><span class="cls_017">O/N:     I__I</span></div>
<div style="position:absolute;left:363.84px;top:436.08px" class="cls_017"><span class="cls_017">1 dernier bulletin de salaire</span></div>
<div style="position:absolute;left:33.96px;top:443.40px" class="cls_010"><span class="cls_010">CHARGES AVANT PROJET</span></div>
<div style="position:absolute;left:447.59px;top:445.20px" class="cls_017"><span class="cls_017">O/N:     I__I</span></div>
<div style="position:absolute;left:87.36px;top:453.72px" class="cls_012"><span class="cls_012">Engagements chez BANQUE ATLANTIQUE CAMEROUN</span></div>
<div style="position:absolute;left:363.84px;top:454.44px" class="cls_017"><span class="cls_017">Un justificatif de domicile récent</span></div>
<div style="position:absolute;left:87.36px;top:464.04px" class="cls_012"><span class="cls_012">Autres</span></div>
<div style="position:absolute;left:447.59px;top:463.56px" class="cls_017"><span class="cls_017">O/N:     I__I</span></div>
<div style="position:absolute;left:363.84px;top:472.80px" class="cls_017"><span class="cls_017">Une attestation de virement irrévocable</span></div>
<div style="position:absolute;left:33.96px;top:474.36px" class="cls_012"><span class="cls_012">TAUX D’ENDETTEMENT AVANT PROJET : I__I__I%</span></div>
<div style="position:absolute;left:451.31px;top:481.92px" class="cls_017"><span class="cls_017">O/N:     I__I</span></div>
<div style="position:absolute;left:363.84px;top:491.16px" class="cls_017"><span class="cls_017">Une attestation de non redevance</span></div>
<div style="position:absolute;left:33.96px;top:494.64px" class="cls_010"><span class="cls_010">CONDITIONS FINANCIERES DU PRÊT</span></div>
<div style="position:absolute;left:451.31px;top:500.28px" class="cls_017"><span class="cls_017">O/N:     I__I</span></div>
<div style="position:absolute;left:363.84px;top:509.52px" class="cls_017"><span class="cls_017">Autres</span></div>
<div style="position:absolute;left:33.96px;top:519.84px" class="cls_012"><span class="cls_012">CAPITAL EMPRUNTE (en FCFA)</span><span class="cls_013">:</span></div>
<div style="position:absolute;left:451.31px;top:518.64px" class="cls_017"><span class="cls_017">O/N:     I__I</span></div>
<div style="position:absolute;left:33.96px;top:530.28px" class="cls_012"><span class="cls_012">I__________________________________________________________I</span></div>
<div style="position:absolute;left:433.55px;top:536.04px" class="cls_026"><span class="cls_026">APPROBATIONS</span></div>
<div style="position:absolute;left:33.96px;top:550.92px" class="cls_012"><span class="cls_012">DUREE (en mois):       I__I__I</span></div>
<div style="position:absolute;left:196.20px;top:550.92px" class="cls_012"><span class="cls_012">DIFFERE (O/N):</span></div>
<div style="position:absolute;left:264.24px;top:550.92px" class="cls_012"><span class="cls_012">I__I</span></div>
<div style="position:absolute;left:431.28px;top:555.36px" class="cls_017"><span class="cls_017">GESTIONNAIRE</span></div>
<div style="position:absolute;left:411.12px;top:564.60px" class="cls_013"><span class="cls_013">Avis favorable</span></div>
<div style="position:absolute;left:33.96px;top:571.56px" class="cls_012"><span class="cls_012">TAUX D’INTERET HT: I__I__I%</span></div>
<div style="position:absolute;left:411.11px;top:582.96px" class="cls_013"><span class="cls_013">Avis défavorable</span></div>
<div style="position:absolute;left:33.96px;top:592.20px" class="cls_012"><span class="cls_012">FRAIS DE DOSSIER PRÊT (en FCFA) :</span></div>
<div style="position:absolute;left:192.14px;top:592.20px" class="cls_012"><span class="cls_012">I______________________________I</span></div>
<div style="position:absolute;left:363.84px;top:592.08px" class="cls_013"><span class="cls_013">Date :</span></div>
<div style="position:absolute;left:363.84px;top:601.32px" class="cls_013"><span class="cls_013">Signature :</span></div>
<div style="position:absolute;left:431.28px;top:610.44px" class="cls_017"><span class="cls_017">CHEF D’AGENCE</span></div>
<div style="position:absolute;left:33.96px;top:612.84px" class="cls_012"><span class="cls_012">PRIME D’ ASSURANCE (en FCFA): I______________________________I</span></div>
<div style="position:absolute;left:412.91px;top:628.80px" class="cls_013"><span class="cls_013">Avis favorable</span></div>
<div style="position:absolute;left:33.96px;top:633.48px" class="cls_012"><span class="cls_012">TAUX D’ENDETTEMENT APRES PROJET : I__I__I%</span></div>
<div style="position:absolute;left:412.91px;top:638.04px" class="cls_013"><span class="cls_013">Avis défavorable</span></div>
<div style="position:absolute;left:33.96px;top:656.04px" class="cls_010"><span class="cls_010">GARANTIES</span></div>
<div style="position:absolute;left:363.84px;top:656.40px" class="cls_013"><span class="cls_013">Date :</span></div>
<div style="position:absolute;left:363.84px;top:665.52px" class="cls_013"><span class="cls_013">Signature :</span></div>
<div style="position:absolute;left:434.88px;top:674.76px" class="cls_017"><span class="cls_017">DCPR / CIC</span></div>
<div style="position:absolute;left:33.96px;top:681.36px" class="cls_012"><span class="cls_012">ATTESTION DE VIREMENT IRREVOCABLE (O/N):     I__I</span></div>
<div style="position:absolute;left:412.91px;top:693.12px" class="cls_013"><span class="cls_013">Avis favorable</span></div>
<div style="position:absolute;left:33.96px;top:696.84px" class="cls_012"><span class="cls_012">ASSURANCE DECES (O/N):</span></div>
<div style="position:absolute;left:211.44px;top:696.84px" class="cls_012"><span class="cls_012">I__I</span></div>
<div style="position:absolute;left:411.11px;top:702.24px" class="cls_013"><span class="cls_013">Avis défavorable</span></div>
<div style="position:absolute;left:33.96px;top:712.32px" class="cls_010"><span class="cls_010">CLAUSE D’ACCEPTATION GENERALE</span></div>
<div style="position:absolute;left:363.84px;top:711.48px" class="cls_013"><span class="cls_013">Date :</span></div>
<div style="position:absolute;left:363.84px;top:720.60px" class="cls_013"><span class="cls_013">Signature :</span></div>
<div style="position:absolute;left:414.83px;top:729.84px" class="cls_017"><span class="cls_017">DIRECTION DES RISQUES</span></div>
<div style="position:absolute;left:34.20px;top:735.36px" class="cls_013"><span class="cls_013">Le soussigné certifie exactes et sincères les déclarations sur la présente. Il reconnaît avoir reçu un exemplaire</span></div>
<div style="position:absolute;left:33.96px;top:744.48px" class="cls_013"><span class="cls_013">conditions particulières et des conditions générales, et déclare y adhérer pleinement sans aucune réserve.</span></div>
<div style="position:absolute;left:418.43px;top:748.20px" class="cls_013"><span class="cls_013">Avis favorable</span></div>
<div style="position:absolute;left:69.36px;top:762.96px" class="cls_012"><span class="cls_012">Fait à ____________________________, le______________________</span></div>
<div style="position:absolute;left:416.63px;top:766.56px" class="cls_013"><span class="cls_013">Avis défavorable</span></div>
<div style="position:absolute;left:133.44px;top:773.28px" class="cls_012"><span class="cls_012">(Signature précédée de la mention « </span><span class="cls_020">Lu et approuvé </span><span class="cls_012">»)</span></div>
<div style="position:absolute;left:363.84px;top:775.68px" class="cls_013"><span class="cls_013">Date :</span></div>
<div style="position:absolute;left:363.84px;top:781.20px" class="cls_013"><span class="cls_013">Signature</span>
<br><br>
<button class="btn btn-primary hidden-print" id="printPageButton" onclick="myfunction()" >
Print Page</button></div>

</div>

<script type="text/javascript">
	function myfunction(){
		window.print();
	}
</script>
</body>
</html>
