<?php 
$documentArray1 = 0;
if(isset($documentArray))
	$documentArray1 = sizeof($documentArray); 
$customer=(array) json_decode($appformD['customer_data']);
$convert=new ConvertNumberToText(); 
?>
<html>
    <head>
        <style>
			@page {
				margin: 0;
			}
		</style>
		<link rel="stylesheet" href="<?php echo base_url('assets/css/compiled/document_css.css" type="text/css');?>" media='all'/>
	</head>
	<p style="page-break-before: always;">&nbsp;</p>
    <body translate="no" style="background-color: #fff; font-family: Open Sans, sans-serif; font-size: 100%; font-weight: 400; line-height: 1.4; color: #000; margin: 0;">
        <table style="width: 700px; background-color: #fff; margin: 0px auto;" >
            <tbody>
                <tr>
                    <td>
                        <table style="width: 100%; margin-top: 1px;">
                            <tbody>
                                <tr>
									<td style="width: 80px; font-size: 11px;">
										<img class="letterDeDecision_logo" src="<?php echo  base_url(); ?>assets/logo2.png"/>
									</td>
									<td style="width: 400px; font-size: 11px;">
										<span style="font-weight: bold; font-size: 17px; padding-right: 20px;">
											DECLARATION DE CESSION VOLONTAIRE DE SALAIRE
										</span> 
									</td>
                                </tr> 
                            </tbody>
                        </table>
                    </td>
                </tr>
                <br>
                <tr>
                    <td>
                        <table style="width: 100%;">
                            <tbody>
                                <tr>
                                    <td style="width: 100%; vertical-align: top; padding-right: 10px;">
                                        <table style="width: 100%;">
                                            <tbody>
                                                <tr>
                                                    <td colspan="2" style="font-size: 15px; font-weight: normal;">
                                                        <div style="display: flex;">
                                                            <span style="display: block; width: 347px;">Enregistrement au Greffe Civil le : </span>
                                                            <span style="display: block; width: 100%; "><input type="text"></span>
                                                        </div>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td colspan="2" style="height:3px; width: 100%;"></td>
                                                </tr>
												<tr>
                                                    <td colspan="2" style="font-size: 15px; font-weight: normal;">
                                                        <div style="display: flex;">
                                                            <span style="display: block; width: 347px;">Sous le numéro :  </span>
                                                            <span style="display: block; width: 100%; "><input type="text"></span>
                                                        </div>
                                                    </td>
                                                </tr>
                                                            <br>
                                                <tr>
                                                    <td colspan="2" style="height:3px; width: 100%;"></td>
                                                </tr>
												 <tr>
                                                    <td colspan="2" style="font-size: 15px; font-weight: normal;">
                                                        <div style="display: flex;">
                                                            <span style="display: block; width: 347px;">Nom : </span>
                                                            <span style="display: block; width: 100%; ">  <?php echo ucfirst($customer['last_name']) ?: '-';?></span>
                                                        </div>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td colspan="2" style="height:3px; width: 100%;"></td>
                                                </tr>
												<tr>
                                                    <td colspan="2" style="font-size: 15px; font-weight: normal;">
                                                        <div style="display: flex;">
                                                            <span style="display: block; width: 347px;">Prénom :  </span>
                                                            <span style="display: block; width: 100%; ">  <?php echo ucfirst($customer['first_name'])." " ?: '-';?></span>
                                                        </div>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td colspan="2" style="height:3px; width: 100%;"></td>
                                                </tr>
												
												<tr>
                                                    <td colspan="2" style="font-size: 15px; font-weight: normal;">
                                                        <div style="display: flex;">
                                                            <span style="display: block; width: 347px;">Adresse :  </span>
                                                            <span style="display: block; width: 100%; "> <?php echo ucfirst($customer['street'])." " ?: '-';?> <?php echo ucfirst($customer['alternateAddress'])." " ?: '-';?> <?php echo ucfirst($customer['state_of_issue'])." " ?: '-';?></span>
                                                        </div>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td colspan="2" style="height:3px; width: 100%;"></td>
                                                </tr>
												<tr>
                                                    <td colspan="2" style="font-size: 15px; font-weight: normal;">
                                                        <div style="display: flex;">
                                                            <span style="display: block; width: 347px;">Matricule :  </span>
                                                            <span style="display: block; width: 100%; "> <input type="text">  </span>
                                                        </div>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td colspan="2" style="height:3px; width: 100%;"></td>
                                                </tr>
                                                 <tr>
                                                    <td colspan="2" style="font-size: 15px; font-weight: normal;">
                                                        <div style="display: flex;">
                                                            <span style="display: block; ;"><strong>Objet : </strong> </span>
                                                            <span style="display: block; width: 100%; "> <strong>cession volontaire de salaires. </strong></span>
                                                        </div>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td colspan="2" style="height:3px; width: 100%;"></td>
                                                </tr>
												<tr>
                                                    <td colspan="2" style="font-size: 15px; font-weight: normal;">
                                                        <div style="display: flex;">
                                                            <span style="display: block; width: 100%;">Je soussigné(e) <?php echo ucfirst($customer['last_name'])." " ?: '-';?> <?php echo ucfirst($customer['first_name']) ?: '-';?>, </span> 
                                                        </div>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td colspan="2" style="height:3px; width: 100%;"></td>
                                                </tr>
												<tr>
                                                    <td colspan="2" style="font-size: 15px; font-weight: normal;">
                                                        <div style="display: flex;">
                                                           né(e) <span style="display: block; width: 100%;"> <?php echo " le ". date("d-m-Y",strtotime($customer['dob']));?> à <?php echo ucfirst($customer['birthplace'])." " ?: '-';?> résidant <?php echo ucfirst($customer['resides_address'])." " ?: '-';?>  * BP  <?php echo ucfirst($customer['state_of_issue'])." " ?: '-';?> et exerçant la profession de </span> 
                                                        </div>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td colspan="2" style="height:3px; width: 100%;"></td>
                                                </tr>
												
												<tr>
                                                    <td colspan="2" style="font-size: 15px; font-weight: normal;">
                                                        <div style="display: flex;">
                                                            <span style="display: block; width: 100%; text-align: justify;"> <?php echo ucfirst($customer['employeeOccupation'])." " ?: '-';?> déclare par la présente, être débiteur envers mon employeur la Banque Internationale pour le Commerce et l’Industrie du Gabon (BICIG) de la somme provisoirement fixée à FCFA :  <?php echo number_format($appformD['tpmnt'],0,',',' ');?> (<?php echo strtoupper($convert->Convert($appformD['tpmnt'])) ; ?>), en principal, intérêts et accessoires.</span> 
                                                        </div>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td colspan="2" style="height:3px; width: 100%;"></td>
                                                </tr>
                                                 <tr>
                                                    <td colspan="2" style="font-size: 15px; font-weight: normal;">
                                                        <div style="display: flex;">
                                                            <span style="display: block; width: 100%;">En effet, le  <?php echo date("d-m-Y",strtotime($appformD['cdate'])) ;?> , la BICIG m’a accordée un prêt de FCFA <?php echo $appformD['loan_amt'] ; ?> ( <?php echo strtoupper($convert->Convert($appformD['loan_amt'])) ; ?> ) au taux de   <?php echo $appformD['loan_interest'] ; ?>  % destiné à financer  <?php echo strtoupper($appformD['loan_object']);?></span> 
                                                        </div>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td colspan="2" style="height:3px; width: 100%;"></td>
                                                </tr>
                                                 <tr>
                                                    <td colspan="2" style="font-size: 15px; font-weight: normal;">
                                                        <div style="display: flex;">
                                                            <span style="display: block; width: 100%; text-align: justify;">Je déclare volontairement par le présent acte, céder à la BICIG, ce qui est accepté par son représentant ès-qualité, la portion cessible disponible de mes rémunérations conformément à la procédure de la cession des rémunérations prévue à l’article 161 et suivants du code du travail et aux articles 205 à 212 de l’AUO portant organisation des procédures simplifiées de recouvrement et des voies d’exécution.</span> 
                                                        </div>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td colspan="2" style="height:3px; width: 100%;"></td>
                                                </tr>
                                                  <tr>
                                                    <td colspan="2" style="font-size: 15px; font-weight: normal;">
                                                        <div style="display: flex;">
                                                            <span style="display: block; width: 100%; text-align: justify;">J’autorise par conséquent mon employeur la (e)  <?php echo ucfirst($customer['employer_name'])." " ?: '-';?> à prélever sur mon salaire la somme de FCFA  <?php echo number_format($appformD['pmnt'],0,',',' ');?> ( <?php echo strtoupper($convert->Convert($appformD['pmnt'])) ; ?> ) Pendant <?php echo strtoupper($appformD['loan_term']);?>  mois, jusqu’au remboursement total de ma dette et de reverser ladite somme sur mon compte de remboursement n° <?php echo ucfirst($customer['flexcube_acct'])." " ?: '-';?> </span> 
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="2" style="height:3px; width: 100%;"></td>
                                                </tr>
                                                 <tr>
                                                    <td colspan="2" style="font-size: 15px; font-weight: normal;">
                                                        <div style="display: flex;">
                                                            <span style="display: block; width: 100%; text-align: justify;">En cas de résiliation de mon contrat de travail, j’autorise mon employeur à prélever sur l’ensemble de mes droits les sommes dues à ce jour dans les limites autorisées par la législation en vigueur. Mandat est également donné au liquidateur désigné, dans le cadre d’une procédure collective, pour désintéresser la BICIG en prélevant sur l’ensemble de mes droits à hauteur de la quotité cessible les sommes dues au titre du prêt ci-dessus mentionné.</span> 
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="2" style="height:3px; width: 100%;"></td>
                                                </tr>
                                                  <tr>
                                                    <td colspan="2" style="font-size: 15px; font-weight: normal;">
                                                        <div style="display: flex;">
                                                            <span style="display: block; width: 100%; text-align: justify;">La présente cession n’opère pas novation au sens de l’article 1271 du code civil relativement à ma dette. </span> 
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="2" style="height:3px; width: 100%;"></td>
                                                </tr>
                                                  <tr>
                                                    <td colspan="2" style="font-size: 15px; font-weight: normal;">
                                                        <div style="display: flex;">
                                                            <span style="display: block; width: 100%;">Le présent acte est établi pour servir et valoir ce que de droit.</span> 
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="2" style="height:3px; width: 100%;"></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table style="width: 100%; border-collapse: collapse;">
                            <tbody style="">
								<tr>
                                    <td colspan="2" style="width: 50%; font-size: 16px; font-weight: normal; line-height: 19px;"></td>
                                    <td colspan="1" style="width: 50%; font-size: 16px; font-weight: normal; line-height: 19px; text-align: left;">
                                        <span style="display: block; font-size: 15px; font-weight: 600;">
                                            Fait à <span style="display: inline-block; margin: 0px 5px;  min-width:50px;  border-bottom: dashed 1px;"></span> , le <span style="display: inline-block; margin: 0px 5px;  min-width:50px;  border-bottom: dashed 1px;"></span>/<span style="display: inline-block; margin: 0px 5px;  min-width:50px;  border-bottom: dashed 1px;"></span>/<span style="display: inline-block; margin: 0px 5px;  min-width:50px;  border-bottom: dashed 1px;"></span>
                                        </span>
                                        <span style="display: block; font-size: 15px; padding: 0; font-weight: 400;  height:10px;"></span>
                                        <span style="display: block; font-size: 15px; padding: 0; font-weight: 400;">
                                            En 5 exemplaires1
                                        </span>
										<br>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="3" style="font-size: 15px; text-align: left; line-height: 16px;">
                                        <table style="width: 100%; border-collapse: collapse;">
                                            <tbody style="">
                                                <tr>
                                                    <td style="font-size: 14px; width: 40%; padding: 10px; text-align: center; line-height: 16px; border-collapse: separate;">
                                                        <span style="font-weight: normal;">
                                                            Le salarié <br />
                                                            Signature
                                                        </span>
                                                    </td>
                                                    <td style="font-size: 14px; width: 30%; padding: 10px; text-align: center; line-height: 16px; border-spacing: 0;">
                                                        <span style="font-weight: normal;">
                                                            L’employeur <br />
                                                            Signature et cachet
                                                        </span>
                                                    </td>
                                                    <td style="font-size: 14px; width: 40%; padding: 10px; text-align: center; line-height: 16px;">
                                                        <span style="font-weight: normal;">
                                                            Le greffier <br />
                                                            Signature et cachet
                                                        </span>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <ul style="font-size: 15px; line-height: 18px; list-style: decimal; margin: 0; padding-left: 15px;">
                                            <li>Montant en chiffre et en lettres.</li>
                                            <li>Fait en 5 exemplaires, 1 client, 3 BICIG, 1 greffe.</li>
                                            <li>Signature précédée de la mention « Bon pour cession de salaire à hauteur de FCFA : …… (en chiffre et en lettre) ».</li>
                                            <li>Le Cédant remettra l’acte dûment enregistré à la BICIG qui le présentera à son employeur pour que celui-ci puisse signer et procéder aux retenues.</li>
                                            <li>Enregistrement au greffe du Tribunal compétent.</li>
										</ul>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
        <center>
            <style type="text/css">
				@media print {
				  .hidden-print {
					visibility: hidden !important;
				  }
				}
			</style>
			<?php 
			if(isset($documentArray1) && $documentArray1 == $combine_doc){?>
				<button class="btn btn-primary hidden-print" id="printPageButton" onclick="myfunction()" style="position: relative;">Print Page</button>
			<?php }
			else if($documentArray1 == 0){?>
				<button class="btn btn-primary hidden-print" id="printPageButton" onclick="myfunction()" style="position: relative;">Print Page</button>
			<?php }?>
        </center>
    </body>
    <script type="text/javascript">
		function myfunction(){ window.print();}
	</script>
</html>
