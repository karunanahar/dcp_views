<?php 

$documentArray1 = 0;
if(isset($documentArray))
	$documentArray1 = sizeof($documentArray); 
$customer=(array) json_decode($appformD['customer_data']); 
$databinding=(array) json_decode($appformD['databinding']); 
// echo "<pre>"; 
// print_r($appformD); 
// die;
// print_r($riskcurrentmonthlyvrefit); 
$convert=new ConvertNumberToText();

							
								if((($customer['cat_employeurs']) == "Public Civil 25") || (($customer['cat_employeurs']) == "Prive 25") || (($customer['cat_employeurs']) == "Public Corps 25")){
									$loandate= '25';
								}else if((($customer['cat_employeurs']) == "Prive 20") || (($customer['cat_employeurs']) == "Autres 20")){
									$loandate='20';
								}else if((($customer['cat_employeurs']) == "Prive 30") || (($customer['cat_employeurs']) == "Organisation internationales")){
									$loandate='30';
								}else{
									$loandate='30';
								}
								
								
?>

<html>
<head>
<title></title>
<style type="text/css">
<!--
body { font-family: Arial; font-size: 17.6px }
.pos { position: absolute; z-index: 0; left: 0px; top: 0px }
-->
</style>
</head>
<body>
<nobr><nowrap>
<div class="pos" id="_0:0" style="top:0">
<img name="_1180:826" src="<?php echo  base_url(); ?>/assets/page_001.jpg" height="1180" width="826" border="0" usemap="#Map"></div>
<div class="pos" id="_110:36" style="top:36;left:110">
<span id="_11.7" style=" font-family:Arial; font-size:11.7px; color:#222222">
BANQUE INTERNATIONALE</span>
</div>
<div class="pos" id="_110:49" style="top:49;left:110">
<span id="_11.0" style=" font-family:Arial; font-size:11.0px; color:#282828">
POUR LE COMMERCE</span>
</div>
<div class="pos" id="_110:63" style="top:63;left:110">
<span id="_11.7" style=" font-family:Arial; font-size:11.7px; color:#2f2f2f">
ET L'INDUSIRIE <span style=" color:#252525"> DU GABON</span></span>
</div>
<div class="pos" id="_310:140" style="top:140;left:310">
<span id="_21.2" style="font-weight:bold; font-family:Arial; font-size:21.2px; color:#282828">
ACTE DE PRET N&#176; 2</span>
</div>
<div class="pos" id="_57:184" style="top:184;left:57">
<span id="_11.3" style=" font-family:Arial; font-size:11.3px; color:#404040">
 Je soussign&#233; (1)<span style=" color:#595959"> &#133;&#133;&#133;&#133;&#133;&#133;&#133;&#133;</span><span style=" font-family:Times New Roman; color:#000000"> </span><span style=" color:"> <?php echo ucfirst($customer['first_name'])." " ?: '-';?><?php echo ucfirst($customer['middle_name'])." " ?: '';?><?php echo ucfirst($customer['last_name']) ?: '-';?> &#133;&#133;&#133;&#133;&#133;&#133;&#133;</span></span>
</div>
<div class="pos" id="_60:216" style="top:216;left:60">
<span id="_11.3" style=" font-family:Arial; font-size:11.3px; color:#4f4f4f">
N&#233; le &#133;&#133;&#133;&#133;&#133;&#133;<span style=" font-family:Times New Roman; color:#000000"> </span><span style=" color:"> <?php  echo ($customer['dob']) ? (date("d-m-Y", strtotime($customer['dob']))) : ""; ?> &#133;&#133;&#133;&#133;.. &#224; &#133;&#133;&#133;&#133;&#133;&#133;&#133;&#133;</span><span style=" font-family:Times New Roman; color:#000000"> </span><span style=" color:"> <?php  echo ($customer['birthplace']);?> &#133;&#133;&#133;&#133;&#133; </span></span>
</div>
<div class="pos" id="_59:248" style="top:248;left:59">
<span id="_11.3" style=" font-family:Arial; font-size:11.3px; color:#4d4d4d">
Demeurant &#224;  <span style=" color:#595959"> &#133;&#133;&#133;&#133;&#133;&#133;&#133;&#133;</span><span style=" font-family:Times New Roman; color:#000000"> </span><span style=" color:"> <?php  echo ($customer['resides_address']);?> <?php  echo ($customer['city_id']);?>  &#133;&#133;</span></span>
</div>
<div class="pos" id="_59:266" style="top:266;left:59">
<span id="_11.3" style=" font-family:Arial; font-size:11.3px; color:#4d4d4d">
reconnais devoir &#224; la<span style="font-weight:bold; color:#494949"> </span><span style=" color:#454545"> BANQUE INTERNATIONALE POUR LE COMMERCE ET L&#146;INDUSTRIE DU GABON</span></span>
</div>
<div class="pos" id="_59:284" style="top:284;left:59">
<span id="_11.1" style=" font-family:Arial; font-size:11.1px; color:#4d4d4d">
La somme de &#133;&#133;&#133;<span id="_13.6" style=" font-size:13.6px; color:#000000"> </span><span style=" color:"> <?php echo number_format($appformD['amount'],0,',',' ');?> &#133;&#133;&#133;&#133;&#133;&#133; </span><span style=" color:#5d5d5d"> F. CFA</span><span style=" color:#595959"> </span><span style=" color:#353535"> re&#231;ue &#224; titre de pr&#234;t et port&#233;e au cr&#233;dit de mon</span></span>
</div>
<div class="pos" id="_59:302" style="top:302;left:59">
<span id="_10.8" style=" font-family:Arial; font-size:10.8px; color:#4d4d4d">
compte N&#176; &#133;&#133;&#133;<span id="_13.1" style=" font-size:13.1px; color:#000000"> </span><span style=" color:"> <?php  echo ($customer['flexcube_acct']);?> &#133;&#133;&#133;&#133;&#133;&#133;&#133;&#133;&#133; chez son si&#232;ge de &#133;&#133;&#133;</span><span id="_13.1" style=" font-size:13.1px; color:#000000"> </span><span style=" color:"> <?php echo $appformD['branch_name'];?> &#133;&#133;&#133;&#133;&#133;&#133;</span></span>
</div>
<div class="pos" id="_59:347" style="top:347;left:59">
<span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#4f4f4f">
La BANQUE INTERNATIONALE <span style=" color:#494949"> POUR  LE </span><span style=" color:#404040"> COMMERCE  ET </span><span style=" color:#414141"> L'INDUSTRIE  </span><span style=" color:#454545"> DU  </span><span style=" color:#4b4b4b"> GABON  ne  sera  pas  </span><span style=" color:#434343"> tenue  &#224;  l'&#233;gard</span></span>
</div>
<div class="pos" id="_58:365" style="top:365;left:58">
<span id="_11.5" style=" font-family:Arial; font-size:11.5px; color:#4d4d4d">
de quiconque <span style=" color:#434343"> de surveiller</span><span style=" color:#333333"> </span><span style=" color:#3b3b3b"> l'emploi </span><span style=" color:#434343"> des fonds. </span><span style=" color:#4b4b4b"> Je m'engage &#224; rembourser </span><span style=" color:#4f4f4f"> ce </span><span style=" color:#4b4b4b"> pr&#234;t en  <?php echo $appformD['loan_term']?> </span><span style=" color:#434343"> &#133;.. </span><span style=" color:#3b3b3b"> termes mensuels.</span></span>
</div>
<div class="pos" id="_58:383" style="top:383;left:58">
<span id="_11.5" style=" font-family:Arial; font-size:11.5px; color:#494949">
d'un montant constant de <span style=" color:#434343"> &#133;<?php echo number_format($appformD['pmnt'],0,',',' ')?> </span><span style=" color:#434343"> &#133;. </span><span style=" color:#3d3d3d"> francs d&#233;compt&#233; sur le montant en capital restant d&#251; apr&#232;s chaque &#233;ch&#233;ance,</span></span>
</div>
<div class="pos" id="_58:400" style="top:400;left:58">
<span id="_11.5" style=" font-family:Arial; font-size:11.5px; color:#696969">
ce programme d'amortissement ne pourra en aucun cas &#234;tre modifi&#233;.</span>
</div>
<div class="pos" id="_59:418" style="top:418;left:59">
<span id="_11.5" style=" font-family:Arial; font-size:11.5px; color:#333333">
Le premier remboursement aura lieu le <span style=" color:#434343"> &#133;..</span><span style=" color:#414141"> <?php echo  $loandate."-".$databinding[0]->month."-".$databinding[0]->years?></span><span style="font-weight:bold; color:"> </span><span style=" color:#434343"> &#133;.., </span><span style=" color:#4b4b4b"> le dernier </span><span style=" color:#434343"> le &#133;&#133;</span><span style=" font-family:Times New Roman; color:#000000"> </span><span style=" color:"> <?php echo $loandate."-".end($databinding)->month."-".end($databinding)->years;?> &#133;&#133;..</span></span>
</div>
<div class="pos" id="_59:449" style="top:449;left:59">
<span id="_11.5" style=" font-family:Arial; font-size:11.5px; color:#535353">
Le r&#232;glement de ces termes sera automatiquement effectu&#233; par le d&#233;bit de mon compte sus-indiqu&#233; que je m'engage &#224; approvisionner <span style=" color:#747474"> &#224; cette </span></span>
</div>
<div class="pos" id="_58:467" style="top:467;left:58">
<span id="_11.9" style=" font-family:Arial; font-size:11.9px; color:#595959">
fin. Je donne &#224; cet effet mandat irr&#233;vocable permanent &#224; la BANQUE INTERNATIONALE POUR LE COMMERCE ET L'INDUSTRIE <span style=" color:#434343"> DU </span></span>
</div>
<div class="pos" id="_58:484" style="top:484;left:58">
<span id="_12.9" style=" font-family:Arial; font-size:12.9px; color:#414141">
GABON.</span>
</div>
<div class="pos" id="_59:502" style="top:502;left:59">
<span id="_11.7" style=" font-family:Arial; font-size:11.7px; color:#484848">
Par ailleurs, je m'engage &#224; supporter les frais, taxes et pr&#233;l&#232;vements de toute nature, pr&#233;sents ou &#224; venir dont pourrait &#234;tre frapp&#233; le <span style=" color:#2b2b2b"> pr&#233;sent </span></span>
</div>
<div class="pos" id="_59:521" style="top:521;left:59">
<span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#4f4f4f">
contrat, ainsi que les frais et honoraires des pr&#233;sentes et ceux qui en seront la cons&#233;quence.</span>
</div>
<div class="pos" id="_59:539" style="top:539;left:59">
<span id="_11.4" style=" font-family:Arial; font-size:11.4px; color:#000000">
En cas de non-respect de l'une quelconque des clauses du pr&#233;sent acte et notamment en cas de d&#233;faut d'un seul des r&#232;glements indiqu&#233;s ci-dessus, </span>
</div>
<div class="pos" id="_58:556" style="top:556;left:58">
<span id="_11.4" style=" font-family:Arial; font-size:11.4px; color:#353535">
la totalit&#233; de la cr&#233;ance en principal, <span style=" color:#404040"> int&#233;r&#234;ts </span><span style=" color:#3b3b3b"> et accessoires </span><span style=" color:#333333"> deviendrait </span><span style=" color:#3a3a3a"> imm&#233;diatement </span><span style=" color:#404040"> et de plein droit exigible, </span><span style=" color:#414141"> s'il convient &#224;</span><span style=" color:#636363"> la BANQUE </span></span>
</div>
<div class="pos" id="_58:574" style="top:574;left:58">
<span id="_11.8" style=" font-family:Arial; font-size:11.8px; color:#404040">
INTERNATIONALE  POUR  LE <span style=" color:#434343"> COMMERCE </span><span style=" color:#454545"> ET </span><span style=" color:#353535"> EINDUSTRIE </span><span style=" color:#3b3b3b"> DU </span><span style=" color:#434343"> GABON </span> et <span style=" color:#3f3f3f"> celle-ci </span><span style=" color:#4f4f4f"> aurait </span><span style=" color:#3f3f3f"> alors </span><span style=" color:#454545"> une </span><span style=" color:#515151"> enti&#232;re </span><span style=" color:#2a2a2a"> libert&#233; </span><span style=" color:#3b3b3b"> d'action </span> pour </span>
</div>
<div class="pos" id="_58:592" style="top:592;left:58">
<span id="_11.8" style=" font-family:Arial; font-size:11.8px; color:#3d3d3d">
recouvrer ladite cr&#233;ance par toutes voies et moyens de droit.</span>
</div>
<div class="pos" id="_59:610" style="top:610;left:59">
<span id="_11.8" style=" font-family:Arial; font-size:11.8px; color:#494949">
En cas d'exigibilit&#233; anticip&#233;e ou d'atermoiement pour quelque cause que ce soit, les sommes devenues exigibles seront productives <span style=" color:#595959"> d'int&#233;r&#234;t </span></span>
</div>
<div class="pos" id="_58:628" style="top:628;left:58">
<span id="_11.8" style=" font-family:Arial; font-size:11.8px; color:#616161">
au taux du pr&#233;sent<span style=" color:#434343"> </span><span style=" color:#454545"> pr&#234;t.</span><span style=" color:#454545"> </span><span style=" color:#4f4f4f"> Les dits</span><span style=" color:#494949"> </span><span style=" color:#4d4d4d"> int&#233;r&#234;ts</span><span style=" color:#4d4d4d"> </span><span style=" color:#414141"> &#233;chus et non pay&#233;s,</span><span style=" color:#555555"> </span><span style=" color:#484848"> se capitaliseront de</span><span style=" color:#4f4f4f"> </span><span style=" color:#4f4f4f"> plein droit &#224; compter du</span><span style=" color:#454545"> </span><span style=" color:#3d3d3d"> jour o&#249;</span><span style=" color:#5d5d5d"> </span><span style=" color:#4f4f4f"> ils seront </span><span style=" color:#454545"> dus pour une </span></span>
</div>
<div class="pos" id="_58:646" style="top:646;left:58">
<span id="_12.4" style=" font-family:Arial; font-size:12.4px; color:#383838">
ann&#233;e enti&#232;re et porteront eux-m&#234;mes int&#233;r&#234;ts au taux du pr&#233;sent pr&#234;t.</span>
</div>
<div class="pos" id="_59:664" style="top:664;left:59">
<span id="_11.8" style=" font-family:Arial; font-size:11.8px; color:#6f6f6f">
A peine d'exigibilit&#233; anticip&#233;e, je m'engage &#224; consentir &#224; la BANQUE INTERNATIONALE <span style=" color:#454545"> POUR </span><span style=" color:#5f5f5f"> LE </span><span style=" color:#4d4d4d"> COMMERCE </span><span style=" color:#4b4b4b"> ET </span><span style=" color:#3b3b3b"> L'INDUSTRIE DU</span><span style=" color:#383838"> </span></span>
</div>
<div class="pos" id="_58:681" style="top:681;left:58">
<span id="_11.8" style=" font-family:Arial; font-size:11.8px; color:#353535">
GABON une provision<span style=" color:#434343"> </span><span style=" color:#4b4b4b"> de 20 % du montant du pr&#233;sent pr&#234;t &#224; titre de retenue de garantie.</span>  Lesquels seront log&#233;s dans un compte BICIG </span>
</div>
<div class="pos" id="_58:699" style="top:699;left:58">
<span id="_11.8" style=" font-family:Arial; font-size:11.8px; color:#353535">
identifiable &#224; tout moment. Il est express&#233;ment convenu que dans le cas o&#249; pour quelque cause que ce soit, le pr&#233;sent pr&#234;t ne serait pas </span>
</div>
<div class="pos" id="_58:717" style="top:717;left:58">
<span id="_11.8" style=" font-family:Arial; font-size:11.8px; color:#454545">
rembours&#233; &#224; son &#233;ch&#233;ance, la provision restera acquise de plein droit &#224; la BANQUE INTERNATIONALE <span style=" color:#3d3d3d"> POUR LE COMMERCE </span><span style=" color:#3d3d3d"> ET EINDUSTRIE </span></span>
</div>
<div class="pos" id="_58:735" style="top:735;left:58">
<span id="_11.8" style=" font-family:Arial; font-size:11.8px; color:#434343">
DU <span style=" color:#2f2f2f"> GABON, </span><span style=" color:#282828"> quelque soit </span><span style=" color:#3d3d3d"> le montant </span><span style=" color:#454545"> des sommes impay&#233;es et sans </span><span style=" color:#3b3b3b"> pr&#233;judice pour </span><span style=" color:#848484"> la BICIG d'une part, d'agir en recouvrement &#224; mon </span></span>
</div>
<div class="pos" id="_58:753" style="top:753;left:58">
<span id="_11.8" style=" font-family:Arial; font-size:11.8px; color:#434343">
encontre au titre des sommes impay&#233;es n'&#233;tant pas couvertes par la retenue de garantie et d&#146;autre part d'agir en dommages-int&#233;r&#234;ts au titre </span>
</div>
<div class="pos" id="_58:771" style="top:771;left:58">
<span id="_11.8" style=" font-family:Arial; font-size:11.8px; color:#353535">
du pr&#233;judice subi du fait du non remboursement &#224; &#233;ch&#233;ance. En cas de <span style=" color:#3f3f3f"> remboursement int&#233;gral sans incident du pr&#233;sent pr&#234;t, cette retenue de </span></span>
</div>
<div class="pos" id="_58:789" style="top:789;left:58">
<span id="_11.8" style=" font-family:Arial; font-size:11.8px; color:#2f2f2f">
garantie sera restitu&#233;e en totalit&#233; &#224; l'emprunteur<span style=" color:#383838"> </span><span style=" color:#4d4d4d"> &#224; l'&#233;ch&#233;ance. Toutes les obligations r&#233;sultant des pr&#233;sentes sont stipul&#233;es solidaires et indivisibles</span><span style=" color:#454545"> </span></span>
</div>
<div class="pos" id="_58:806" style="top:806;left:58">
<span id="_11.8" style=" font-family:Arial; font-size:11.8px; color:#454545">
entre <span style=" color:#484848"> mes h&#233;ritiers</span><span style=" color:#353535"> </span><span style=" color:#4f4f4f"> et</span><span style=" color:#4f4f4f"> </span><span style=" color:#3b3b3b"> ayants droits de</span><span style=" color:#4d4d4d"> </span><span style=" color:#484848"> telle sorte </span><span style=" color:#3f3f3f"> que leur ex&#233;cution pourra &#234;tre r&#233;clam&#233;e pour le tout &#224; n'importe quel moment.</span></span>
</div>
<div class="pos" id="_59:836" style="top:836;left:59">
<span id="_11.8" style=" font-family:Arial; font-size:11.8px; color:#4d4d4d">
En outre je certifie, <span style=" color:#454545"> apr&#232;s avoir pris connaissance de l'article L 1 13-8 </span> du code des assurances :</span>
</div>
<div class="pos" id="_78:854" style="top:854;left:78">
<span id="_11.8" style=" font-family:Arial; font-size:11.8px; color:#3b3b3b">
<li type="square"><span style=" color:#535353"> Ne pas &#234;tre actuellement </span><span style=" color:#414141"> en &#233;tat d'incapacit&#233; </span><span style=" color:#333333"> temporaire de travail, exercer mon activit&#233; professionnelle de fa&#231;on </span><span style=" color:#434343"> normale </span><span style=" color:#535353"> et </span></span>
</div>
<div class="pos" id="_87:872" style="top:872;left:87">
<span id="_11.8" style=" font-family:Arial; font-size:11.8px; color:#494949">
effective ;</span>
</div>
<div class="pos" id="_78:890" style="top:890;left:78">
<span id="_11.8" style=" font-family:Arial; font-size:11.8px; color:#3f3f3f">
<li type="square"><span style=" color:#4f4f4f"> N&#146;&#234;tre </span><span style=" color:#383838"> atteint </span> d'aucune infirmit&#233;,<span style=" color:#3a3a3a"> </span><span style=" color:#252525"> invalidit&#233;,</span><span style=" color:#252525"> </span><span style=" color:#383838"> maladie </span> aigu&#235;  ou <span style=" color:#3a3a3a"> chronique</span></span>
</div>
<div class="pos" id="_78:907" style="top:907;left:78">
<span id="_11.8" style=" font-family:Arial; font-size:11.8px; color:#434343">
<li type="square"><span style=" color:#4b4b4b"> Ne suivre aucun traitement ou r&#233;gime et ne pas &#234;tre sous surveillance m&#233;dicale.</span></span>
</div>
<div class="pos" id="_59:936" style="top:936;left:59">
<span id="_11.8" style=" font-family:Arial; font-size:11.8px; color:#434343">
En cas de remboursement anticip&#233;, apr&#232;s avoir fait la demande avec pr&#233;avis d'un mois, je m'engage &#224; reverser &#224; la Banque une indemnit&#233; <span style=" color:#6f6f6f"> &#233;gale &#224; </span></span>
</div>
<div class="pos" id="_59:955" style="top:955;left:59">
<span id="_12.2" style=" font-family:Arial; font-size:12.2px; color:#000000">
5% (hors taxe) du capital effectivement rembours&#233; par anticipation.</span>
</div>
<div class="pos" id="_463:987" style="top:987;left:463">
<span id="_16.3" style=" font-family:Arial; font-size:16.3px; color:#353535">
Fait &#224;</span>
</div>
<div class="pos" id="_595:991" style="top:991;left:595">
<span id="_12.9" style=" font-family:Arial; font-size:12.9px; color:#535353">
, <span style=" color:#404040"> le</span></span>
</div>
<div class="pos" id="_660:989" style="top:989;left:660">
<span id="_17.1" style=" font-family:Arial; font-size:17.1px; color:#4b4b4b">
/</span>
</div>
<div class="pos" id="_710:989" style="top:989;left:710">
<span id="_17.1" style=" font-family:Arial; font-size:17.1px; color:#4f4f4f">
/</span>
</div>
<div class="pos" id="_494:1015" style="top:1015;left:494">
<span id="_11.9" style="font-style:italic; font-family:Arial; font-size:11.9px; color:#404040">
Signature (2)</span>
</div>
<div class="pos" id="_446:1126" style="top:1165;left:59">
<span id="_10.3" style=" font-family:Arial; font-size:10.3px; color:#383838">
</span>
</div>
<div class="pos" id="_59:1133" style="top:1133;left:59">
<span id="_8.9" style=" font-family:Arial; font-size:8.9px; color:#4b4b4b">
(1) Nom et Pronoms dans l'ordre de I &#146;&#233;tat civil</span>
</div>
<div class="pos" id="_59:1145" style="top:1145;left:59">
<span id="_8.9" style=" font-family:Arial; font-size:8.9px; color:#323232">
(2) La signature doit &#234;tre pr&#233;c&#233;d&#233;e de la mention suivante :</span>
</div></br>
<div class="pos" id="_446:1138" style="top:1181;left:59">
<span id="_9.5" style=" font-family:Arial; font-size:9.5px; color:#3b3b3b">
"EN PRINCIPAL PLUS INTERETS, FRAIS ET ACCESSOIRES&#146;</span>
</div>
<div class="pos" id="_59:1156" style="top:1156;left:59">
<span id="_9.6" style=" font-family:Arial; font-size:9.6px; color:#3d3d3d">
LU ET APPROUVE BON POUR F. CFA - <?php echo strtoupper($convert->Convert($appformD['tpmnt'])) ; ?></span>

<style type="text/css">
          @media print {
            .hidden-print {
              visibility: hidden !important;
            }
          }
        </style>
        <center>
          <button class="btn btn-primary hidden-print" id="page-container" onclick="myfunction()" style="padding: 5px 10px; font-size: 15px;">Print Page</button>
        </center>
        <script type="text/javascript">
          function myfunction() {
            window.print();
          }
        </script>
</div>
</body>
</html>

