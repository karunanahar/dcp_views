<?php
$documentArray1 = 0;
if (isset($documentArray))
  $documentArray1 = sizeof($documentArray);
$customer = (array) json_decode($appformD['customer_data']);
$convert = new ConvertNumberToText();
// print_r($customer);
?>
<!DOCTYPE html>
<html>

<head>
  <style>
    body {
      font-size: 11px;
      padding: 3px;
    }

    .container {
      display: flex;
    }

    .column {
      flex: 1;
      padding: 10px;
      width: 49%;
    }

    .column:first-child {
      background-color: #f2f2f2;
    }

    h4 {
      margin: 0px;
    }

    .column:last-child {
      background-color: #e6e6e6;
    }

    p {
      line-height: 1.5;
      text-align: justify;
    }
  </style>
  <meta charset="utf-8" />

  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

  <title></title>
  <link rel="stylesheet" href="<?php echo base_url('assets/css/compiled/document_css.css" type="text/css');?>" media='all'/>
</head>

<body>

  <div id="page-container">
    <div>
      <table style="width: 100%;">
        <tr>
          <td><img class="common_document_logo3" src="<?php echo  base_url(); ?>/assets/logo2.png"/></td>
          <td style="width: 60%; padding: 7px 20px; text-align: center; font-weight: bold; border: 3px solid #000;  border-bottom: 5px solid #000;">CONVENTION DE DELEGATION DE LOYERS</td>
          <td style="width: 20%;">&nbsp;</td>
        </tr>
      </table>
    </div>
    <div style="padding-top: 10px;"><b>ENTRE-LES SOUSSIGNES,</b></div><br>
    <div style=" padding: 7px 20px;  border: 1px solid #000; margin-bottom: 10px; text-align: justify;">
      LA <b>AFG BANK GABON</b> en abrégé <b>«AFG BANK GA »</b>, Société Anonyme avec Conseil d’Administration, au capital de F.CFA 18.000.000.000 (dix-huit milliards) dont le siège social est à Libreville, Avenue du Colonel Parant, domiciliée à la boite postale 2241,
      immatriculée au Registre du Commerce et du Crédit Mobilier de ladite ville sous le numéro 2002 B 01732, identifiée fiscalement sous le numéro 790 027 A,
      inscrite sur la liste des banque sous le numéro 40001 et dont l’adresse électronique est serviceclient@afgbank.ga, représentée par <b>Madame Carole CAPITO</b>, agissant en qualité de Directeur Adjoint du Réseau Clientèle des Particuliers et des Professionnels ;
      <div style="text-align: right; padding-top: 10px;">Ci-après dénommée "la Banque" ou "le Bénéficiaire’’ d’une part ; </div>
    </div>
    <div style="padding-left: 30px; margin-bottom: 20px;"><b>ET:</b></div>
    <div style=" padding: 7px 20px;  border: 1px solid #000; margin-bottom: 10px; text-align: justify;">
      <b><?php echo ucfirst($customer['title']) . " " ?: ''; ?><?php echo ucfirst($customer['first_name']) ?: '-'; ?> <?php echo ucfirst($customer['middle_name']) . " " ?: ''; ?> <?php echo ucfirst($customer['last_name']) ?: '-'; ?>, </b>
      Président du Conseil d’Administration du Conseil Gabonais des Chargeurs, domiciliée à <?= $customer['city_id']; ?>, <?= $customer['resides_address']; ?>.
      <br><br>
      De nationalité <?= $customer['nationality']; ?>,<br>
      Né à <?= $customer['birthplace']; ?>, le <?php setlocale(LC_TIME, "fr_FR");
                                                echo strftime("%d-%B-%Y", strtotime($customer['dob'])); ?><br>
      Titulaire de la pièce d’identité numéro <?= $customer['id_number']; ?>.

      <div style="text-align: right; padding-top: 10px;">Ci-après désigné (e) : “ le délégant” de second part ;</div>
    </div>
    <div style="padding-bottom: 20px; text-align: center;"><b>IL A ETE PREALABLEMENT EXPOSE CE QUI SUIT:</b></div>
    <div style="text-align: justify;">
      <b><?php echo ucfirst($customer['title']) . " " ?: ''; ?><?php echo ucfirst($customer['first_name']) ?: '-'; ?> <?php echo ucfirst($customer['middle_name']) . " " ?: ' '; ?> <?php echo ucfirst($customer['last_name']) ?: '-'; ?></b>
      a sollicité et obtenu de la AFG BANK GA la mise en place d’un crédit d’un montant de <b><?php echo number_format($appformD['loan_amt'], 0, ',', ' '); ?> (<?php echo ucwords($convert->Convert($appformD['loan_amt'])); ?>), </b>
      destiné à financer <?php echo $appformD['loan_object']; ?> 

      Afin de garantir le remboursement de toutes les sommes dues au titre dudit crédit, il a accepté de déléguer au profit de la Banque, ce qui a été
      accepté par ses représentants légaux, les loyers qu’il perçoit régulièrement auprès de
      <b><?php echo ucfirst($rent_details['tenant_title']) . " " ?: ''; ?> <?php echo ucfirst($rent_details['tenant_first_name']) ?: '-'; ?> <?php echo ucfirst($rent_details['tenant_last_name']) . " " ?: ''; ?>, son locataire. </b>
      <br><br>
      La Banque s’y étant disposée ainsi que dit ci-dessus, les Parties se sont rapprochées pour matérialiser leur accord dans les termes de la présente convention,
      avec laquelle ce préambule forme un tout indivisible:
    </div>
    <div style=" padding-top: 20px; text-align: center;"><b>CECI EXPOSE, IL A ETE CONVENU ET ARRETE CE QUI SUIT:</b></div>
    <div>
      <div class="container">
        <div class="column">
          <h4>ARTICLE 1: DEFINITIONS</h4>
          <p>
            Aux fins de la présente convention, et sauf si le contexte justifie une autre interprétation, les termes et expressions ci-dessous doivent
            s'entendre comme suit:<br><br>
            "OHADA" désigne l'Organisation pour l'Harmonisation en Afrique du
            Droit des Affaires, instituée par le Traité de Port Louis en date du 17
            octobre 1993 révisé par le Traité de Québec du 17 octobre 2008 ;
            <br><br>
            "Acte OHADA sur les Sûretés" désigne l'acte uniforme OHADA portant
            organisation des sûretés adopté le 15 décembre 2010 ;
            <br><br>
            "Délégation" a le sens donné à ce terme à l'Article 3 ci-dessous ;
            <br><br>
            "Période de Garantie" désigne la période débutant à la date du présent
            Acte et finissant à la date à laquelle la Banque aura notifié au Constituant
            que toutes les Obligations Garanties ont été intégralement et
            irrévocablement payées et que le Bénéficiaire n’a plus aucun
            engagement au titre des Documents de Financement ;
            <br><br>
            "RCCM" signifie le Registre du Commerce et du Crédit Mobilier ;
            <br><br>
            "Sûretés" désigne les Sûretés Personnelles et les Sûretés Réelles ;
            <br><br>
            "Sûreté Personnelle" désigne tout cautionnement, aval, garantie autonome ou autre sûreté personnelle ou garantie mis en place en
            garantie de dettes ou d'emprunts présents ou futurs ; et
            <br><br>
            "Sûreté Réelle" désigne tout gage, hypothèque, nantissement, privilège,
            servitude, ou autre sûreté réelle ou droit sur les actions, autres titres,
            biens, revenus et droits, présents ou futurs mis en place en garantie de
          </p>

          <!-- Article 1 Remaining Content -->
          <p style="border-top: 4px solid #fff;">
            La Banque procèdera en outre, à tout moment pendant la durée de la
            Convention, aux frais du déléguant qui s’y engage, autant que
            nécessaire, au renouvellement de l’inscription et à toute autre formalité
            nécessaire pour en assurer la validité, l’opposabilité et l’efficacité, dans
            les conditions et délais légaux en vigueur.
            <br><br>
            Tous pouvoirs sont donnés au porteur d’un original, d’une copie ou d’un
            extrait de la Convention pour l’accomplissement de toute formalité.
          </p>

          <h4>ARTICLE 5: DECLARATIONS - ENGAGEMENTS</h4>
          <p>
            Le Déléguant déclare et donne les garanties qu’à la date des présentes,
            il a tous pouvoirs et pleine capacité pour signer et exécuter la présente convention.
            Il déclare :
            <br><br>
            - qu’il n’a pas fait de délégation avant ce jour au profit de quiconque, et
            qu’il n’a consenti à ce jour aucune cession de créances détenues sur le
            délégué, ni aucun gage sur celle-ci, pour tout ou partie, et qu’il n’existe
            aucune opposition à paiement sur les dites sommes.
            <br><br>
            - accepter la délégation et considère, en tant que débiteur délégué, cette délégation effectuée en vertu de l’article 1275 et suivants du code
            civil comme pleinement valable à son égard.
            <br><br>
            Il s’engage à informer le délégué de la présente délégation et à recueillir sa signature suivie de la mention manuscrite, si la banque ne peut le faire elle-même.
            <br><br>
            Le délégué reconnaît que son engagement est indépendant de tous liens
            susceptibles de l’unir au délégant et, en conséquence, il ne pourra
            opposer à la banque aucune des exceptions qu’il serait en mesure de
            faire valoir à l’encontre du délégant.
            <br><br>
            Le Déléguant s'engage, aux termes de la Convention :
            <br><br>
            (a) à ne pas céder, transférer ou autrement disposer, ou permettre ou consentir que soit cédé, transféré ou qu'il soit disposé des sommes déléguées, ou de l'un quelconque de ses droits y afférents, au bénéfice d'une autre partie que la banque sans l'accord préalable et écrit de cette dernière ;
            <br><br>
            (b) à exécuter toute mesure ou à signer tout document ou acte requis
            <br><br>
            ou qui pourrait, le cas échéant, être requis par le Bénéficiaire, en vue de
            l'exécution de la délégation, ou à toute autre fin pour les besoins de la convention ;
            <br><br>
            (c) à supporter sur simple demande du délégataire, l'ensemble des
            dépenses et frais raisonnables, y compris sans caractère limitatif, les
            frais de conseils que la Banque aurait exposé au titre de la convention ou à l'occasion de la constitution, défense, préservation ou de la
            réalisation de la présente garantie ;
            <br><br>
            En contrepartie, le Bénéficiaire s'engage de manière diligente à donner
            mainlevée à condition et dès lors que toutes les sommes dues au titre
            des Obligations Garanties auront été intégralement remboursées ou payées.
          </p>

          <h4>ARTICLE 6: REALISATION </h4>
          <p>
            La Banque est fondée à exercer sur les sommes déléguées, dans la limite des Obligations Garanties, les droits qui lui sont conférés en sa qualité
            de délégataire, dans les conditions et limites fixées par la loi A cet effet, le Constituant autorise à tout moment, le Bénéficiaire à
            débiter son Compte en vue du remboursement des sommes dues.
            <br>
          </p>

          <h4 style="border-top: 4px solid #fff;">Article 11 : Frais et droits</h4>
          <p>
            Le délégant prend à sa charge les impôts, taxes et autres frais liés à la
            conclusion et à l’exécution du présent acte ; notamment ceux qui sont
            liés à la rédaction, l’enregistrement du présent acte, et autorise la
            BANQUE à débiter son compte pour le règlement desdits frais.
            <br><br>
            La présente convention rentrera en vigueur après recueil des signatures
            de toutes les parties et les engagera jusqu'au plein accomplissement de
            la totalité des obligations qu’elle constate.
          </p>

          <h4>Article 12 : Règlements des différends</h4>
          <p>
            La présente convention est soumise au Droit en vigueur en République
            Gabonaise.
            <br><br>
            Pour l’exécution des présentes et de leurs suites, pour tous différends
            pouvant survenir entre la BANQUE et le délégant dans leurs rapports
            d’affaires, et pour toute difficulté à laquelle la présente convention pourrait donner lieu pour son interprétation, sa validité et son
            exécution, les parties s’accordent pour rechercher une solution amiable.
            <br><br>
            A défaut d’accord, la partie la plus diligente en réfèrera aux tribunaux
            compétents de Libreville.
          </p>

          <br>
          <p>Fait à __________ le _________________</p>
          <br>
          <p><strong><u>POUR LE CONSTITUANT (1)</u></strong></p>
        </div>
        <div class="column">
          <!-- Article 2 Remaining Content -->
          <p>
            dettes ou d’emprunts présents ou futurs.
          </p>
          <!-- Article 2 Remaining Content -->

          <h4>ARTICLE 2: OBLIGATIONS OU CREANCES GARANTIES</h4>
          <p>
            Les "Obligations Garanties ou Créances Garanties" désignent la somme de <b><?php echo number_format($appformD['loan_amt'], 0, ',', ' '); ?> ( <?php echo ucwords($convert->Convert($appformD['loan_amt'])); ?> ),</b>
            consentie au profit <b><?php echo ucfirst($customer['title']) . " " ?: ''; ?><?php echo ucfirst($customer['first_name']) ?: '-'; ?><?php echo ucfirst($customer['middle_name']) . " " ?: ''; ?><?php echo ucfirst($customer['last_name']) ?: '-'; ?> </b>
            Etant précisé que ledit crédit a été mis en place sur le <b>compte numéro <?= $customer['flexcube_acct'] ?></b> ouvert les
            livres de la banque au nom du Délégant.
          </p>
          <h4>ARTICLE 3: DELEGATION</h4>
          <p>
            En sûreté et à la garantie du remboursement intégral des ‘‘Obligations Garanties’’,
            <b><?php echo ucfirst($customer['title']) . " " ?: ''; ?><?php echo ucfirst($customer['first_name']) ?: '-'; ?><?php echo ucfirst($customer['middle_name']) . " " ?: ''; ?><?php echo ucfirst($customer['last_name']) ?: '-'; ?></b>
            délègue et transporte avec toutes les garanties de faits et de droit, à la AFG BANK GA, qui
            accepte, par préférence à lui-même et à tous autres cessionnaires, le
            montant de loyers dus par
            <b><?php echo ucfirst($rent_details['tenant_title']) . " " ?: ''; ?><?php echo ucfirst($rent_details['tenant_first_name']) ?: '-'; ?><?php echo ucfirst($rent_details['tenant_last_name']) . " " ?: ''; ?></b>,
            soit la somme de xaf <b><?php echo $rent_details['tenant_rent'] ?></b>.
            <br><br>
            Etant expressément convenu que les loyers ainsi délégués au titre des
            présentes, seront irrévocablement domiciliés sur le <b>compte numéro <?php echo $rent_details['bank_account'] ?></b> ouvert dans les livres de la AFG BANK GA, au nom du
            Délégant.
            <br><br>
            La présente délégation s'ajoutera à toutes sûretés dont bénéficie la
            Banque, et ne pourra en aucun cas porter atteinte à, ni être compromis ou affecté, par lesdites sûretés.
          </p>
          <h4>ARTICLE 4 : FORMALITES D'INSCRIPTION ET DE RENOUVELLEMENT</h4>
          <p>
            La Banque procèdera, aux frais du délégant qui s’y engage, à toutes les
            formalités nécessaires à la constitution, à la validité, à l’opposabilité et à
            l’efficacité de la délégation, notamment par son inscription et, le cas échéant, son enregistrement auprès administrations compétentes.
          <p>

          <p style="border-top: 4px solid #fff;">
            Même après sa réalisation, la délégation subsiste tant que la Créance Garantie n'a pas été intégralement payée.
          <p>

          <h4>ARTICLE 7: IMPUTATION DES PAIEMENTS</h4>
          <p>
            Toute somme prélevée au titre de la présente convention sera affectée au remboursement et paiement des Obligations Garanties, à leur date
            d’échéance normale ou anticipée.
            <br><br>
            Le reliquat après prélèvement et apurement de l’encours du client sera
            reversé sur le compte courant du client ouvert dans les livres de la
            Banque.
          </p>

          <h4>ARTICLE 8: DUREE</h4>
          <p>
            La présente Convention prend effet à compter de sa signature et restera
            en vigueur tant que l’ensemble des Obligations Garanties n’aura pas été
            intégralement remboursé ou payé
          </p>

          <h4>ARTICLE 9: NOTIFICATIONS</h4>
          <p>
            La présente délégation sera notifiée à son locataire.
            <br><br>
            Ladite notification sera faite par écrit et sera adressée par lettre recommandée avec accusé de réception, remises par porteur avec cahier de transmission, ou transmises par un service de courrier de
            réputation internationale, aux Parties, à leurs adresses respectives
            indiquée ci-dessus.
          </p>

          <h4>ARTICLE 10: DIVERS</h4>
          <p>
            Les modifications à la présente convention doivent être faites par écrit. L’invalidation d’une clause n’entache pas la validité des autres dispositions.
            <br><br>
            Les clauses invalides seront aussitôt remplacées par les parties contractantes par des dispositions conformes à la législation et aux usages en vigueur.
            <br><br>
            Il est convenu que la convention ne préjudicie ou ne limite et ne préjudiciera ou ne limitera en aucune manière les autres droits et recours du Bénéficiaire et qu’il n’affecte et ne pourra affecter ni la
            nature, ni l’étendue de tous engagements et de toutes garanties auxquels il s’ajoute ou s’ajoutera et qui ont pu ou pourront par ailleurs
            être contractés ou concédés par le Constituant.
            <br><br>
            Le fait que le Bénéficiaire omette d'exercer un quelconque droit, recours ou option conformément au Contrat ou accuse un retard à l'exercice
            desdits droits, recours ou option, ne sera pas considéré comme une renonciation à ce droit, recours ou option. Ne sera pas non plus
            considéré comme une renonciation, l'exercice isolé ou partiel d'un
            quelconque droit, recours ou option ou un tel exercice ne préjugera en
            rien de l'exercice renouvelé ou futur desdits droits, recours ou options ou de tout autre droit. Aucune renonciation par le Bénéficiaire ne sera valable si elle n'est pas expressément faite par acte écrit faisant
            spécifiquement référence au présent Contrat.
            <br><br>
            Au cas où une quelconque stipulation de la convention serait considérée comme nulle ou inopposable ou le deviendrait par l'effet d'une loi
            quelconque ou en raison de l'interprétation qui en serait donnée par une quelconque juridiction, la convention serait interprété comme s'il ne contenait pas ladite disposition et l'invalidité de ladite disposition n'affectera pas la validité de toutes autres stipulations de la convention qui resteront par ailleurs légales et valables et demeureront pleinement
            en vigueur. Le cas échéant, les clauses invalides seront remplacées, à la diligence des parties contractantes, par des dispositions conformes à la
            législation et aux usages bancaires.
          </p>
          <h4 style="border-top: 4px solid #fff;">Article 13 : Election de domicile</h4>
          <p>
            Pour l’exécution des présentes et de leurs suites, domicile est élu :
            <br><br>
            - Pour le Délégant et le délégué, à leurs adresses ci-dessus ;
            <br>
            - Pour la BANQUE, en son siège social sus mentionné
            <br><br>
            Dont acte dressé en Cinq (05) exemplaires
          </p>

          <br><br><br><br><br><br><br><br><br>
          <div style="text-align: center;">
            <p><strong><u>POUR LA BANQUE</u></strong></p>
          </div>
        </div>
      </div>
      <div style="width: 80%; margin: auto; padding-left: 5px; padding-right: 5px; text-align: center;">
        (1) "Bon pour nantissement de compte, dans les termes ci-dessus, à hauteur d'un montant maximal de F.CFA <?php echo $appformD['tpmnt']; ?>
        <b>(<?php echo strtoupper($convert->Convert($appformD['tpmnt'])); ?> )</b>
        couvrant le paiement du principal, des intérêts, des commissions, frais et accessoires".
      </div>
      <div>
        <style type="text/css">
          @media print {
            .hidden-print {
              visibility: hidden !important;
            }
          }
        </style>
        <center>
          <button class="btn btn-primary hidden-print" id="page-container" onclick="myfunction()" style="padding: 5px 10px; font-size: 15px;">Print Page</button>
        </center>
        <script type="text/javascript">
          function myfunction() {
            window.print();
          }
        </script>
      </div>
</body>

</html>