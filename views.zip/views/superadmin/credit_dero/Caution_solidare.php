<?php
$documentArray1 = 0;
if (isset($documentArray))
  $documentArray1 = sizeof($documentArray);
$customer = (array) json_decode($appformD['customer_data']);
$garant_detail = (array) json_decode($appformD['garant_detail']);
$databinding = (array) json_decode($appformD['databinding']);

$convert = new ConvertNumberToText();
?>
<html>

<head>
  <style>
    body {
      font-size: 11px;
      padding: 3px;
    }

    .container {
      display: flex;
    }

    .column {
      flex: 1;
      padding: 10px;
      width: 49%;
    }

    .column:first-child {
      background-color: #f2f2f2;
    }

    h4 {
      margin: 0px;
    }

    .column:last-child {
      background-color: #e6e6e6;
    }

    p {
      line-height: 1.5;
      text-align: justify;
    }
  </style>
  <meta charset="utf-8" />

  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

  <title></title>
  <link rel="stylesheet" href="<?php echo base_url('assets/css/compiled/document_css.css" type="text/css');?>" media='all'/>
</head>

<body>

  <div id="page-container">
    <div>
      <table style="width: 100%;">
        <tr>
          <td><img class="common_document_logo3" src="<?php echo  base_url(); ?>/assets/logo2.png"/></td>
          <td style="width: 60%; padding: 7px 20px; text-align: center; font-weight: bold; border: 3px solid #000;  border-bottom: 5px solid #000;">CONVENTION DE CAUTIONNEMENT SOLIDAIRE<BR>POUR UNE OPERATION DETERMINEE</td>
          <td style="width: 20%;">&nbsp;</td>
        </tr>
      </table>
    </div>
    <div style="padding-top: 10px;"><b>ENTRE LES SOUSSIGNES</b></div><br>
    <div style=" padding: 7px 20px;  border: 1px solid #000; margin-bottom: 10px; text-align: justify;">
      LA AFG BANK GABON en abrégé «AFG BANK GA », Société Anonyme avec Conseil d’Administration, au capital de F.CFA 18.000.000.000 (dix-huit milliards) dont le siège social est à Libreville, Avenue du Colonel Parant, domiciliée à la boite postale 2241,
      immatriculée au Registre du Commerce et du Crédit Mobilier de ladite ville sous le numéro 2002 B 01732, identifiée fiscalement sous le numéro 790 027
      A, inscrite sur la liste des banque sous le numéro 40001 et dont l’adresse électronique est bicignet@bicig.ga, représentée par Madame Lysianne MFOULOUH EMANE, agissant en qualité de Directeur Adjoint du Réseau Clientèle des Particuliers et des Professionnels ;
      <div style="text-align: right; padding-top: 10px;">Ci-après dénommée "la Banque" ou "le Bénéficiaire’’ d’une part ; </div>
    </div>
    <div style="padding-left: 30px; margin-bottom: 20px;"><b>ET:</b></div>
    <div style=" padding: 7px 20px;  border: 1px solid #000; margin-bottom: 10px; text-align: justify;">
      La <?php echo $garant_detail['g_eterprise_caution']; ?>, <?php echo $garant_detail['g_forme_societal']; ?> ayant son siège social à <?php echo $garant_detail['g_siege_caution']; ?>, domiciliée à la BP<?php echo $garant_detail['g_bp']; ?>. Identifié fiscalement sous le numéro <?php echo $garant_detail['g_nif2']; ?>, représentée par <?php echo $garant_detail['g_titre2']; ?> <?php echo $garant_detail['g_garantname']; ?> agissant en qualité de Gérant , dûment habilité à engager la société et élisant domicile pour l’exécution de la présente convention en son siège social,
      <div style="text-align: right; padding-top: 10px;">Ci-après désigné (e) : le “Constituant” d’autre part ;</div>
    </div>
    <div style="padding-bottom: 20px; text-align: center;"><b>IL A ETE PREALABLEMENT EXPOSE CE QUI SUIT:</b></div>
    <div style="text-align: justify;">
      <b><span style="color: #c3534e;"><?php echo $customer['title'] ?: '-'; ?> <?php echo $customer['first_name'] ?: '-'; ?> <?php echo $customer['last_name'] ?: '-'; ?>, né à <?php echo $customer['birthplace'] ?: '-'; ?> le <?php setlocale(LC_TIME, "fr_FR");
                                                                                                                                                                                                                              echo strftime("%d-%B-%Y", strtotime($customer['dob']));
                                                                                                                                                                                                                              //echo strftime(date_format(date_create($customer['dob']),"d-F-Y")) ?: '-';
                                                                                                                                                                                                                              ?>,</span></b> fonctionnaire, a sollicité et obtenu de la BICIG un crédit moyen terme d’un montant
      de <span style="color: #c3534e;"><b>xaf <?php echo $appformD['loan_amt'] ?: '-'; ?> <?php echo strtoupper($convert->Convert($appformD['loan_amt'])); ?>,</b></span> destiné à <?php echo $appformD['loan_object'] ?: '-'; ?></span>. Ledit prêt est réputé remboursable en <?php echo $appformD['loan_term'] ?> mois à dater de sa mise
      en place au taux d’intérêts de <b><span style="color: #c3534e;"><?php echo $appformD['loan_interest'] ?>%</span></b> Hors taxes.
      <br><br>
      Afin de garantir le remboursement de toutes les sommes dues par l’Emprunteur, il a été convenu que le CONSTITUANT se porte Caution Solidaire auprès de
      la Banque, et s’engage à pallier toute défaillance de l’Emprunteur jusqu’à concurrence du montant de <b><span style="color: #c3534e;">xaf <?php echo $appformD['tpmnt'] ?></span></b> en principal, plus intérêts, frais et accessoires.
      <br><br>
      La Banque s’y étant disposée, les Parties se sont rapprochées pour matérialiser leur accord dans les termes de la présente convention de cautionnement, avec laquelle ce préambule forme un tout indivisible :
    </div>
    <div style=" padding-top: 20px; text-align: center;"><b>CECI EXPOSE, IL A ETE CONVENU ET ARRETE CE QUI SUIT:</b></div>
    <div>
      <div class="container">
        <div class="column">
          <h4>ARTICLE 1: OBJET</h4>
          <p>
            1.1 La Caution déclare se constituer caution solidaire de <span style="color: #c3534e;"><b><?php echo $customer['title'] ?: '-'; ?> <?php echo $customer['first_name'] ?: '-'; ?> <?php echo $customer['last_name'] ?: '-'; ?>,</span></b> titulaire du compte numéro <?php echo $customer['flexcube_acct'] ?: '-'; ?>, pour toutes les sommes que le Cautionné doit, peut ou pourra devoir à la Banque
            à raison du crédit moyen terme de <span style="color: #c3534e;"><b>xaf <?php echo $appformD['loan_amt'] ?: '-'; ?></span></b> qui lui a été consenti par la banque, et d’une façon générale, de toutes les obligations nées, sans aucune
            exception, directement ou indirectement à l’égard de la Banque pour quelque
            cause que ce soit en vertu du crédit sus indiqué.
            <br><br>
            1.2 Les obligations de la Caution en exécution du présent cautionnement sont limitées au montant de <span style="color: #c3534e;"><b>xaf <?php echo $appformD['tpmnt'] ?: '-'; ?>,</span></b> garantissanttant
            le principal des engagements de l’Emprunteur que tous intérêts, frais et accessoires venant en sus, étendus au solde éventuellement débiteur de son
            compte courant tel qu’il apparaîtrait à sa clôture.
            <br><br>
            1.3 En cas de fusion, absorption, scission ou apport partiel d'actifs affectant la banque, la caution accepte d'ores et déjà irrévocablement le maintien de son
            engagement, y compris pour les créances nées postérieurement aux dites opérations, de sorte que l'entité venant aux droits de la banque continuera à
            bénéficier, dans les mêmes termes, de ladite caution en couverture des opérations garanties résultant de la continuation des relations avec le
            cautionné.
          </p>
          <h4>ARTICLE 2: ETENDUE DU CAUTIONNEMENT</h4>
          <p>
            Le présent engagement oblige la Caution, à titre solidaire, à payer à la Banque
            ce que lui doit ou devra le Cautionné, dans la limite du
          </p>

          <!-- Article 4 Remaining Content -->
          <p style="border-top: 4px solid #fff;">

            déchéance ou de la prorogation du terme en indiquant le montant restant dû par lui en principal, intérêts et frais au jour de la défaillance, déchéance ou prorogation du terme.
            <br><br>
            4.2 La Banque est tenue, dans le mois qui suit le terme de chaque semestre
            civil, de communiquer à la Caution l’état des dettes du Cautionné précisant
            leurs causes, leurs échéances et leurs montants en principal, intérêts, commissions, frais et accessoires restant dus à la fin de chaque semestre
            écoulé, en luirappelant la faculté de révocation parreproduction littérale des
            stipulations du présent article et celles de l’article 19 de l’Acte Uniforme portant organisation des sûretés.
            <br><br>
            4.3 Pour la bonne exécution de cet engagement, la caution s’oblige et s’engage à informer la Banque de tout changement d’adresse le concernant.
          </p>
          <!-- Article 4 Remaining Content -->


          <h4>ARTICLE 5 : MISE EN JEU DU CAUTIONNEMENT</h4>
          <p>
            En cas de non-paiement à son échéance, par le Cautionné, d'une quelconque
            somme due au titre de l’obligation garantie, la Caution sera tenue de payer à
            la Banque, dans la limite du Montant Maximal Garanti, le montant concerné, quinze (15) jours après une mise en demeure adressée au Cautionné restée
            sans effet. La Caution ne pourra pas se prévaloir des délais de paiement accordés conventionnellement ou judiciairement au Cautionné.
          </p>
          <h4>ARTICLE 6 : DUREE</h4>
          <p>
            6.1 Le présent cautionnement entre en vigueur à la date de sa signature et
            restera en vigueur tant que l’obligation garantie n’aura pas été intégralement
            remboursée ou payée.
            <br><br>
            6.2 La Caution peut décider à tout moment de révoquer son engagement
            par notification écrite à la Banque. La révocation prendra effet à l’expiration d’un délai de quatre-vingt-dix (90) jours à compter de la date de réception de
            la lettre de notification. La Caution restera tenue jusqu’au remboursement
            intégral et définitif à la Banque de tous les engagements du Cautionné nés antérieurement à la date de prise d’effet de cette révocation, y compris de
            ceux dont les échéances et l’exigibilité seront postérieurs à cette date
          </p>
          <h4>ARTICLE 7 : DIVERS</h4>
          <p>
            7.1 Le présent cautionnement s’ajoute et s’ajouteraà toutes garanties réelles ou personnelles qui ont pu ou qui pourront être fournies au profit de la Banque par la Caution, par le Cautionné ou par tout tiers.
            <br><br>
            7.2 Toutes les obligations résultant du présent cautionnement pour la Caution sont stipulées indivisibles, de telle sorte que leur exécution pourra être réclamée pour leur totalité à n’importe lequel des héritiers ou ayant- droits de la Caution.
          </p>
          <br>
          <p>Fait à __________ le _________________</p>
          <br>
          <p><strong><u>POUR LE CONSTITUANT (1)</u></strong></p>
        </div>
        <div class="column">
          <!-- Article 2 Remaining Content -->
          <p>
            Montant Maximal
            Garanti, au cas où le Cautionné ne pourrait faire face à ses obligations au titre des Obligations Garanties.
          </p>
          <!-- Article 2 Remaining Content -->

          <h4>ARTICLE 3 : ENGAGEMENTS DE LA CAUTION</h4>
          <p>
            3.1 La Caution renonce expressément aux bénéfices de discussion et de division tant avec le Cautionné qu’avec tous coobligés. <br><br>
            3.2 La Caution renonce expressément, dans l’hypothèse de la déclaration de
            l’exigibilité anticipée des Crédits conformément aux stipulations de la Conventionde Crédit, à se prévaloir, à l’égard de la Banque, de l’inopposabilité
            de la déchéance du terme encourue par le Débiteur Garanti. <br><br>
            3.3 La Caution s’engage, pour toute la durée du présent cautionnement :<br>
            - à informer la Banque par écrit dès qu’elle aura connaissance de tout<br>
            événement susceptible d’entraîner une détérioration de sa situation
            financière ou de sa capacité à faire face à ses obligations au titre du présent cautionnement ;<br><br>
            3.4 La cautiondéclare quela banque a suffisamment attiré sonattention sur :
            - La nature et l’étendue de son engagement ;
            - La proportionnalité entre la valeur de ses biens et le montant du
            cautionnement, ce à quoi il atteste sur l’honneur disposé d’un patrimoine
            suffisant pour couvrir le montant cautionné
          </p>
          <h4>ARTICLE 4 : ENGAGEMENT DE LA BANQUE</h4>
          <p>
            4.1 La Banque est tenue d’informer la Caution de toute défaillance du Cautionné au titre des Obligations Garantie, ainsi que de la
          </p>
          <p style="border-top: 4px solid #fff;">
            7.3 Toutes les notifications auxquelles le présent cautionnement pourra donner lieu seront faites par écrit et seront adressées par lettre
            recommandée avec accusé de réception, remises par porteur avec décharge, ou transmises par un service de courrier de réputation internationale, aux Parties, à leur adresse respective mentionnée en tête des présentes.
          <p>
          <h4>ARTICLE 8 : DECLARATION DE PATRIMOINE</h4>
          <p>
            La Caution déclare que son patrimoine est constitué des éléments actifs et
            passifs et qui sont notoirement connus de la banque.
          </p>

          <h4>Article 9 : Frais et droits</h4>
          <p>
            Le Constituant prend à sa charge les impôts, taxes et autres frais liés à la
            conclusion et à l’exécution du présent acte; notamment ceux qui sont liés à la
            rédaction, l’enregistrement du présent acte, et autorise la BANQUE à débiter son compte pour le règlement desdits frais
          </p>

          <h4>Article 10 : Clauses finales</h4>
          <p>
            Les modifications à la présente convention doivent être faites par écrit. L’invalidation d’une clause n’entache pas la validité des autres dispositions. Les clauses invalides seront aussitôt remplacées par les parties contractantes par des dispositions conformes à la législation et aux usages en vigueur. <br>
            Le fait pour la BANQUE de ne pas user d’un droit dont elle jouit en vertu de la présente convention n'emporte pas renonciation à ce droit. <br>
            La présente convention rentrera en vigueur après recueil des signatures de toutes les parties et les engagera jusqu'au plein accomplissement de la totalité des obligations qu’elle constate.
          </p>

          <h4>Article 11 : Règlements des différends</h4>
          <p>
            La présente convention est soumise au Droit OHADA. <br>
            Pour l’exécution des présentes et de leurs suites, pour tous différends pouvant survenir entre la BANQUE et le Constituant dans leurs rapports d’affaires, et pour toute difficulté à laquelle la présente convention pourrait donner lieu pour son interprétation, sa validité et son exécution, les parties s’accordent pour rechercher une solution amiable.<br>
            A défaut d’accord, la partie la plus diligente en réfèrera aux tribunaux compétents de.
          </p>

          <h4>Article 12 : Election de domicile</h4>
          <p>
            Pour l’exécution des présentes et de leurs suites, domicile est élu :<br>
            - Pour le Constituant, à son adresse ci-dessus ;<br>
            - Pour la BANQUE, en son siège social sus mentionné<br>
            - Dont acte dressé en Cinq (05) exemplaires
          </p>
          <br><br><br><br><br><br><br><br><br>
          <p><strong><u>POUR LA BANQUE</u></strong></p>
        </div>
      </div>
      <div style="width: 80%; margin: auto; padding-left: 5px; padding-right: 5px; text-align: center;">
        (1) "Bon pour cautionnement solidaire dans les termes ci-dessus à hauteur d'un montant maximal de F.CFA <?php echo $appformD['tpmnt']; ?>
        (<?php echo strtoupper($convert->Convert($appformD['tpmnt'])); ?> ) couvrant le paiement du principal, des intérêts, des éventuelles cotisations d'assurance, des commissions, frais et accessoires".
      </div>
      <div>
        <style type="text/css">
          @media print {
            .hidden-print {
              visibility: hidden !important;
            }
          }
        </style>
        <center>
          <button class="btn btn-primary hidden-print" id="page-container" onclick="myfunction()" style="padding: 5px 10px; font-size: 15px;">Print Page</button>
        </center>
        <script type="text/javascript">
          function myfunction() {
            window.print();
          }
        </script>
      </div>
</body>

</html>