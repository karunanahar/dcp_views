<?php 
$documentArray1 = 0;
if(isset($documentArray))
	$documentArray1 = sizeof($documentArray); 
	
$customer=(array) json_decode($appformD['customer_data']);
$databinding=(array) json_decode($appformD['databinding']);
$am=new Class_Amort();
$age= date_diff(date_create($customer['dob']), date_create('today'))->y;
$loan_interest =$appformD['loan_interest'];
$vat_on_interest=$appformD['loan_tax'] ?: '19.25'; 
$rt=($loan_interest*(1+$vat_on_interest/100));
                

if ($age <= 30) {
    if ($appformD['loan_term'] <= 24) {
      $insuranceRate = "0.42";
    } else if ($appformD['loan_term'] <= 35) {
      $insuranceRate = "0.42";
    } else if ($appformD['loan_term'] <= 60) {
      $insuranceRate = "0.52";
    } else if ($appformD['loan_term'] <= 96) {
      $insuranceRate = "0.95";
    } else if ($appformD['loan_term'] <= 144){
      $insuranceRate = "1.52";
    } else{
      $insuranceRate = "2.17"; 
    }
  
} else if ($age <= 40) {
    if ($appformD['loan_term'] <= 24) {
      $insuranceRate = "0.75";
    } else if ($appformD['loan_term'] <= 35) {
      $insuranceRate = "0.75";
    } else if ($appformD['loan_term'] <= 60) {
      $insuranceRate = "0.94";
    } else if ($appformD['loan_term'] <= 96) {
      $insuranceRate = "1.76";
    } else if ($appformD['loan_term'] <= 144){
      $insuranceRate = "2.85";
    } else{
      $insuranceRate = "4.12"; 
    }
} else if ($age <= 50) {
    if ($appformD['loan_term'] <= 24) {
      $insuranceRate = "0.92";
    } else if ($appformD['loan_term'] <= 35) {
      $insuranceRate = "0.92";
    } else if ($appformD['loan_term'] <= 60) {
      $insuranceRate = "1.94";
    } else if ($appformD['loan_term'] <= 96) {
      $insuranceRate = "3.61";
    } else if ($appformD['loan_term'] <= 144){
      $insuranceRate = "5.84";
    } else{
      $insuranceRate = "8.36"; 
    }
} else if ($age <= 60) {
    if ($appformD['loan_term'] <= 24) {
      $insuranceRate = "2.06";
    } else if ($appformD['loan_term'] <= 35) {
      $insuranceRate = "2.06";
    } else if ($appformD['loan_term'] <= 60) {
      $insuranceRate = "4.29";
    } else if ($appformD['loan_term'] <= 96) {
      $insuranceRate = "7.89";
    } else if ($appformD['loan_term'] <= 144){
      $insuranceRate = "12.46";
    } else{
      $insuranceRate = "17.32"; 
    }
} else {
  $insuranceRate = "0.00";
}

$insuranceAmount=($appformD['loan_amt']*$insuranceRate)/100;

 if (($age >= 60) || ($appformD['frais_de_assurance_choice'] == 'N')) {
        $insuranceAmount = $appformD['frais_de_assurance'] ? $appformD['frais_de_assurance'] : "0";
 }

$teg=$am->tegcal($appformD['npmts'],$appformD['loan_amt'],$appformD['pmnt'],$rt,$appformD['frais_de_dossier'],$age,$insuranceAmount);
?>

 

<!DOCTYPE html>

<html>

  <head>
	  <meta charset="UTF-8"/>
	  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
		<style>
			
			.form_top h2{
				font-size: 18px;
				padding: 0px;

				color: #000;
				margin:0;
			}
			.form_top .p-0{
				padding: 0px;

			}
			.form_top .container{
				width: auto;
				padding: 15px;
			}
			.form_top{
				background-color: #fff;
			}
			.form_top p {
				color: #444444;
				font-size: 14px;
				margin-bottom: 5px;
				margin-top: 5px;
			} 
			.form-text{
				padding: 10px 15px;
				border: 1px solid #dddddd;
				border-radius: 5px;
				margin: 10px 0;
			}
			.form_tabel th {
				background-color: #ccc;
				color: #222222;
			}
			.form_tabel tr{
				color: #000;
			}
			.form_btm{ 
				display: flex;
				justify-content: space-between;
				margin-top: 10px;
			}
			.form_top{
				width: 800px;
				background-color: #fff;
				margin: 0px auto; 
				padding: 0px;
			}
		</style>
		<link rel="stylesheet" href="<?php echo base_url('assets/css/compiled/document_css.css" type="text/css');?>" media='all'/>
	</head>
<body style="background-color: #e2e1e0; font-family: Open Sans, sans-serif; font-size: 100%; font-weight: 400; line-height: 1.4; color: #000; margin: 0;">

<div class="form_top">

<div class="container"> 
    <div class="row" style="width: 90%; margin: auto;">

	  <p style="page-break-before: always;">&nbsp;</p>
	  <br><br><br>
      <div class="col-lg-12">
      
                <h2><img src="<?php echo  base_url(); ?>/assets/logo2.png" class="common_document_logo1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Taux Annuel Effectif Global - TAEG</h2>
        
        <h3 style="font-size: 16px;margin: 0;padding-top: 10px;margin-bottom: 10px; color: #333333"> ENTRE LES SOUSSIGNES </h3>

        <p><span style="font-size: 13px; font-weight:bold; border-bottom:solid 1px #000">La AFG BANK GABON</span>, Société Anonyme, inscrite au Registre du Commerce de Libreville, sous le N° 2002 B 01732, NIF 790027 A, dont le Siège Social est situé à Libreville, 714 Avenue du Colonel Parant </p>

        <div class="form-text">

        <p><b>Ci-après dénommée « <span style="font-weight:bold; border-bottom:solid 1px #000">LA BANQUE</span> »                                                <span style="font-weight:bold; border-bottom:solid 1px #000">D’une part,</span>  </b></p>

        <p><b>MONSIEUR, MADAME </b> <?php echo ucfirst($customer['first_name'])." " ?: '-';?><?php echo ucfirst($customer['last_name']) ?: '-';?> <b> De nationalité </b> <?php echo ucfirst($customer['nationality'])." " ?: '-';?></p>

        <p><b>Né(e) à <?php echo $customer['birthplace'];?> </b> <b> le </b><?php echo date("d-m-Y",strtotime($customer['dob']));?><b> Titulaire de la/du </b><?php echo ucfirst($customer['type_id'])." " ?: '-';?></p>

        <p><b>Numéro </b><?php echo ucfirst($customer['id_number'])." " ?: '-';?> <b> du  </b><?php echo date("d-m-Y",strtotime($customer['dateId']))." " ?: '-';?></p>

        <p><b> Profession </b><?php echo ucfirst($customer['employeeOccupation'])." " ?: '-';?><b> Demeurant à </b><?php echo ucfirst($customer['resides_address'])." " ?: '-';?> , <?php echo ucfirst($customer['city_id'])." " ?: '-';?></p>

        <p><b> BP </b><?php echo ucfirst($customer['street'])." " ?: '-';?> </p>

        <p><b>Ci-après dénommé « <span style="font-weight:bold; border-bottom:solid 1px #000">L’EMPRUNTEUR</span> »                                        D’autre part</b> </p>

        <p><b><span style="font-weight:bold; border-bottom:solid 1px #000">L’emprunteur sollicite auprès de la AFG BANK GA un prêt dont les caractéristiques sont les suivantes :</span></b>  </p>

      </div>

	<div class="col-lg-12 p-0"> 
        <table class="table table-bordered form_tabel" style="margin: auto; width: 100%;" CELLSPACING=0 CELLPADDING=0>

    <thead>

      <tr>

        <th>LIBELLE</th>

        <th>Valeur</th>

        <th>TEG</th>

      </tr>

    </thead>

    <tbody>

      <tr>

        <td>Taux nominal fixe</td>

        <td><?php echo ucfirst($appformD['loan_interest'])." " ?: '-';?> </td>

        <td></td>

        

      </tr>

      <tr>

     <td>Montant du Crédit</td>

        <td><?php echo number_format($appformD['loan_amt'],0,',',' ')." " ?: '-';?></td>

       <td></td>

      </tr>

      <tr>

        <td>Périodicité</td>

        <td> MOIS<?php //echo ucfirst($appformD['loan_schedule'])." " ?: '-';?></td>

        <td></td>

      </tr>

      <tr>

        <td>Nombre de remboursements </td>

        <td><?php echo ucfirst($appformD['loan_term'])." " ?: '-';?></td>
        <td><strong><?php echo round($teg['tegvalue'],2)?></strong></td>

      </tr>

      <tr>

        <td>Frais de Dossier HT </td>

        <td><?php
        
        echo number_format($appformD['frais_de_dossier'],0,',',' ')." " ?: '-';
        //if($appformD['loan_amt']<='1500000'){
        //                 $ht = 37000;
        //             }else{
        //                 $ht = 67000;
        //             }
        // echo number_format($ht,0,',',' ')." " ?: '-';
        ?></td>

        <td></td>

</tr>    

<tr>

  <td>Assurances-Décès-Invalidité

(Sous réserve de surprime)

 </td>

 <td>
  
                     <?php echo number_format($insuranceAmount,0,',',' ')." " ?: '-';?>
 </td>

 <td></td>

</tr>

<tr>

<td>

Amortissement HT 

</td>

<td><?php echo number_format($databinding[0]->principal_payment,0,',',' ')." " ?: '-';?></td>
<td></td>
 </tr>

<?php if($loan_type == "credit_confort" || $loan_type == "pp_scolair"){?>
 <tr> 

  <td>Frais d’enregistrement HT </td>

  <td> <?php echo number_format($appformD['frais_denregistrement'],0,',',' ')." " ?: '-';?></td>
  <td></td>
 </tr>
 <?php } ?>



</tbody>

  </table>



      </div>

      <div class="col-lg-12 p-0">

        <div class="form-text">
</br></br>
      <p class="form_btm"><b><span style="font-weight:bold; border-bottom:solid 1px #000">L’EMPRUNTEUR</span></b>                                                                                                                           <span><b><span style="font-weight:bold; border-bottom:solid 1px #000">LA BANQUE</span></b></span></p>

    </div>

  </div><br>
    <p><small><br>Signature précédée de la mention « Je confirme avoir été informé du TEG correspondant au prêt sollicité ce jour »</small> </p>
<br>
<br>
 


    <div class="form-text_btm">

      <p><b>Taux nominal fixe</b> désigne le taux d’intérêt fixe exprimé sur une base annuelle

<b><span style="font-size: 13px; font-weight:bold; border-bottom:solid 1px #000">Le Taux Effectif Global</span></b> est calculé sur une base annuelle, ce taux inclut, outre les intérêts, les frais,

Commissions ou rémunérations de toute nature, directs ou indirects y compris ceux destinés à des 

Intermédiaires intervenus dans l’octroi du prêt.

 </p>



    </div>

    </div>







    </div>





  </div>









</div>
	<style type="text/css">
        @media print {
		  .hidden-print {
			visibility: hidden !important;
		  }
		}
    </style>

	<center> 
		<?php 
		if(isset($documentArray1) && $documentArray1 == $combine_doc){?>
			<button class="btn btn-primary hidden-print" id="printPageButton" onclick="myfunction()" style="position: relative;">Print Page</button>
		<?php }
		else if($documentArray1 == 0){?>
			<button class="btn btn-primary hidden-print" id="printPageButton" onclick="myfunction()" style="position: relative;">Print Page</button>
		<?php }?>
	</center>




<!-- 





































 <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/jquery.js"></script> 









  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/demo-skin-changer.js"></script> 

 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/bootstrap.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/jquery.nanoscroller.min.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/scripts.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/demo.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/jquery.validate.min.js"></script>







  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/jquery.scrollTo.min.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/jquery.slimscroll.min.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/moment.min.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/jquery-jvectormap-1.2.2.min.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/jquery-jvectormap-world-merc-en.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/gdp-data.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/flot/jquery.flot.min.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/flot/jquery.flot.resize.min.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/flot/jquery.flot.time.min.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/flot/jquery.flot.threshold.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/flot/jquery.flot.axislabels.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/jquery.sparkline.min.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/skycons.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/raphael-min.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/morris.js"></script>  







  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/pace.min.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/bootstrap-wizard.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/select2.min.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/jquery.dataTables.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/dataTables.fixedHeader.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/dataTables.tableTools.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/jquery.dataTables.bootstrap.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/jquery.maskedinput.min.js"></script>

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/bootstrap-datepicker.js"></script>

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/moment.min.js"></script>

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/daterangepicker.js"></script>

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/jquery-ui.min.js"></script>

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/jquery.timepicker.js"></script>





   

   <script src="assets/js/upload.js"></script> --> 



  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/modernizr.custom.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/notificationFx.js"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/classie.js"></script> 

  <!-- <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/collateral.custom.js"></script>  -->

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/js/timeline.js"></script>







  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/intl-tel-input-master/build/js/intlTelInput.js?1585994360633"></script> 

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/intl-tel-input-master/examples/js/isValidNumber.js.ejs?1585994360633"></script>

  <script src="http://www.myprojectdemonstration.com/development1/dcp_gabon/assets/intl-tel-input-master/examples/js/displayNumber.js.ejs?1585994360633"></script> 

  </body>
    <script type="text/javascript">
function myfunction(){
window.print();
}
</script>
</html>