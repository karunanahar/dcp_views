<html>
	<head>
<?php

$documentArray1 = 0;
if(isset($documentArray))
	$documentArray1 = sizeof($documentArray); 
// $customer=(array) json_decode($appformD['customer_data']);

$databinding=(array) json_decode($appformD['databinding']);

// echo "<pre>";

// print_r($changeArray);

// echo "</pre>";
$unique=array();
foreach ($changeArray as $value)
    {
        foreach ($value as $value1=>$key1)
    {
        
        array_push($unique,$key1);
    }
    }
    
   
// array_push($a,"blue","yellow");

?>
<style> 
	
</style> 
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap/bootstrap.min.css');?>"/> 
<script src="<?php echo base_url('assets/js/demo-rtl.js');?>"></script> 
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/libs/font-awesome.css');?>"/>
<style>  
	@page { 
		margin: 0;

	}
	@media print { 
		.colorstrip{
				border-color: green; 
				height: 18px;
				border-style: solid; 
				background-color: #11da33
		}
	}
	.colorstrip{
		border-color: green; 
		height: 18px;
		border-style: solid; 
		background-color: #11da33
	}
</style> 
<link rel="stylesheet" href="<?php echo base_url('assets/css/compiled/document_css.css" type="text/css');?>" media='all'/>
</head> 
<body translate="no" style="background-color: #fff; font-family: Open Sans, sans-serif; font-size: 100%; font-weight: 400; line-height: 1.3; color: #444444; margin: 0;">
	<div id="content-wrapper"> 
    <div class="row"> 
      <div class="col-lg-12">
        <div id="content-header" class="clearfix">
			 <div class="main-box-body clearfix" >
				<p style="page-break-before: always;">&nbsp;</p>
                  <center> 
					<h3 id="tab-title" style="margin-top: 20px;">
							<img class="common_document_logo1" src="<?php echo  base_url(); ?>/assets/logo2.png"/>
						<span>Fiche d'actualisation</span>
					</h3>
				  </center>
                   <div class="detail_section" style="margin: 1 30 30 30;">
					<form id="addnewcustomer" action=''  method="post" class="form_style"> 
						<div class="row">
							<div class="col-xs-12 response-msg"></div>
						</div> 
						<h4 id="tab-title" style="margin-top: 5px;"><span>Renseignements Personnels</span></h4>
						<div class="row"> 
						  <?php // echo '<pre>'; print_r($customer);?> 
						<div class="col-xs-3">
							<div class="form-group">
							  <span class="label_style_new">Titre</span>
							  <div id="tab-details" class="<?php if (in_array("title", $unique)){echo "colorstrip"; }?>"> 
							   <?= $customer->title ; ?> 
							  </div>
							</div>
						  </div>
						  <div class="col-xs-3">
							<div class="form-group">
							  <span class="label_style_new"> Prénoms</span>
							  <div id="tab-details" class="<?php if (in_array("first_name", $unique)){echo "colorstrip"; }?>"> 
								<?= $customer->first_name ; ?>
							  </div>
							</div>
						  </div>                  
						  <div class="col-xs-3 hidden">
							<div class="form-group">
							  <span class="label_style_new">2ième Prénoms </span>
							  <div id="tab-details" class="<?php if (in_array("middle_name", $unique)){echo "colorstrip"; }?>"> 
							  <?= $customer->middle_name ; ?>
							   </div>
							</div>
						  </div>
						  <div class="col-xs-3">
							<div class="form-group">
							  <span class="label_style_new"> Nom Patronymique</span>
							  <div id="tab-details" class="<?php if (in_array("last_name", $unique)){echo "colorstrip"; }?>"> 
							  <?= $customer->last_name ; ?>
								
							  </div>
							</div>
						  </div>

						  <div class="col-xs-3">
							<div class="form-group">
							  <span class="label_style_new">Genre </span>
							  <div id="tab-details" class="<?php if (in_array("gender", $unique)){echo "colorstrip"; }?>"> 
									<?= $customer->gender ; ?>
								 
							 </div>
							</div>
						  </div>
						  
						</div>

						<div class="row">
						  
						  <div class="col-xs-3">
							<div class="form-group" >
							  <span class="label_style_new">Date de naissance </span>
							  <div id="tab-details" class="<?php if (in_array("dob", $unique)){echo "colorstrip"; }?>"> 
								<?= date("d-m-Y", strtotime($customer->dob));?>
								 
							  </div>
							</div>
						  </div>

						  <div class="col-xs-3">
							<div class="form-group" >
							  <span class="label_style_new">Lieu de naissance</span>
							  <div id="tab-details" class="<?php if (in_array("birthplace", $unique)){echo "colorstrip"; }?>">
								  <?= $customer->birthplace ; ?>
							  
							  </div>
							</div>
						  </div>

						  <div class="col-xs-3 hidden">
							<div class="form-group">
							  <span class="label_style_new">Dipôme ou Niveau étude </span>
							  <div id="tab-details" class="<?php if (in_array("education", $unique)){echo "colorstrip"; }?>"> 
									<?= $customer->education ; ?>
								
							  </div>
							</div>
						  </div>
						  <div class="col-xs-3">
							<div class="form-group">
							  <span class="label_style_new">Situation Matrimoniale </span>
							  <div id="tab-details" class="<?php if (in_array("marital_status", $unique)){echo "colorstrip"; }?>"> 
									<?= $customer->marital_status ; ?>
								
							   </div>
							</div>
						  </div>
						  <div class="col-xs-3">
							<div class="form-group">
							  <span class="label_style_new">Email </span>
							  <div id="tab-details" class="<?php if (in_array("email", $unique)){echo "colorstrip"; }?>"> 
									<?= $customer->email ; ?>
							   
							  </div>
							</div>
						  </div>
						 <div class="col-xs-3">
							<div class="form-group">
							  <span class="label_style_new">Lieu d'habitation</span>
							  <div id="tab-details" class="<?php if (in_array("resides_address", $unique)){echo "colorstrip"; }?>"> 
								<?= $customer->resides_address ; ?>
								
							  </div>
							</div>
						  </div>
						  <div class="col-xs-3">
							<div class="form-group">
							  <span class="label_style_new">Adresse postale</span>
							  <div id="tab-details" class="<?php if (in_array("street", $unique)){echo "colorstrip"; }?>">  
								<?= $customer->street ; ?>
								
							  </div>
							</div>
						  </div>

						  <div class="col-xs-3">
							<div class="form-group">
							  <span class="label_style_new">Adresse Complémentaire</span>
							  <div id="tab-details" class="<?php if (in_array("alternateAddress", $unique)){echo "colorstrip"; }?>">  
								<?= $customer->alternateAddress ; ?>
								
							  </div>
							</div>
						  </div>


						  <div class="col-xs-3">
							<div class="form-group">
							  <span class="label_style_new">Ville </span>
							  <div id="tab-details" class="<?php if (in_array("city_id", $unique)){echo "colorstrip"; }?>"> 
								<?= $customer->city_id ; ?>
								
							 </div>
							</div>
						  </div>

						   <div class="col-xs-3 hidden">
							<div class="form-group">
							  <span class="label_style_new">Pays de résidence <span style="color:red">*</span></span>
							  <div id="tab-details" class="<?php if (in_array("state_id", $unique)){echo "colorstrip"; }?>"><span> 
								<?= $customer->state_id ; ?>
								
							  </div>
							</div>
						  </div>

							<div class="col-xs-3">
									<div class="form-group">
									  <span class="label_style_new">Capacite Juridique</span> 
									   <div id="tab-details" class="<?php if (in_array("legalCapacity", $unique)){echo "colorstrip"; }?>">
											<?= $customer->legalCapacity ; ?> 
									  </div>   
								</div>
							  </div> 
							  
							  	<div class="col-xs-3">
									<div class="form-group">
									  <span class="label_style_new">ID Client</span> 
									   <div id="tab-details" class="<?php if (in_array("id_client", $unique)){echo "colorstrip"; }?>">
											<?= $customer->id_client ; ?> 
									  </div>   
								</div>
							  </div> 
							</div>
							<h4 id="tab-title" style="margin-top: 1px;"><span>Informations Additionnelles</span></h4>
							<div class="row">
							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Nature de la Pièce d’ Identité </span>                
								 

									<div id="tab-details"  class="<?php if (in_array("type_id", $unique)){echo "colorstrip"; }?>">
										
										<?php echo $customer->type_id;?>
								   

									 </div>                  
								</div>
							  </div>
							  
							  <div class="col-xs-3 ">
								<div class="form-group">
								  <span class="label_style_new">Numéro de la Pièce d’Identité </span>
								  <div id="tab-details" class="<?php if (in_array("id_number", $unique)){echo "colorstrip"; }?>"> 
								  <?= $customer->id_number;?>
									 
								  </div>
								</div>
							  </div>
							  
							   <div class="col-xs-3 ">
								<div class="form-group">
								  <span class="label_style_new">Date etablissement type de piece</span>
								  <div id="tab-details" class="<?php if (in_array("dateId", $unique)){echo "colorstrip"; }?>">  
								  <?= date("d-m-Y", strtotime($customer->dateId));?>
									
								  </div>
								</div>
							  </div>

							   <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Pays Res. Fiscale</span></span>
								  <div id="tab-details" class="<?php if (in_array("state_of_issue", $unique)){echo "colorstrip"; }?>"> 
								  <?= $customer->state_of_issue;?>
									 
								 </div>
								</div>
							  </div> 
							</div>
							<div class="row">
								
							   <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Numéro de téléphone Portable 1</span>
								  <div id="tab-details" class="<?php if (in_array("main_phone", $unique)){echo "colorstrip"; }?>">  
								  <?= $customer->main_phone;?>
								   
								  
								</div>
								</div>
							  </div>



							  <div class="col-xs-3">
								  <div class="form-group">
									<span class="label_style_new">Numéro de téléphone Portable 2</span>
									<div id="tab-details" class="<?php if (in_array("main_phone2", $unique)){echo "colorstrip"; }?>">
										<?= $customer->main_phone2;?>
									 
									</div>  
								
								</div>
							  </div>
							 
							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Second Numéro de téléphone Domicile 1 </span>
								  <div id="tab-details" class="<?php if (in_array("alternative_phone", $unique)){echo "colorstrip"; }?>"> 
								  <?= $customer->alternative_phone;?>
									  
								  </div>
									
								</div>
							  </div>

							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Second Numéro de téléphone Domicile 2</span>
								  <div id="tab-details" class="<?php if (in_array("alter_phone2", $unique)){echo "colorstrip"; }?>">
									  <?= $customer->alter_phone2;?>
									 
								  </div>
								  
								</div>
							  </div> 
							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Date d’Expiration de la Pièce d’Identité </span>
								  <div id="tab-details" class="<?php if (in_array("expiration_date_id", $unique)){echo "colorstrip"; }?>"> 
								  <?= $customer->expiration_date_id;?>
									
								  </div>
								</div>
							  </div> 
							  <div class="col-xs-3">
							  <div class="form-group">
								<span class="label_style_new">Prénoms du Pere </span>
								<div id="tab-details" class="<?php if (in_array("father_firstname", $unique)){echo "colorstrip"; }?>"> 
								<?= $customer->father_firstname;?> 
								</div>
							  </div>
							</div>
							<div class="col-xs-3">
							  <div class="form-group">
								<span class="label_style_new">Nom Pere </span>
								<div id="tab-details" class="<?php if (in_array("father_fullname", $unique)){echo "colorstrip"; }?>"> 
									<?= $customer->father_fullname;?> 
								</div>
							  </div>
							</div>
							<div class="col-xs-3">
							  <div class="form-group">
								<span class="label_style_new">Prénoms du Mere </span>
								<div id="tab-details" class="<?php if (in_array("mother_firstname", $unique)){echo "colorstrip"; }?>"> 
								<?= $customer->mother_firstname;?>
								   
								</div>
							  </div>
							</div> 
							</div>
							<div class="row"> 	
								<div class="col-xs-3">
								  <div class="form-group">
									<span class="label_style_new">Nom Mere </span>
									<div id="tab-details" class="<?php if (in_array("mother_fullname", $unique)){echo "colorstrip"; }?>"> 
									<?= $customer->mother_fullname;?>
									  
									</div>
								  </div>
								</div> 
								   <div class="col-xs-3">
									 <div class="form-group">
									<span class="label_style_new">Nationalité</span>
									 <div id="tab-details" class="<?php if (in_array("nationality", $unique)){echo "colorstrip"; }?>">
										 <?= $customer->nationality;?>
									 </div>
								  </div>
								  </div>
								  <div class="col-xs-3">
									<div class="form-group">
									<span class="label_style_new">Lieu Etablissement Pièce</span>
									<div id="tab-details" class="<?php if (in_array("insurance_place_id", $unique)){echo "colorstrip"; }?>"> 
									<?= $customer->insurance_place_id;?>
									</div>
								  </div>
								  </div>
							</div> 
							<h4 id="tab-title" style="margin-top: 1px;"><span>Information Sur l'Emploi</span></h4>
							<div class="row">
							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Type Emploi </span>
								  <div  id="tab-details" class="<?php if (in_array("employeeStatus", $unique)){echo "colorstrip"; }?>"> 
								  <?= $customer->employeeStatus;?>

									</div>
								</div>
							  </div>
							   <div class="col-xs-3">
								<div class="form-group">
								<span class="label_style_new">Nom de l’employeur</span>
								<div id="tab-details" class="<?php if (in_array("employer_name", $unique)){echo "colorstrip"; }?>"> 
								<?= $customer->employer_name;?>
								</div>
							  </div>
							  </div>

							  <div class="col-xs-3">
								<div class="form-group" style="margin-bottom:5px;">
								  <span class="label_style_new">Secteur d’activité</span> 
								  <div id="tab-details" class="<?php if (in_array("secteurs_id", $unique)){echo "colorstrip"; }?>"> 
								  <?= $customer->secteurs_id;?>
								
								</div>
								</div>
							  </div>

							  <div class="col-xs-3">
								<div class="form-group">
									<span class="label_style_new">Categ. Socio-Prof</span>
									<div id="tab-details" class="<?php if (in_array("categ", $unique)){echo "colorstrip"; }?>"> 
									<?= $customer->categ;?>
								   
									</div>
										
								</div>
							  </div>


							
							</div>
							<div class="row">


							  <div class="col-xs-3">
								<div class="form-group" style="margin-bottom:5px;">
								  <span class="label_style_new">Type Employeur </span>
								  <div id="tab-details" class="<?php if (in_array("cat_employeurs", $unique)){echo "colorstrip"; }?>">
									  <?= $customer->cat_employeurs;?>
								  

								 </div>
								</div>
							  </div>


							  <div class="col-xs-3">

								 <div class="form-group" style="margin-bottom:5px;">
								   
									<span class="label_style_new">Type de Contrat </span>
									 <div id="tab-details" class="<?php if (in_array("contract_type_id", $unique)){echo "colorstrip"; }?>">
										 <?= $customer->contract_type_id;?>
									
									</div>
								  </div>  
							  </div>

							  <div class="col-xs-3">
								<div class="form-group" style="margin-bottom:5px;">
								  <span class="label_style_new">Adresse de l'employeur</span> 
								  <div id="tab-details" class="<?php if (in_array("address_employer", $unique)){echo "colorstrip"; }?>"> 
								  <?= $customer->address_employer;?>
								
								</div>
								</div>
							  </div>

							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Numéro Professionel 1</span>
								  <div id="tab-details" class="<?php if (in_array("numero1", $unique)){echo "colorstrip"; }?>">
									  <?= $customer->numero1;?>
								  
								  </div>
								</div>
							  </div>


							 
							 
							</div>

							<div class="row">

							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Numéro Professionel 2</span>
								  <div id="tab-details" class="<?php if (in_array("numero2", $unique)){echo "colorstrip"; }?>">
									  <?= $customer->numero2;?>
									 
								  </div>
								</div>
							  </div>

							   <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Date d’embauche </span>
								  <div id="tab-details" class="<?php if (in_array("employment_date", $unique)){echo "colorstrip"; }?>"> 
								  <?php
								  if($customer->employment_date){
								  echo date("d-m-Y", strtotime($customer->employment_date));
								  }?>
								 
								  </div>
								</div>
							  </div>
							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Date De Fin de Contrat/Départ à la Retraite</span>
								  <div id="tab-details" class="<?php if (in_array("sate_end_contract_cdd", $unique)){echo "colorstrip"; }?>"> 
								  
									<?php
								  if($customer->sate_end_contract_cdd){
								  echo date("d-m-Y", strtotime($customer->sate_end_contract_cdd));
								  }?>
								 </div>
								</div>
							  </div>
							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Date de présence chez l’employeur actuel </span>
								  <div id="tab-details" class="<?php if (in_array("how_he_is_been_with_current_employer", $unique)){echo "colorstrip"; }?>"> 
								  
								  <?php if($customer->how_he_is_been_with_current_employer) echo date('d-m-Y', strtotime($customer->how_he_is_been_with_current_employer)); ?>
								  </div>
								</div>
							  </div>
							  <div class="col-xs-3 hidden">
								<div class="form-group">
								  <span class="label_style_new">Nombre d’année d’expérience professionnelle </span>
								  <div id="tab-details" class="<?php if (in_array("years_professionel_experience", $unique)){echo "colorstrip"; }?>"> 
								  <?= $customer->years_professionel_experience;?>
									</div>
								</div>
							  </div>
						   </div>
							<div class="row">
							   <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Salaire net </span>
								  <div id="tab-details" class="<?php if (in_array("emp_net_salary", $unique)){echo "colorstrip"; }?>">  
								  <?= $customer->emp_net_salary;?>
									   </div>
								</div>
							  </div>
							  <div class="col-xs-3 hidden">
								<div class="form-group">
								  <span class="label_style_new">Age de retraite prévu </span>
								  <div id="tab-details" class="<?php if (in_array("retirement_age_expected", $unique)){echo "colorstrip"; }?>"> 
									<?= $customer->retirement_age_expected;?>
								  </div>
								</div>
							  </div>
							  <div class="col-xs-3">
								<div class="form-group">
									<span class="label_style_new">Emploi exercé </span>
									<div id="tab-details" class="<?php if (in_array("employeeOccupation", $unique)){echo "colorstrip"; }?>"> 
									<?= $customer->employeeOccupation;?> 
									</div>
								</div>
							  </div>
							   <div class="col-xs-3">
								  <div class="form-group">
									<span class="label_style_new">Nom Ancien Employeur</span>
									<div id="tab-details" class="<?php if (in_array("ancianemployer", $unique)){echo "colorstrip"; }?>">
										<?= $customer->ancianemployer;?>
									   
									</div>
								  </div>
								</div>
							  </div>
							  <div class="row">
							  </div>
							<h4 id="tab-title" style="margin-top: 1px;"><span>Information Sur le Compte Bancaire</span></h4>
							<div class="row">
							  <div class="col-xs-3">
								 <div class="form-group">
								  <span class="label_style_new">Type de compte </span>
							  <div id="tab-details" class="<?php if (in_array("account_type", $unique)){//echo "colorstrip"; 
							  }?>">
								   <?= $customer->account_type;?>
							  </div>                                 
							  </div>   
						   </div>
							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new"> Agence bancaire </span>
								  <div id="tab-details" class="<?php if (in_array("bank_name", $unique)){//echo "colorstrip"; 
								  }?>">  
								  <?= $customer->bank_name;?>
								</div>
							  </div>
							  </div>
							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Téléphone agence bancaire</span>
								  <div id="tab-details" class="<?php if (in_array("bank_phone", $unique)){//echo "colorstrip";
								  }?>">  
								  <?= $customer->bank_phone;?>
								  </div>
								</div>
							  </div>
							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Date ouverture de compte </span>
								  <div id="tab-details" class="<?php if (in_array("opening_date", $unique)){//echo "colorstrip"; 
								  }?>"> 
								  <?php
								  
								  if($customer->opening_date){
								  echo date("d-m-Y", strtotime($customer->opening_date));
								  }?>
									
								   </div>
								</div>
							  </div>
							</div>
							<div class="row">
							   <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Code Bqe</span>
								  <div id="tab-details" class="<?php if (in_array("code_bqe", $unique)){//echo "colorstrip";
								  }?>"> 
								  <?= $customer->code_bqe;?>
								  
								  </div>
								</div>
							  </div>

							   <div class="col-xs-2">
								<div class="form-group">
								  <span class="label_style_new">Code Agc</span>    
								  <div id="tab-details" class="<?php if (in_array("code_agence", $unique)){//echo "colorstrip";
								  }?>">
									  <?= $customer->code_agence;?>
								 
								  </div>
								</div>
							  </div>

							  
							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Numéro de compte</span>
								  <div id="tab-details" class="<?php if (in_array("account_no", $unique)){//echo "colorstrip";
								  }?>"> 
								  <?= $customer->account_no;?>
								  </div>
								</div>
							  </div>

							 
							   <div class="col-xs-2">
								<div class="form-group">
								  <span class="label_style_new">RIB </span>
								  <div id="tab-details" class="<?php if (in_array("rib4", $unique)){//echo "colorstrip"; 
								  }?>"> 
								  <?= $customer->rib4;?>
									</div>
								</div>
							  </div>

							 
							  <div class="col-xs-2">
								<div class="form-group">
								  <span class="label_style_new">Devise</span>
								  <div id="tab-details" class="<?php if (in_array("devise", $unique)){//echo "colorstrip"; 
								  }?>">
									  <?= $customer->devise;?>
								   
								  </div>
								</div>
							  </div> 
							</div>

							<div class="row">

							   <div class="col-xs-3">
										<div class="form-group">
										  <span class="label_style_new">N° Carte Bancaire</span>  
										   <div id="tab-details" class="<?php if (in_array("carte_bancaire", $unique)){echo "colorstrip";
										   }?>"> 
										   <?= $customer->carte_bancaire;?>
								   
								  </div>
								
							  </div>

								  </div>


							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Identifiant National </span>
								  <div id="tab-details" class="<?php if (in_array("ibu", $unique)){//echo "colorstrip";
								  }?>">  
								  <?= $customer->ibu;?>
									
								  </div>
								</div>
							  </div>
						   
							
							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Nature de la Relation </span>
								  <div id="tab-details" class="<?php if (in_array("nature_relation", $unique)){//echo "colorstrip";
								  }?>">  
								  <?= $customer->nature_relation;?>
									
								 </div>
								</div>
							  </div>
							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Categorie Clientèle </span>
								  <div id="tab-details" class="<?php if (in_array("cat_client", $unique)){//echo "colorstrip";
								  }?>"> 
								  <?= $customer->cat_client;?>
									
									</div>
								</div>
							  </div>
							  
							 

									
							</div>

							<div class="row">

							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new"> Type De Clientele</span>
								  <div id="tab-details" class="<?php if (in_array("typeDeClientele", $unique)){//echo "colorstrip"; 
								  }?>">
									  <?= $customer->typeDeClientele;?>
									 
								  </div>
								</div>
							  </div>


							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Etat Dossier KYC </span> 
								  <div id="tab-details" class="<?php if (in_array("dossierkyc", $unique)){//echo "colorstrip";
								  }?>">
									  <?= $customer->dossierkyc;?>
									
								  </div>
								</div>
							  </div>
							   

								<div class="col-xs-3">
								  <div class="form-group">
									  
									<span class="label_style_new">Date Prochaine Revision </span>
									<div id="tab-details" class="<?php if (in_array("prochaineRevision", $unique)){//echo "colorstrip";
									}?>"> 
									<?php
								  
								  if($customer->prochaineRevision){
								  echo date("d-m-Y", strtotime($customer->prochaineRevision));
								  }?>
									 
									  </div>
						  
								  </div>
								</div>
							  
							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Selection Clientelle</span>
								  <div id="tab-details" class="<?php if (in_array("segmentation", $unique)){//echo "colorstrip"; 
								  }?>">  
								  <?= $customer->segmentation;?>
									
								  </div>
								</div>
							  </div>
							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Cotation Risque</span>
								  <div id="tab-details" class="<?php if (in_array("risk_level", $unique)){//echo "colorstrip";
								  }?>"> 
								  <?= $customer->risk_level;?>
								  
								 </div>
								</div>
							  </div>
							  <div class="col-xs-3">
								<div class="form-group">
									<?php 
									// print_r($customer)
									;?>
								  <span class="label_style_new">Date de Cotation</span>
								  <div id="tab-details" class="<?php if (in_array("risk_level_date", $unique)){//echo "colorstrip"; 
								  }?>"> 
								  <?= $customer->risk_level_date;?>
									
								 </div>
								</div>
							  </div>
							  
							  
							  <div class="col-xs-3">
										<div class="form-group">
										  <span class="label_style_new">Montant Autorisation en Code Atlas</span>
										  <div id="tab-details" class="<?php if (in_array("authCode", $unique)){//echo "colorstrip"; 
										  }?>"> 
										  <?= $customer->authCode;?>
									
									</div>
							  
										</div>
									  </div>

									  <div class="col-xs-3">
										<div class="form-group">
										  <span class="label_style_new">Date Echeance Autorisation</span>
										  <div id="tab-details" class="<?php if (in_array("authDate", $unique)){//echo "colorstrip"; 
										  }?>"> 
										  <?= $customer->authDate;?>
									
									</div>
								
										</div>
									  </div>
							</div>


							<div class="row">

							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Nom Gestionnaire</span>
								  <div id="tab-details" class="<?php if (in_array("nomGestionnaire", $unique)){//echo "colorstrip";
								  }?>"> 
								  <?= $customer->nomGestionnaire;?>
									
								  </div>
								</div>
							  </div>

							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Code Gestionnaire</span>
								  <div id="tab-details" class="<?php if (in_array("codeGestionnaire", $unique)){//echo "colorstrip"; 
								  }?>"> 
								  <?= $customer->codeGestionnaire;?>
									 
								  </div>
								</div>
							  </div>

							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">État Autorisation </span>
								  <div id="tab-details" class="<?php if (in_array("etatAutorisation", $unique)){//echo "colorstrip"; 
								  }?>"> 
								  <?= $customer->etatAutorisation;?>
									 
								  </div>
						
								</div>
							  </div>

							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new"> Surveillance </span>
								  <div id="tab-details" class="<?php if (in_array("Surveillance", $unique)){//echo "colorstrip";
								  }?>">
									  <?= $customer->Surveillance;?>
								   
								  </div>
						
								</div>
							  </div>


							</div>

							<div class="row">
							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Deces </span>
								  <div id="tab-details" class="<?php if (in_array("Deces", $unique)){//echo "colorstrip";
								  }?>"> 
								  <?= $customer->Deces;?>
									 
								  </div>
						
								</div>
							  </div>

							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Contentieux</span>
								  <div id="tab-details" class="<?php if (in_array("Contexntieux", $unique)){//echo "colorstrip"; 
								  }?>"> 
								  <?= $customer->Contexntieux;?>
									
								  </div>
								</div>
							  </div>

							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new"> Interdit </span>
								  <div id="tab-details" class="<?php if (in_array("Interdit", $unique)){//echo "colorstrip"; 
								  }?>"> 
								  <?= $customer->Interdit;?>
									
								  </div>
								</div>
							  </div>

							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Indicateur Pep</span>
								  <div id="tab-details" class="<?php if (in_array("pep", $unique)){//echo "colorstrip"; 
								  }?>"> 
								  <?= $customer->pep;?>
									
								  </div>  
					  
								</div>
							  </div>

							</div>

							<div class="row">

							  <div class="col-xs-3">
								<div class="form-group">
								  <span class="label_style_new">Niveau De Vigilance</span>
								  <div id="tab-details" class="<?php if (in_array("niveiu", $unique)){//echo "colorstrip"; 
								  }?>"> 
								  <?= $customer->niveiu;?>
								   
								  </div>
								 </div>
							  </div>

							  <div class="col-xs-3">
								<div class="form-group">
								<span class="label_style_new"> Date De Derniere Evaluation</span>
								  <div id="tab-details" class="<?php if (in_array("datedernier", $unique)){//echo "colorstrip";
								  }?>"> 
									<?= $customer->datedernier;?>
									
								  </div>
								</div>
							  </div>
							  
							   <div class="col-xs-3">
								<div class="form-group">
								<span class="label_style_new"> Particularite de Gestion</span>
								  <div id="tab-details" class="<?php if (in_array("particularite_de_gestion	", $unique)){//echo "colorstrip";
								  }?>"> 
									<?= $customer->particularite_de_gestion	;?>
									
								  </div>
								</div>
							  </div>
							  
							   <div class="col-xs-3">
								<div class="form-group">
								<span class="label_style_new">Flexcube Acct</span>
								  <div id="tab-details" class="<?php if (in_array("flexcube_acct", $unique)){//echo "colorstrip";
								  }?>"> 
									<?= $customer->flexcube_acct;?>
									
								  </div>
								</div>
							  </div>
							  
							  
							   <div class="col-xs-3">
								<div class="form-group">
								<span class="label_style_new">Flexcube Code Agence</span>
								  <div id="tab-details" class="<?php if (in_array("flexcube_code", $unique)){//echo "colorstrip";
								  }?>"> 
									<?= $customer->flexcube_code;?>
									
								  </div>
								</div>
							  </div>
							  
							  
							   <div class="col-xs-3">
								<div class="form-group">
								<span class="label_style_new">Flexcube Code Gestionnaire</span>
								  <div id="tab-details" class="<?php if (in_array("flexcube_code_gestionnaire", $unique)){//echo "colorstrip";
								  }?>"> 
									<?= $customer->flexcube_code_gestionnaire	;?>
									
								  </div>
								</div>
							  </div>


							</div> 
							<!--  </form>     -->                   
							<!--  </div> -->
							</form>
						  </div>
					  </div>
				  </div>
			   </div>
		  </div>
	  </div>
	</div>
	<center>
		<style type="text/css">
			@media print {
			  .hidden-print {
				visibility: hidden !important;
			  }
			}
		</style>
		<?php 
		if(isset($documentArray1) && $documentArray1 == $combine_doc){?>
			<button class="btn btn-primary hidden-print" id="printPageButton" onclick="myfunction()" style="position: relative;">Print Page</button>
		<?php }
		else if($documentArray1 == 0){?>
			<button class="btn btn-primary hidden-print" id="printPageButton" onclick="myfunction()" style="position: relative;">Print Page</button>
		<?php }?>
	</center>    
</body>
    <script type="text/javascript">
		function myfunction(){
			window.print();
		}
	</script>
</html>
