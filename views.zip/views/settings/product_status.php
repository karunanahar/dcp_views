<style type="text/css">
	
	.form-control .has-error{
		border: 1px solid #ff0000;
	}



fieldset {
    font-family: sans-serif;
    border: 1px solid #eee;
   	border-radius: 5px;
    padding: 2px;
}

fieldset legend {
    background: #dff0d8;
    color: #000;
    padding: 5px 10px ;
    font-size: 14px;
    border-radius: 5px;
}

.switch {
  position: relative;
  display: inline-block;
  width: 50px;
  height: 20px;
}

.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 15px;
  width: 15px;
  left: 4px;
  bottom: 3px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
</style>
<div id="content-wrapper">
	<div class="row">
		<?php 
		
		
		?>	

		<div class="col-lg-12">
			<div class="row">
				<div class="col-lg-12">
					<div id="content-header" class="clearfix">
						<div class="pull-left">
							<ol class="breadcrumb">
								<li><a href="<?php echo base_url('/');?>">Dashboard</a></li>
								<li><span>Product Status</span></li>
								
							</ol>
						</div>
					</div>
					<h1>Change Product Status</h1>
				</div>
			</div>

			<div class="row">
				<div class="col-lg-12">

					
					<?php if($this->session->flashdata("flash_message")) {?>
					<div class="alert alert-success fade in" role="alert">
						<?php echo $this->session->flashdata("flash_message");?>
                       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					</div>
				<?php }?>
					<div class="main-box">	
										
						<div class="main-box-body clearfix">
							<br>
							
							<form action ="<?php echo base_url('Settings/save_product_status');?>" method="POST">
							<div class="row"  style="margin-bottom: 2%;">
							<div class="col-md-12">

									<fieldset>
										<legend>List of loan Products</legend>
										<table id="sys_table" class="table table-hover sorttable_c">
									<?php 

										if(!empty($loan_products)){
										foreach($loan_products as $key=>$sys_row) { ?>
											
											<tr>
												<td style="width:70%"><input type="hidden" class="docid_c" name="doc_id[]"  value="<?php echo $sys_row['loan_id'];?>" required="true"  /><i class="fa fa-file"></i> <?php echo ucwords($sys_row['loan_original_name']);?></td>
												<td><label class="switch">
												<input type="checkbox" class="status_c" <?php echo $sys_row['status'] ? "checked" :  "" ;?>>
											  	<span class="slider round"></span>
												</label>
												<input type="hidden" class="input_status" name="status[]" value="<?php echo $sys_row['status']; ?>"></td>
												
											</tr>
											
									<?php  }
									}
								?>
										</table>
									</fieldset>
								
								
							</div>
							</div>

							<div class="form-group">
								<div class="col-lg-offset-4 col-lg-10">
									<button type="submit" id="button_1" class="btn btn-primary">SAVE DETAILS</button>
									<img src="<?php echo  base_url('assets/img/select2-spinner.gif');?>" class="saveloder" style="position: absolute;top: 8px;    left: 123px;    display: none;">
								</div>
							</div>
							
						 </form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<script>

	




	$(".product_type_c").change(function()
	{
		

		if($(this).val() != "" && ($(".product_type_c").val() == 'credit_conso' || $(".product_type_c").val() == 'credit_scolair' || $(".product_type_c").val() == 'credit_confort') )
			{
				$("#docForm").submit();
			}
			else if($(".sub_product_type_c").val() == '' && ($(this).val() == 'commune' || $(this).val() == 'depassment'))
			{
				$("#docForm").submit();
			}
		
	});


	$(".status_c").click(function(){
		if($(this).is(":checked"))
		{
			$(this).closest("td").find(".input_status").val("1");
		}
		else
		{
			$(this).closest("td").find(".input_status").val("0");
		}
	});

	
</script>		