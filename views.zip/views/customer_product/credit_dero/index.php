<style type="text/css">
	.hidden { display: none; }

	.lodertypeof {    
  background-color: #dff0d8c7;
  background-image: url("<?php echo base_url('assets/img/select2-spinner.gif');?>");
  background-size: 18px 18px;
  background-position:right center;
  background-repeat: no-repeat;
  opacity: 0.5;
  }
  
  
  
.accordion {

  background-color: #eee;

  color: #444;

  cursor: pointer;

  padding: 12px;

  width: 100%;

  border: none;

  text-align: left;

  outline: none;

  font-size: 14px;

  transition: 0.4s;

}



.accordion:active, .accordion:hover {

  background-color: #ccc; 

}



.panel {

  padding: 0 18px;

  display: none;

  background-color: white;

  overflow: hidden;

}

.main-box .main-box-body {
    padding: 10px 10px 10px 10px;
}


.info_box_icon_top {
    display: flex;
    padding: 7px;
    border-radius: 10px;
}
.info_box_icon i {
    font-size: 30px;
    color: #fff;
}
.info_box_text{
padding: 10px;
color: #000;	
}
.info_box_icon {
    width: 73px;
    height: 75px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #b1b3b5;
}
.info_box_g{
	color: #015a94;
	font-weight : 600 !important;
}.info_box_r{
	color: #f4786e;
	font-weight : 600 !important;
}
.info_box_p{
   color: #009136;
   font-weight : 600 !important;
}

.view_info{
    font-size:13px;
    float:right;
}

</style>
<div id="content-wrapper">
	<div class="row">
		<div class="col-lg-12">

			<div id="content-header" class="clearfix">
				<div class="pull-left">
					<ol class="breadcrumb">
						<li><a href="<?php echo base_url('Dashboard');?>">Tableau de bord</a></li>
						<li class="active"><span>Crédit Dérogatoire</span></li>
						<?php //print_r($this->session->username);?>
					</ol>
				</div>
			</div>
			<div class="main-box-body clearfix">
			    
			    <?php if($this->session->flashdata('flash_message')){?>
			     <div class="row">
			        <div class="col-md-12">
				         <div class="alert alert-success alert-dismissible">
							<button type="button" class="close" data-dismiss="alert">×</button>
						    <?php echo $this->session->flashdata('flash_message');?>
						</div>
			        </div>
		        
			    <?php } ?>
			    
			    
			    <?php if($this->session->flashdata('error_message')){?>
			     <div class="row">
			        <div class="col-md-12">
				         <div class="alert alert-danger alert-dismissible">
							<button type="button" class="close" data-dismiss="alert">×</button>
						    <?php echo $this->session->flashdata('error_message');?>
						</div>
			        </div>
		        
			    <?php } ?>
			    
			    
			    <div class="row" style="margin-bottom:1%">
			        <div class="col-md-12">
				    <?php 

                    if (in_array('4_1', $this->session->userdata('portal_permission'))){?>
    				<a href="javascript:void(0);" class="btn btn-primary  openBtn"  data-toggle="modal" data-target="#myModal">
    					<i class="fa fa-plus-circle fa-lg"></i> Nouvelle demande de Prêt Crédit Dérogatoire
    				</a>
    				<?php } ?>
    				<a href="<?php echo base_url('PP_Credit_Derogatoire/archive_loan')?>" class="btn btn-primary pull-right">
    					<i class="fa fa-archive fa-sm"></i> Archive Loans
    				</a>
				
				    </div>
				</div>
				
				<div class="row">

            <!--Start Asset Dashboard-->
           
    		<div class="col-md-2 col-sm-6 col-xs-12">
    		    <div class="main-box small-graph-box  info_box_icon_top" style="max-height: 101px;">
            
    				<!--<div class="info_box_icon">-->
    				<!--	<i class="fa fa-bell"></i>-->
        <!--            </div>-->
    
    				<div class="info_box_text">
    				<span class="value text-left"><?php echo $applied['count'];?></span>
                    <span class="headline text-left">Demandes Actives - Today</span>
    				<a href="javascript:0;" class="applied_flip"><span class="view_info" id="applied_total">View Total</span></a>
    			    </div>
                </div>
        		
            </div>

		<div class="col-md-2 col-sm-6 col-xs-12">
           
            <div class="main-box small-graph-box  info_box_icon_top ">
				<!--<div class="info_box_icon info_box_g">-->
				<!--<i class="fa fa-clock-o" aria-hidden="true"></i>-->
    <!--			</div>-->
                <div class="info_box_text">
    				<span class="value text-left info_box_g"><?php echo $other_count['pending_loans'];?></span>
                    <span class="headline text-left info_box_g">En Attente- Today</span>
    				<a href="javascript:0;" class="pending_flip"><span class="view_info" id="pending_total">View Total</span></a>
    			</div>
            </div>
            
		</div>



		<div class="col-md-2 col-sm-6 col-xs-12">
            <div class="main-box small-graph-box info_box_icon_top">
				<!--<div class="info_box_icon info_box_p">-->
    <!--                <i class="fa fa-check" aria-hidden="true"></i>-->
    <!--            </div>-->

			    <div class="info_box_text">
                    <span class="value text-left info_box_p"><?php echo $other_count['approved_loans'];?></span>
                    <span class="headline text-left info_box_p">Approuvées- Today</span>
                    <a href="javascript:0;" class="approved_flip"><span class="view_info" id="approved_total">View Total</span></a>
			    </div>
        	</div>
        </div>
		
		
		<div class="col-md-2 col-sm-6 col-xs-12">
            <div class="main-box small-graph-box info_box_icon_top">
            <!--	<div class="info_box_icon info_box_r">-->
            <!--    <i class="fa fa-times" aria-hidden="true"></i>-->
            <!--</div>-->
            
            	<div class="info_box_text">
                    <span class="value text-left info_box_r"><?php echo $other_count['rejected_loans'];?></span>
                    <span class="headline text-left info_box_r">Rejetées- Today</span>
                    <a href="javascript:0;" class="rejected_flip"><span class="view_info" id="rejected_total">View Total</span></a>
            	</div>
            </div>
        </div>
        
        <div class="col-md-2 col-sm-6 col-xs-12">
            <div class="main-box small-graph-box info_box_icon_top">
            <!--	<div class="info_box_icon info_box_r">-->
            <!--    <i class="fa fa-ban" aria-hidden="true"></i>-->
            <!--</div>-->
            
            	<div class="info_box_text">
                    <span class="value text-left info_box_r"><?php echo $cancel['count'];?></span>
                    <span class="headline text-left info_box_r">Annulé- Today</span>
                    <a href="javascript:0;" class="cancelled_flip"><span class="view_info" id="cancelled_total">View Total</span></a>
            	</div>
            </div>
        </div>
	
	</div>
	    <!--End Asset Dashboard-->
				<div class="row" style="margin-top:10px;">					
					<div class="col-lg-12">
						

						<div class="main-box clearfix">

							
							<header class="main-box-header clearfix">								
									<div class="form-group pull-left">
										
									</div>	
								<textarea class="checkstatus form-control" rows="10" style="display: none"></textarea>
							</header>
							<div class="main-box-body clearfix">
							    
							      <button class="accordion active">
							        <?php $role_id  = $this->session->userdata('role');
							           if($role_id =="2" || $role_id =="3")
							           {
							              echo "Mon Agence"; 
							           }
							           else{
							               echo "Demandes en Attente";
							           }
							        ?>
							        
							        </button>

            	                    <div class="panel" style="display: block;">
        								<div class="table-responsive">
        									<table id="table-example" class="table table-hover table-striped">
        										<thead>
        											<tr>
        											    <!--<th style="display:none;">S.no</th>-->
        												<th>Numéro Demande</th>
        												<th>Flexcube Acct</th>
        												<!--<th>Code Exploitant</th>-->
        												<th>Agence</th>
        												<th>Exploitant Placeur</th>
        												<th>Client Agence Bancaire</th>
        												<th>Client</th>
        												<!-- <th>Date De Dernier Paiement</th> -->
        												<th width="12%">Date De Demande Prêt</th>
        												<th>Montant Du Prêt</th>
        												<th>Taux Interet</th>
        												<th width="5%">Durée</th>
        												<th width="5%">Statut</th>
        												<th width="15%">Vue</th>
        											</tr>
        										</thead>
        										<tbody>
        										   
        										
        										</tbody>
        									</table>
        								</div>
        							</div>

                                  <button class="accordion">
                                    
                                    <?php   if($role_id =="2" || $role_id =="3")
							           {
							              echo "Autres Agences"; 
							           }
							           else{
							               echo "Demandes Traitées";
							           }?>
						           </button>
						           
						            <div class="panel">
                                     <div class="table-responsive">
									<table id="table-example1" class="table table-hover table-striped" width="100%">
										<thead>
										<tr>
										    <th>Numéro Demande</th>
											<th>Flexcube Acct</th>
											<!--<th>Code Exploitant</th>-->
										    <th>Agence</th>
											<th>Exploitant Placeur</th>
											<th>Client Agence Bancaire</th>
											<th>Client</th>
											<!-- <th>Date De Dernier Paiement</th> -->
											<th>Date De Demande Prêt</th>
											<th>Montant Du Prêt</th>
											<th>Taux Interet</th>
											<th>Durée</th>
											<th>Statut</th>
											<th>Vue</th>
											
											</tr>
										</thead>
										<tbody>
											
										
										</tbody>
									</table>
								</div>
                                </div>
							</div>
						</div>
					</div>
				</div>
			</div>			
		</div>
	</div>
	<div id="myModal" class="modal fade" role="dialog" data-keyboard="false" data-backdrop="static">
	  	<div class="modal-dialog modal-full-height modal-left modal-notify modal-info">	
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title heading lead">Nouvelle demande de Prêt Crédit Dérogatoire</h4>
				</div>
			   <form role="form" method="post" id="NewloanForm">
					<div class="modal-body">   
						<div class="error-msg"></div>    
						<div class="form-group">
							<label>MONTANT DEMANDE</label>
							<div class="input-group">
								<span class="input-group-addon">F CFA</span>
							
								<input type="text" class="form-control numberformat" id="loan_amt"  name="loan_amt" required>
							</div>
							<span class="amterror"></span>
						</div>
						
						<div class="form-group">
									<label>VALEUR RG</label>
									<div class="input-group">
										<select class="form-control borderRadiusInput" id="value_rg" name="value_rg" required>
											<option value="">Veuillez sélectionner la Valeur RG</option>
											<option value="00">00</option>
											<option value="10">10</option>
											<option value="20">20</option>
										</select>
										<span class="input-group-addon addsch borderRadiusInputright">%</span>
									</div>
								</div>

						<div class="form-group">
							<label>OBJET DU FINANCEMENT</label>
							
							<!--<select class="form-control" id="loan_object_drop" onchange='add_object(this.value);' required>-->
								
							<!--	<option value="fetes a la carte" selected >Credit Dérogatoire</option>-->
							<!--	<option value="other">Other</option>-->
							<!--</select>-->
								<input type="text" class="form-control" id="loan_object"  name="loan_object"  value="Credit Derogatoire" >
							
							
						</div>
						
						<div class="form-group">
							<label>BUREAU</label>
							
						<select class="form-control" name="department" id="department" aria-invalid="false" required>
    	        			<option value="">Select Bureau</option>	
    	        			<?php if(!empty($bureau)){ 
    	        			    foreach($bureau as $b){
    	        			        
    	        			    $bvalue =  $this->Common_model->get_bureau_value($b['branch_name']);
    	        			?>
    	        			    <option value="<?php echo $bvalue;?>"><?php echo $b['branch_name']; ?></option>
    	        			
    	        			<?php } } ?>
    	        			
    	        		</select>
							
							
							
						</div>

						<div class="form-group">
							<label>TAUX D'INTERET</label>
							<div class="input-group">							
								<input type="number" class="form-control" id="loan_interest" name="loan_interest" step="any" value="12" >
								<span class="input-group-addon">%</span>
							</div>
						</div>
						<div class="form-group">
							<label>Durée</label>
							<div class="input-group">
							    <input type="text" class="form-control numberformat" id="loan_term"  name="loan_term" required>
								
								<span class="input-group-addon addsch">MOIS</span>
							</div>
						</div>
						<div class="form-group">
							<label>PERIODICITE DE REMBOURSEMENT</label>
							<select class="form-control required" name="loan_schedule" id="loan_schedule" readonly>
								<option value="Monthly" selected>MOIS</option>
								<!--<option value="Quarterly" >TRIMESTRE</option>-->
								<!--<option value="Half Yearly">SEMESTRE</option>-->
								<!--<option value="Yearly">ANNEE</option>-->
							</select>
						</div>
						<div class="form-group">
							<label>TVA</label>
							<div class="input-group">							
								<input type="number" class="form-control" id="tva" name="tva" step="any" min="0" max="100" value="18" readonly="readonly">
								<span class="input-group-addon">%</span>
						</div>
						<div class="form-group">
							<label>CSS</label>
							<div class="input-group">							
								<input type="number" class="form-control" id="css" name="css" step="any" min="0" max="100" readonly="readonly" value="1">
								<span class="input-group-addon">%</span>
						</div>
						<!--<div class="form-group">-->
						<!--	<label>TEG PERIODIQUE</label>-->
						<!--	<div class="input-group">							-->
						<!--		<input type="number" class="form-control" id="periodic_teg" name="periodic_teg" step="any" min="0" max="100">-->
						<!--		<span class="input-group-addon">%</span>-->
						<!--	</div>-->
						<!--</div>-->
						<!--<div class="form-group">-->
						<!--	<label>TAUX USURE</label>-->
						<!--	<div class="input-group">							-->
						<!--		<input type="number" class="form-control" id="wear_rate" name="wear_rate" step="any" min="0" max="100">-->
						<!--		<span class="input-group-addon">%</span>-->
						<!--	</div>-->
						<!--</div>		-->
						<!--<div class="form-group">-->
						<!--	<label>TAUX FOND DE GENERATIE</label>-->
						<!--	<input type="number" class="form-control numberformat" id="loan_guarantee" name="loan_guarantee" step="any" min="0" max="100" >-->
						<!--</div>	       -->
				  </div>

				  	<div class="modal-footer justify-content-center">
				  		<input type="hidden" class="form-control" name="loan_fee" value="0">
				  		<input type="hidden" class="form-control" name="loan_type" value="14">
				  		<input type="hidden" class="form-control" name="vat_on_interest" value="<?php echo $loanrange[0]['vat_on_interest'] ?: '19.25';?>">
				  		<input type="hidden" class="form-control" name="loan_commission" value="0">	
						 
					  	<button type="submit" class="btn btn-primary waves-effect waves-light submitBtn"><img src="<?php echo  base_url('assets/img/select2-spinner.gif');?>" class="pull-left lodergif" style="position:relative;top:2px;left:-3px; display:none;"> SOUMETTRE</button>
					  	<button type="button" class="btn btn-danger waves-effect waves-light"  data-dismiss="modal">FERMER</button>
						</div>
				</form>
			</div>
		</div>
	</div>
	<!-- ================== -->
</div>
</div>

	<!-- Confirm popup -->

<div class="modal fade" id="cnfrm_delete" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="smallModalLabel">Confirmation</h4>
            </div>
            <!--Do you want to proceed-->
            <div class="modal-body">Voulez-Vous Poursuivre ?</div>
            <div class="modal-footer">
                <a type="button" href="" class="btn btn-primary waves-effect yes-btn">Oui</a>
                <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">Non</button>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="show_popup" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="smallModalLabel">Assignation</h4>
            </div>
            <form action="<?php echo base_url()?>PP_Credit_Derogatoire/update_assignee" method="POST">
            <div class="modal-body">Voulez-vous vraiment l'assigner à un nouveau Expl/Placeur ?
            <!--Are you sure you want to update Account Manager ?-->
             <div class="row">
                    <div class="col-md-12">
                    	<div class="form-group">
    						<label>Expl/Placeur</label>
    						<input type="hidden" name="loan_id" id="assign_loanid" value="">
    						<select class="form-control" name="userinfo" id="userinfo" required>
    						</select>
    						
    			        </div>
    			    </div>
		        </div>
		        
		        <div class="row">
                    <div class="col-md-12">
                    	<div class="form-group">
    						<label>Raison</label>
    					    <textarea class="form-control" name="addremark" required></textarea>
    						
    			        </div>
    			    </div>
		        </div>
	        </div>
            <div class="modal-footer">
                 <button type="submit" class="btn btn-primary waves-effect">Soumettre</button>
                 <button type="button" class="btn btn-primary waves-effect" data-dismiss="modal">Annuler</button>
            </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" id="other_popup" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="smallModalLabel">Assignation</h4>
            </div>
            <div class="modal-body"></div>
            <div class="modal-footer">
                 <button type="button" class="btn btn-primary waves-effect" data-dismiss="modal">OK</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="overide_popup" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="smallModal">Confirmation</h4>
            </div>
            <form action="<?php echo base_url()?>PP_Credit_Derogatoire/overideloan_to_user" method="POST">
            <div class="modal-body">
                <span id="confirm_ques"></span>
                
                <div class="row">
                    <div class="col-md-12">
                    	<div class="form-group">
    						<label>Raison</label>
    						<input type="hidden" name="loan_id" id="overide_loanid" value="">
    						<textarea class="form-control" name="override_reason" required></textarea>
    						
    			        </div>
    			    </div>
		        </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary waves-effect">Soumettre</button>
                <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">Annuler</button>
            </div>
            </form>
        </div>
    </div>
</div>
	<!-- confirm popup -->
</div>
</div>

 
<script src="<?php echo  base_url(); ?>assets/js/demo-skin-changer.js"></script>  
<script src="<?php echo  base_url(); ?>assets/js/jquery.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/bootstrap.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/jquery.nanoscroller.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/demo.js"></script>  

<script src="<?php echo  base_url(); ?>assets/js/jquery.scrollTo.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/jquery.slimscroll.min.js"></script> 
<script src="<?php echo  base_url(); ?>assets/js/moment.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/jquery-jvectormap-1.2.2.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/jquery-jvectormap-world-merc-en.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/gdp-data.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/flot/jquery.flot.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/flot/jquery.flot.resize.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/flot/jquery.flot.time.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/flot/jquery.flot.threshold.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/flot/jquery.flot.axislabels.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/jquery.sparkline.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/skycons.js"></script>

<script src="<?php echo  base_url(); ?>assets/js/raphael-min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/morris.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/scripts.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/pace.min.js"></script>

<script src="<?php echo  base_url(); ?>assets/js/bootstrap-wizard.js"></script>

<script src="<?php echo  base_url(); ?>assets/js/select2.min.js"></script>
<script src="<?php echo base_url('assets/js/jquery.validate.min.js');?>"></script>



<script src="<?php echo base_url();?>assets/js/modernizr.custom.js"></script> 
<script src="<?php echo base_url();?>assets/js/notificationFx.js"></script> 
<script src="<?php echo  base_url(); ?>assets/js/classie.js"></script>

<script src="<?php echo  base_url(); ?>assets/js/jquery.dataTables.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/dataTables.fixedHeader.js"></script>
<!--<script src="<?php echo  base_url(); ?>assets/js/dataTables.tableTools.js"></script>-->
<script src="<?php echo  base_url(); ?>assets/js/jquery.dataTables.bootstrap.js"></script>
 

<script>

// Accordion
var acc = document.getElementsByClassName("accordion");

var i;



for (i = 0; i < acc.length; i++) {

  acc[i].addEventListener("click", function() {

    this.classList.toggle("active");

    var panel = this.nextElementSibling;

    if (panel.style.display === "block") {

      panel.style.display = "none";

    } else {

      panel.style.display = "block";

    }

  });

}

$(".applied_flip").click(function(){
   $.ajax({
       url:"<?php echo base_url()?>PP_Credit_Derogatoire/get_appliedloans",
       success:function(response){
          $("#applied_total").text('View Total:'+response);  
       }
    });
});


$(".cancelled_flip").click(function(){
   $.ajax({
       url:"<?php echo base_url()?>PP_Credit_Derogatoire/get_cancelledloans",
       success:function(response){
          $("#cancelled_total").text('View Total:'+response);  
       }
    });
});


$(".pending_flip").click(function(){
   $.ajax({
        url:"<?php echo base_url()?>PP_Credit_Derogatoire/get_otherloans",
       success:function(response){
           var res = JSON.parse(response);
          $("#pending_total").text('View Total:'+res.pending_loans);  
       }
    });
});

$(".approved_flip").click(function(){
   $.ajax({
       url:"<?php echo base_url()?>PP_Credit_Derogatoire/get_otherloans",
       success:function(response){
           var res = JSON.parse(response);
          $("#approved_total").text('View Total:'+res.approved_loans);  
       }
    });
});

$(".rejected_flip").click(function(){
  $.ajax({
        url:"<?php echo base_url()?>PP_Credit_Derogatoire/get_otherloans",
      success:function(response){
          var res = JSON.parse(response);
          $("#rejected_total").text('View Total:'+res.rejected_loans);  
      }
    });
});


function set_status(val1,val2){
    
    $("#other_popup").find('.modal-body').text("");
    $.ajax({
        url:"<?php echo base_url()?>PP_Credit_Derogatoire/assign_status",
        type:"POST",
        data:{'loan_id':val1,'status':val2},
        success:function(response){
            
            var result  =  JSON.parse(response);
            console.log(result);
            
            if(result['status'] == '1' && result['condition'] == "assign_to_myself")
            {   $("#overide_loanid").val(val1);
                $("#overide_popup").find('#confirm_ques').text("Cette demande est déjà assignée à "+result['user']+".  Voulez-vous la Réassigner?"); //Do you want to overide as it is assigned to username ?
                $("#overide_popup").modal('show');
            }
            else if(result['status'] == '2' && result['condition'] == "override_by_you"){
               
                $("#other_popup").find('.modal-body').text("Vous avez déjà réassignée ce prêt"); // You already overide this loan
                $("#other_popup").modal('show');
            }
            else if(result['status'] == '3' && result['condition'] == "overide_to_other"){
                $("#overide_loanid").val(val1);
                $("#overide_popup").find('#confirm_ques').text("Cette demande est déjà réassignée par "+result['user']+". Voulez vous la réassigner encore?"); //Do you want to overide as it is overided by Username?
                $("#overide_popup").modal('show');
            }
            else if(result['status'] == '4' && result['condition'] == "assign_to_me"){
                $("#other_popup").find('.modal-body').text("Cette demande vous est déjà assignée "); //You are already assigned on this loan
                $("#other_popup").modal('show');
            }
            else if(result['status'] == '5' && result['condition'] == "no_one_assigned"){
                $("#other_popup").find('.modal-body').text("Personne n'est affecté à ce prêt"); //No one is assigned to this loan
                $("#other_popup").modal('show');
            }
           
           
             
            
        }
    });
}

function set_assign(val1,val2){
   $.ajax({
        url:"<?php echo base_url()?>PP_Credit_Derogatoire/assign_status",
        type:"POST",
        data:{'loan_id':val1,'status':val2},
        success:function(response){
            
            var result  =  JSON.parse(response);
            console.log(result);
            
            if(result['status'] == '1' && result['condition'] == "assigned_to_you")
            {  $("#other_popup").find('.modal-body').text("Cette demande vous est déjà assignée"); //You are already assigned in this loan
               $("#other_popup").modal('show');
            }
            else if(result['status'] == '2' && result['condition'] == "overide_by_you"){
                $("#other_popup").find('.modal-body').text("Vous avez déjà réassignée ce prêt"); //You already overide this loan
                $("#other_popup").modal('show');
            }
            else if(result['status'] == '3' && result['condition'] == "overide_to_other"){
                $("#other_popup").find('.modal-body').text("This loan is overided by "+result['user']);
                $("#other_popup").modal('show');
            }
            else if(result['status'] == '4'){
                $("#cnfrm_delete").find("a.yes-btn").attr("href","<?php echo base_url()?>PP_Credit_Derogatoire/assignloan_to_user/"+val1);
                $("#cnfrm_delete").modal('show');
               
            }
            else if(result['status'] == '5' && result['condition'] == "assign_by_other"){
                $("#other_popup").find('.modal-body').text("This loan is assigned by "+result['user']);
                $("#other_popup").modal('show');
            }
           
             
            
        }
    }); 
}

function set_attribuer(val){
    $.ajax({
       url:"<?php echo base_url()?>PP_Credit_Derogatoire/assign_attribuer",
       type:"POST",
       data:{'loan_id':val},
       success:function(response){
            var result  =  JSON.parse(response);
            console.log(result);
            
            if(result['status'] == "1"){
                $("#userinfo").html(result['condition']);
                $("#assign_loanid").val(val);
                $("#show_popup").modal('show');
            }
            else if(result['status'] == '2' && result['condition'] == "processed")
            {  $("#other_popup").find('.modal-body').text("Processed By Account Manager");
               $("#other_popup").modal('show');
            }
       }
    });
}


function CheckColors(val){
	var element=document.getElementById('loan_amt');
	 // alert(val);
	 if(val=='noselection'||val=='other'){
	 	element.style.display='block';
	 }else{
	   element.style.display='none';
		$("#loan_amt").val(val);
	}
}

function add_object(val){

	var element=document.getElementById('loan_object');

	$("#loan_object").val(val);

	 if(val=='other'){
	 	element.style.display='block';
	 }else{
	   element.style.display='none';
		
	}
}


function openPage(pageName,elmnt) {
  var i, tabcontent, tablinks;

  //$(".tablink").removeClass('active');
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");

  $(".tablink").removeClass("active");
  //$(""+elmnt).addClass="active";
  elmnt.className = 'tablink active';
  // for (i = 0; i < tablinks.length; i++) {
  //   tablinks[i].style.backgroundColor = "";
  // }
  document.getElementById(pageName).style.display = "block";
  
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>

<script type="text/javascript">
	$("#NewloanForm").validate({
		errorClass: 'has-error',
		rules: {
		     loan_amt_drop: {
				required: true
				
			 },
			 loan_amt: {
				required: true,
				number: true,
				min: 1000,
				max:120000000,
			 },	
			  loan_interest: {
				required: true,
			 },
			 loan_term: {
				 required: true,
				min: 1,
				number: true,
			 },
			
			 tva:{
			 	required : true,
			 	number: true
			 }
				
		},			
		messages: {
			loan_amt: {
				required: "Loan Amount field is required.",
			},	
			loan_amt_drop: {
				required: "Loan Amount field is required.",
			},
		},
		highlight: function(element) {
			$(element).closest('.form-group').addClass('has-error');
		},
		unhighlight: function(element) {

			$(element).closest('.form-group').removeClass('has-error');

		},
		errorElement: 'span',
		errorClass: 'help-block',
		errorPlacement: function(error, element) {
			if(element.parent('.input-group').length) {
				error.insertAfter(element.parent());
			} else {
				error.insertAfter(element);
			}
		},
		submitHandler: function(form) {			
			//alert("chekfe india");
			//$(".sr-only").show();
			var form = $("form");
			$.ajax({
				type:'POST',
				url:'<?php echo base_url("PP_Credit_Derogatoire/add_loan");?>',
				data:$(form).serialize(),
				beforeSend: function(){
					$('.submitBtn').attr("disabled","disabled");
					$('#NewloanForm').css("opacity","0.5");
					$('.outputdata').val("");
					$('.lodergif').css("display","inline");					
				},
				success: function(response) {
					// console.log(response);
					// return false;
					$('.outputdata').val(response);					
					$('#NewloanForm').css("opacity","");
					$('.submitBtn').attr("disabled",false);
					$('.lodergif').css("display","none");
					var resp = JSON.parse(response);
					if(resp.error){
						$('.error-msg').html('<div class="alert alert-danger"><i class="fa fa-times-circle fa-fw fa-lg"></i><strong>Error!</strong>'+$.trim(resp.error)+'.</div>');               			           	
                     }else{
                     	$("#NewloanForm")[0].reset();                     	
                     	$('.error-msg').html('<div class="alert alert-success"><i class="fa fa-check-circle fa-fw fa-lg"></i><strong>Succès!</strong> en place d un prêt.</div>').show();
	                     setTimeout(function() {						
							window.location.href ="<?php echo base_url('PP_Credit_Derogatoire/amortization_loan/');?>"+$.trim(resp.success)+'/3'+"";
						}, 500);						
                 	} 
				}
			});
		  }
	}); 
</script>

<script>
	$(document).ready(function() {	
	    
	   var table =  $('#table-example').DataTable( {
        sDom: 'lTfr<"clearfix">tip',
        processing: true,
        serverSide: true,
         ajax:{  
                url:"<?php echo base_url().'PP_Credit_Derogatoire/fetch_records/first'; ?>",  
                type:"POST",
                cache:false  
           }, 
        fixedHeader: true,
        columnDefs: [ {
        'targets': [10,11], // column index (start from 0)
        'orderable': false, // set orderable false for selected columns
        }],
        oLanguage: {
			  "sSearch": "<span>Recherche:</span> _INPUT_", //search
			   "sLengthMenu": "AFFICHAGE _MENU_ ENREGISTREMENTS",
			  
			},
	
        
    } );
    
// 		var table = $('#table-example').dataTable({
// 			'info': false,
// 			'sDom': 'lTfr<"clearfix">tip',
// 			"oLanguage": {
// 			  "sSearch": "<span>RECHERCHER:</span> _INPUT_", //search
// 			  "sLengthMenu": "AFFICHAGE _MENU_ ENREGISTREMENTS",
// 			},
// 			'oTableTools': {
// 	            'aButtons': [
// 	                {
// 	                    'sExtends':    'collection',
// 	                    'sButtonText': '<i class="fa fa-cloud-download"></i>&nbsp;&nbsp;&nbsp;<i class="fa fa-caret-down"></i>',
// 	                    'aButtons':    [ 'csv', 'xls', 'pdf', 'copy', 'print' ]
// 	                }
// 	            ]
// 	        },	        
// 		});
		
// 	    var tt = new $.fn.dataTable.TableTools( table );
// 		$( tt.fnContainer() ).insertBefore('div.dataTables_wrapper');


	 var table =  $('#table-example1').DataTable( {
        sDom: 'lTfr<"clearfix">tip',
        processing: true,
        serverSide: true,
         ajax:{  
                url:"<?php echo base_url().'PP_Credit_Derogatoire/fetch_records/second'; ?>",  
                type:"POST",
            //   data:{'start_date':$("#start_date").val(),'end_date':$("#end_date").val(),'agence_id':$("#agence_id").val(),'account_manager_id':$("#account_manager_id").val()},
                cache:false  
           }, 
        fixedHeader: true,
        columnDefs: [ {
        'targets': [10,11], // column index (start from 0)
        'orderable': false, // set orderable false for selected columns
        }],
        oLanguage: {
			  "sSearch": "<span>Recherche:</span> _INPUT_", //search
			  "sLengthMenu": "AFFICHAGE _MENU_ ENREGISTREMENTS",
			  
			},
	
        
    } );
		
// 	    var tt1 = new $.fn.dataTable.TableTools( table1 );
// 		$( tt1.fnContainer() ).insertBefore('div.dataTables_wrapper');
		
		var tableFixed = $('#table-example-fixed').dataTable({
			'info': false,
			'pageLength': 50
		});
		
		//new $.fn.dataTable.FixedHeader( tableFixed );
	});

	$('#loan_schedule').change(function() {	    
	    var $option = $(this).find('option:selected');	    
	    var value = $option.val();//to get content of "value" attrib
	    var text = $option.text();//to get <option>Text</option> content
	    $('.addsch').html(text);

	});
    var xmlHttp;
        function srvTime(){
    try {
        //FF, Opera, Safari, Chrome
        xmlHttp = new XMLHttpRequest();
    }
    catch (err1) {
        //IE
        try {
            xmlHttp = new ActiveXObject('Msxml2.XMLHTTP');
        }
        catch (err2) {
            try {
                xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');
            }
            catch (eerr3) {
                //AJAX not supported, use CPU time.
                alert("AJAX not supported");
            }
        }
    }
    xmlHttp.open('HEAD',window.location.href.toString(),false);
    xmlHttp.setRequestHeader("Content-Type", "text/html");
    xmlHttp.send('');
    return xmlHttp.getResponseHeader("Date");
        }
 
        
		function loanDisbursement(event)
	{
	    
	   // var st = srvTime();
	    
	   // alert (st);
		if (confirm('Voulez-vous vraiment le décaissement du prêt?')) {			
			$.ajax({
		            url: '<?php echo base_url("Credit_Derogatoire/confirm_disbursement/credit_dero");?>',
		            type: "POST",
		            data: {
		                'cl_aid':event
		            },
		            beforeSend: function(){
		            	$('#rowid'+event).addClass("lodertypeof");
		            	$(".loader_class"+event).css('display','inline');
		            },
		            success: function (response) {
		                console.log(response);
		                $('.dsprecord').html(response);		                
		                $('#rowid'+event).removeClass("lodertypeof");
		                $(".loader_class"+event).css('display','inline');
		                if($.trim(response)=='success'){
		            		 notificationcall('<span class="icon fa fa-check-circle fa-2x"></span><p>Loan Disbursement successful.</p>','success');
		            		 setTimeout(function() {                
				          		location.reload();
			        		}, 1000);
		            	}else{
		            		notificationcall('<span class="icon fa fa-times-circle fa-2x"></span><p>Error Found</p>','error');
		            	}
		            }
		        });
		}

	}
	function notificationcall(data, status)
  {
      var notification = new NotificationFx({
          message : data,
          layout : 'bar',
          effect : 'slidetop',
          type : status          
        });
          notification.show();
          this.disabled = true;
  }
	</script>

</body>
</html>