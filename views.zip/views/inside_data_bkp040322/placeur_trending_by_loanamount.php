<style type="text/css">
	.hidden { display: none; }

	.lodertypeof {    
    background-color: #dff0d8c7;
    background-image: url("<?php echo base_url('assets/img/select2-spinner.gif');?>");
    background-size: 18px 18px;
    background-position:right center;
    background-repeat: no-repeat;
    opacity: 0.5;
    }
    
    .pending_row{
        background-color: #ededb5;  
    }
    
    .rejected_row{
        background-color: #ff000047;
    }
    
    .approved_row{
        background-color: #8fbc8f8c;
    }
    
    .gen_row{
        background-color: lightblue;
    }
    
    .theader{
        font-size:12px;
        font-weight:600;
    }
</style>
<div id="content-wrapper">
	<div class="row">
		<div class="col-lg-12">

			<div id="content-header" class="clearfix">
				<div class="pull-left">
					<ol class="breadcrumb">
						<li><a href="<?php echo base_url('Dashboard');?>">TABLEAU DE BORD</a></li>
						<li class="active"><span><?php echo "Tendance des Placeurs par Montant du Prêt";//echo $page;?></span></li>
					</ol>
				</div>

			</div>
			<div class="main-box-body clearfix">
            		<div class="row" style="margin-top:10px;">					
					<div class="col-lg-12">
						
						
						<div class="main-box clearfix">

							<header class="main-box-header clearfix">
							    <div class="form-group">
									<form id="" action="<?php echo base_url('Inside_data/trending_placeur/loan_amount')?>" method="POST">

                                        <div class="row" style="margin-top:2%">
                                            
                                            <div class="col-md-4">

    											<label class="col-md-3 control-label">Productivité:</label>
    											
    												<div class="col-md-8">
    											     <input type="radio" name="loan_type" value="credit_conso" <?php if($_POST['loan_type'] == "credit_conso"){ echo "checked";  } else {  if($active_loan['loan_id'] == "1") echo "checked";   }?> > Fêtes à la Carte <br/>
    											    <input type="radio" name="loan_type" value="credit_scolair" <?php if($_POST['loan_type'] == "credit_scolair") {echo "checked";  } else { if($active_loan['loan_id'] == "2") echo "checked";  }?>  > Congés à la Carte <br/>
    											    <input type="radio" name="loan_type" value="credit_confort" <?php if($_POST['loan_type'] == "credit_confort"){ echo "checked";  } else { if($active_loan['loan_id'] == "3") echo "checked";   }?>  > Crédit Confort <br/>
    											    <input type="radio" name="loan_type" value="pp_scolair" <?php if($_POST['loan_type'] == "pp_scolair") {echo "checked"; } else {  if($active_loan['loan_id'] == "4") echo "checked"; }?> > Crédit Scolaire <br/>
    			
    											</div>
											
											</div>
											
											<div class="col-md-5">
										    	<label class="col-md-2 control-label">DATE:</label>

    											<div class="col-md-8">
    											    <input type="radio" name="date_type" value="today" <?php if($_POST['date_type'] == "today") echo "checked"; ?> > Aujourd'hui <br/>
    											    <input type="radio" name="date_type" value="yesterday" <?php if($_POST['date_type'] == "yesterday") echo "checked"; ?> > Hier <br/>
    											    <input type="radio" name="date_type" value="this_week" <?php if($_POST['date_type'] == "this_week") echo "checked"; ?> > Cette semaine <br/>
    											    <input type="radio" name="date_type" value="last_week" <?php if($_POST['date_type'] == "last_week") echo "checked"; ?> > La semaine dernière <br/>
    											    <input type="radio" name="date_type" value="15_days" <?php if($_POST['date_type'] == "15_days") echo "checked"; ?> > 15 derniers jours <br/>
    											    <input type="radio" name="date_type" value="this_month" <?php if($_POST['date_type'] == "this_month") echo "checked"; ?> > Ce mois-ci <br/>
    											    <input type="radio" name="date_type" value="last_month" <?php if($_POST['date_type'] == "last_month") echo "checked"; ?> > Le mois dernier <br/>
    											    <input type="radio" name="date_type" value="custom_range" <?php if($_POST['date_type'] == "custom_range") echo "checked"; ?> > Dates Spècifiques <br/>
    											    <input type="text" class="form-control" name="daterange" value="<?php echo $_POST['daterange'];?>" <?php if($_POST['date_type'] == "custom_range") { ?> style="display:block" <?php } else { ?> style="display:none" <?php } ?>  />
    			
    			
    											</div>
											</div>
											
											<div class="col-md-3">
										    	<button  type ="submit" class="btn btn-primary">Sélectionner</button> &nbsp;
										        <button id="btnExport" class="btn btn-primary" onclick="fnExcelReport('xlsx');"> Exporter </button>&nbsp;
										        <button id="btnPdf" type="button" class="btn btn-primary" onclick="generatePDF();"> PDF </button>
											</div>
										</div>
										
										
										
									</form>
								
								</div>
							 
							</header>

							<div class="main-box-body clearfix">

								<div class="table-responsive">
								   
									<table id="table-example1" class="table table-hover table-striped">
										<thead>
											<tr>
											    <!--Loan Product -->
											    <th>Produit</th>
											    <!--Account Manager Name -->
												<th>Placeur</th>
												<!--Progress -->
												<th>Progression %</th>
												<th>Trend</th>
												<!--Goals -->
												<th>Objectif</th>
											</tr>
										</thead>
										<tbody id="getrecord">
										    <?php if(!empty($result)){
										        foreach($result as $res){
										    ?>
										    <tr>
										        <td><?php echo $type; ?></td>
										        <td><?php echo $res['user']; ?></td>
										        <td><?php echo $res['progress'] ? number_format($res['progress'], 2).'%' : 0; 
										          //echo  $res['loan_amount'];
										        ?></td>
										         <?php if($res['progress'] >= 90) echo "<td style='background-color:green'></td>";?>
										        <?php if($res['progress'] >= 80 && $res['progress'] < 90) echo "<td style='background-color:yellow'></td>";?>
										        <?php if($res['progress'] >= 70 && $res['progress'] < 80) echo "<td style='background-color:orange'></td>";?>
										        <?php if($res['progress'] < 60) echo "<td style='background-color:red'></td>";?>
										        <td><?php echo number_format($res['goals'],0,',',',');
										        ?></td>
										    </tr>
										    <?php } } ?>
										</tbody>
									</table>
									
									
									<table id="table-example" class="table table-hover table-striped" style="display:none;">
										<thead>
											<tr>
											    <!--Loan Product -->
											    <th>Produit</th>
											    <!--Account Manager Name -->
												<th>Placeur</th>
												<!--Progress -->
												<th>Progression %</th>
												<th>Trend</th>
												<!--Goals -->
												<th>Objectif</th>
											</tr>
										</thead>
										<tbody id="getrecord">
										    <?php if(!empty($result)){
										        foreach($result as $res){
										    ?>
										    <tr>
										        <td><?php echo $type; ?></td>
										        <td><?php echo $res['user']; ?></td>
										        <td><?php echo $res['progress'] ? number_format($res['progress'], 2).'%' : 0; 
										          //echo  $res['loan_amount'];
										        ?></td>
										         <?php if($res['progress'] >= 90) echo "<td style='background-color:green'></td>";?>
										        <?php if($res['progress'] >= 80 && $res['progress'] < 90) echo "<td style='background-color:yellow'></td>";?>
										        <?php if($res['progress'] >= 70 && $res['progress'] < 80) echo "<td style='background-color:orange'></td>";?>
										        <?php if($res['progress'] < 60) echo "<td style='background-color:red'></td>";?>
										        <td><?php echo number_format($res['goals'],0,',',',');
										        ?></td>
										    </tr>
										    <?php } } ?>
										</tbody>
									</table>
								</div>

							</div>
						</div>
					</div>
				</div>
			</div>			
		</div>
	</div>
	
</div>

</div>
</div>
</div>

<?php echo $report_footer;?>

<script type="text/javascript">


	$('input[name="date_type"]').change(function(){
 	    
 	    if($(this).val() == "custom_range"){
 	        $('input[name="daterange"]').show();
 	    }
 	    else{
 	        $('input[name="daterange"]').hide();
 	    }
 	    
 	    $('input[name="daterange"]').val('');
 	    
 	});
	
	
	$(function() {

  $('input[name="daterange"]').daterangepicker({
      autoUpdateInput: false,
      locale: {
          format: 'YYYY/M/DD',
          cancelLabel: 'Clear'
      }
  });

  $('input[name="daterange"]').on('apply.daterangepicker', function(ev, picker) {
      $(this).val(picker.startDate.format('YYYY/M/DD') + ' - ' + picker.endDate.format('YYYY/M/DD'));
  });

  $('input[name="daterange"]').on('cancel.daterangepicker', function(ev, picker) {
      $(this).val('');
  });
  
  <?php if(!$_POST['daterange']) { ?>
   $('input[name="daterange"]').val('');
  <?php } ?>

});
	

	
function generatePDF() {
    
     var doc = new jsPDF('p', 'pt', 'letter');  
    var htmlstring = '';  
    var tempVarToCheckPageHeight = 0;  
    var pageHeight = 0;  
    pageHeight = doc.internal.pageSize.height;  
    specialElementHandlers = {  
        // element with id of "bypass" - jQuery style selector  
        '#bypassme': function(element, renderer) {  
            // true = "handled elsewhere, bypass text extraction"  
            return true  
        }  
    };  
    margins = {  
        top: 150,  
        bottom: 60,  
        left: 40,  
        right: 40,  
        width: 600  
    };  
    var y = 20;  
    doc.setLineWidth(2);  
    doc.text(200, y = y + 30, "Placeur Trending by Loan Amount");  
    doc.autoTable({  
        html: '#table-example',  
        startY: 70,  
        theme: 'grid',  
        // columnStyles: {  
        //     0: {  
        //         cellWidth: 180,  
        //     },  
        //     1: {  
        //         cellWidth: 180,  
        //     },  
        //     2: {  
        //         cellWidth: 180,  
        //     }  
        // },  
        // styles: {  
        //     minCellHeight: 40  
        // }  
    })  
    doc.save('Placeur_Trending_by_LoanAmount.pdf');  


//  var doc = new jsPDF();
//   doc.fromHTML(document.getElementById("table-example"), // page element which you want to print as PDF
//   15,
//   15, 
//   {
//     'width': 170
//   },
//   function(a) 
//   {
//     doc.save("HTML2PDF.pdf");
//   });
}

Highcharts.setOptions({
    colors: Highcharts.map(Highcharts.getOptions().colors, function (color) {
        return {
            radialGradient: {
                cx: 0.5,
                cy: 0.3,
                r: 0.7
            },
            stops: [
                [0, color],
                [1, Highcharts.color(color).brighten(-0.3).get('rgb')] // darken
            ]
        };
    })
});


// Highcharts.chart('container', {
//     chart: {
//         plotBackgroundColor: null,
//         plotBorderWidth: null,
//         plotShadow: false,
//         type: 'pie'
//     },
//     title: {
//         text: 'Status Overview'
//     },
//     tooltip: {
//         pointFormat: '{series.name}: <b>{point.y}</b>'
//     },
//     accessibility: {
//         point: {
//             valueSuffix: '%'
//         }
//     },
//     plotOptions: {
//         pie: {
//             allowPointSelect: true,
//             cursor: 'pointer',
//             dataLabels: {
//                 enabled: true,
//                 format: '<b>{point.name}</b>: {point.y}',
//                 connectorColor: 'silver'
//             }
//         }
//     },
//     series: [{
//         name: 'Count',
//         data:<?php echo $pie_data; ?>
//     }]
// });


$( document ).ready(function() {
    $(".highcharts-credits").css('display','none');


});

	


	

	// show popup notification 

   function notificationcall(data, status)
  {
      var notification = new NotificationFx({
          message : data,
          layout : 'bar',
          effect : 'slidetop',
          type : status          
        });
          notification.show();
          this.disabled = true;
  }
</script>

<script>
function fnExcelReport(type, fn, dl)
{
      var elt = document.getElementById('table-example');
    var wb = XLSX.utils.table_to_book(elt, { sheet: "Placeur Trending by Loan Amount" });
    return dl ?
        XLSX.write(wb, { bookType: type, bookSST: true, type: 'base64' }) :
        XLSX.writeFile(wb, fn || ('Placeur_Trending_by_LoanAmount.' + (type || 'xlsx')));

}
$(window).load(function(){
    // alert('table');
		var table = $('#table-example1').dataTable({
			'info': false,
			'sDom': 'lTfr<"clearfix">tip',
			"oLanguage": {
			  "sSearch": "<span>RECHERCHER:</span> _INPUT_", //search
			 // "sLengthMenu": "AFFICHAGE _MENU_ ENREGISTREMENTS",
			},
		
		});		
		
	    var tt = new $.fn.dataTable.TableTools( table );
		$( tt.fnContainer() ).insertBefore('div.dataTables_wrapper');		
		var tableFixed = $('#table-example-fixed').dataTable({
			'info': false,
			'pageLength': 50
		});	
});

	$('#loan_schedule').change(function() {	    
	    var $option = $(this).find('option:selected');	    
	    var value = $option.val();//to get content of "value" attrib
	    var text = $option.text();//to get <option>Text</option> content
	    $('.addsch').html(text);

	});
	</script>

</body>
</html>