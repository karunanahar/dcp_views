<!doctype html>
<html lang="en" dir="ltr">
	<head>

		<!-- BOOTSTRAP CSS -->
		<link href="<?php echo base_url('assets/volgh/assets/plugins/bootstrap/css/bootstrap.min.css');?>" rel="stylesheet" />

		<!-- STYLE CSS -->
		<link href="<?php echo base_url('assets/volgh/assets/css/style.css');?>" rel="stylesheet"/>
		<link href="<?php echo base_url('assets/volgh/assets/css/skin-modes.css');?>" rel="stylesheet"/>
		<link href="<?php echo base_url('assets/volgh/assets/css/dark-style.css');?>" rel="stylesheet"/>

		<!--C3.JS CHARTS PLUGIN -->
		<link href="<?php echo base_url('assets/volgh/assets/plugins/charts-c3/c3-chart.css');?>" rel="stylesheet"/>

		<!--PERFECT SCROLL CSS-->
		<link href="<?php echo base_url('assets/volgh/assets/plugins/p-scroll/perfect-scrollbar.css');?>" rel="stylesheet"/>

		<!--- FONT-ICONS CSS -->
		<link href="<?php echo base_url('assets/volgh/assets/css/icons.css');?>" rel="stylesheet"/>

		<!-- SIDEBAR CSS -->
		<!--<link href="<?php echo base_url('assets/volgh/assets/plugins/sidebar/sidebar.css');?>" rel="stylesheet">-->

		<!-- COLOR SKIN CSS -->
		<link id="theme" rel="stylesheet" type="text/css" media="all" href="<?php echo base_url('assets/volgh/assets/colors/color1.css');?>" />
<style>
.container {
    
    max-width: 1920px !important;
    
}

</style>
	</head>

	<body>

		<!-- PAGE -->
		<div class="page">
			<div class="page-main">

                <!--app-content open-->
				<div class="container app-content">
					<div class="">

						<!-- PAGE-HEADER -->
						<div class="page-header">
							<div>
								<h1 class="page-title">KPIs</h1>
								
							</div>
							
						</div>

						<div class="page-header">
							<div class="panel panel-primary">
											<div class=" tab-menu-heading">
												<div class="tabs-menu1 ">
													<!-- Tabs -->
													<ul class="nav panel-tabs">
														<li ><a href="#tab5" class="active" data-toggle="tab">Conge a la carte</a></li>
														<li><a href="#tab6" data-toggle="tab">Credit Express</a></li>
														<li><a href="#tab7" data-toggle="tab">Credit Sans Guarantie</a></li>
														
													</ul>
												</div>
											</div>
											<div class="panel-body tabs-menu-body">
												<div class="tab-content">
													<div class="tab-pane active " id="tab5">
														<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xl-6">
								<div class="row">
									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">
										<div class="card">
											<div class="card-body text-center statistics-info">
												<div class="counter-icon bg-primary mb-0 box-primary-shadow">
													<i class="fe fe-trending-up text-white"></i>
												</div>
												<h6 class="mt-4 mb-1">Total Number of disbursed loans</h6>
												<h2 class="mb-2 number-font">34,516</h2>
													<div class="card-body ">
												
													<div class="progress progress-sm mt-0 mb-2">
														<div class="progress-bar bg-success w-50" role="progressbar"></div>
													</div>
														<div class=""><i class="fa fa-caret-down text-danger"></i>5% decrease</div>
													</div>
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">
										<div class="card">
											<div class="card-body text-center statistics-info">
												<div class="counter-icon bg-secondary mb-0 box-secondary-shadow">
													<i class="fe fe-codepen text-white"></i>
												</div>
												<h6 class="mt-4 mb-1">Total Amount of disbursed loans</h6>
												<h2 class="mb-2 number-font">$56,992</h2>
												<div class="card-body ">
												
													<div class="progress progress-sm mt-0 mb-2">
														<div class="progress-bar bg-success w-50" role="progressbar"></div>
													</div>
														<div class=""><i class="fa fa-caret-down text-danger"></i>5% decrease</div>
													</div>
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">
										<div class="card">
											<div class="card-body text-center statistics-info">
												<div class="counter-icon bg-success mb-0 box-success-shadow">
													<i class="fe fe-dollar-sign text-white"></i>
												</div>
												<h6 class="mt-4 mb-1">Total number of Active Loans</h6>
												<h2 class="mb-2  number-font">567</h2>
												
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">
										<div class="card">
											<div class="card-body text-center statistics-info">
												<div class="counter-icon bg-info mb-0 box-info-shadow">
													<i class="fe fe-briefcase text-white"></i>
												</div>
												<h6 class="mt-4 mb-1"> Total Amount of Active Loans</h6>
												<h2 class="mb-2  number-font">$34,789</h2>
												
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-6">
								<div class="card">
									<div class="card-header">
										<h3 class="card-title">Loan Trends</h3>
									</div>
									<div class="card-body">
										<div id="echart1" class="chart-donut chart-dropshadow"></div>
										<div class="mt-4">
											<span class="ml-5"><span class="dot-label bg-info mr-2"></span>Actives</span>
											<span class="ml-5"><span class="dot-label bg-secondary mr-2"></span>Approved</span>
											<span class="ml-5"><span class="dot-label bg-success mr-2"></span>In Process</span>
											<span class="ml-5"><span class="dot-label bg-danger mr-1"></span>Annule/Abondon</span>
										</div>
									</div>
								</div>
							</div><!-- COL END -->
						</div>

						<div class="row">
							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-dollar text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2">Average Loan Request Amount</h6>
										<h2 class="mb-2  number-font">$34,516</h2>
										<p class="text-muted">Sed ut perspiciatis unde omnis accusantium doloremque</p>
									</div>
								</div>
							</div><!-- COL END -->

							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-globe text-primary fa-3x text-primary-shadow"></i>
										<h6 class="mt-4 mb-2">Average Days to Mise a Disposition</h6>
										<h2 class="mb-2 number-font">834</h2>
										<p class="text-muted">Sed ut perspiciatis unde omnis accusantium doloremque</p>
									</div>
								</div>
							</div><!-- COL END -->
							
							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-globe text-primary fa-3x text-primary-shadow"></i>
										<h6 class="mt-4 mb-2">Productivity Efficiency</h6>
										<h2 class="mb-2 number-font">834</h2>
										<p class="text-muted">Sed ut perspiciatis unde omnis accusantium doloremque</p>
									</div>
								</div>
							</div><!-- COL END -->
							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-dollar text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2">Loan Approved  V.s Tokos</h6>
										<h2 class="mb-2  number-font">$34,516</h2>
										<p class="text-muted">Sed ut perspiciatis unde omnis accusantium doloremque</p>
									</div>
								</div>
							</div><!-- COL END -->
						</div>

						<div class="row">
							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
								<div class="card">
									<div class="card-header">
										<h3 class="card-title">Top 5 branches by loan numbers</h3>
									</div>
									<div class="card-body p-4">
										<div class="mb-5">
											<p class="mb-2">Bureau ADL<span class="float-right text-muted">80</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-primary w-80 " role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Université<span class="float-right text-muted">70</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-pink w-70" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Okala<span class="float-right text-muted">80</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-warning w-65" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Prima<span class="float-right text-muted">80</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-danger w-80" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Mouila<span class="float-right text-muted">70</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-success w-60" role="progressbar"></div>
											</div>
										</div>
										
									</div>
								</div>
							</div><!-- COL END -->
							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
								<div class="card">
									<div class="card-header">
										<h3 class="card-title">Top 5 branches by loan amount</h3>
									</div>
									<div class="card-body p-4">
										<div class="mb-5">
											<p class="mb-2">RR<span class="float-right text-muted">80000</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-primary w-80 " role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Prima<span class="float-right text-muted">700002</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-pink w-70" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Bureau ADL<span class="float-right text-muted">802666</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-warning w-65" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Devenir<span class="float-right text-muted">80856</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-danger w-80" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Bureau ADL<span class="float-right text-muted">7077888</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-success w-60" role="progressbar"></div>
											</div>
										</div>
										
									</div>
								</div>
							</div><!-- COL END -->
							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
								<div class="card">
									<div class="card-header">
										<h3 class="card-title">Top 5 branches with less Aging loan numbers (> 3 days)</h3>
									</div>
									<div class="card-body p-4">
										<div class="mb-5">
											<p class="mb-2">Moanda<span class="float-right text-muted">8</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-primary w-80 " role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Louis<span class="float-right text-muted">7</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-pink w-70" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Mont Bouet<span class="float-right text-muted">8</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-warning w-65" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Bureau ADL<span class="float-right text-muted">8</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-danger w-80" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Devenir<span class="float-right text-muted">7</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-success w-60" role="progressbar"></div>
											</div>
										</div>
										
									</div>
								</div>
							</div><!-- COL END -->

						</div>
						<div class="row">
							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
								<div class="card">
									<div class="card-header">
										<h3 class="card-title">Top 5 branches against total loan number GOALS</h3>
									</div>
									<div class="card-body p-4">
										<div class="mb-5">
											<p class="mb-2">Bureau ADL<span class="float-right text-muted">80%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-primary w-80 " role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Université<span class="float-right text-muted">70%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-pink w-70" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Okala<span class="float-right text-muted">80%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-warning w-65" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Prima<span class="float-right text-muted">80%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-danger w-80" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Mouila<span class="float-right text-muted">70%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-success w-60" role="progressbar"></div>
											</div>
										</div>
										
									</div>
								</div>
							</div><!-- COL END -->
							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
								<div class="card">
									<div class="card-header">
										<h3 class="card-title">Top 5 branches Against total loan amount GOALS</h3>
									</div>
									<div class="card-body p-4">
										<div class="mb-5">
											<p class="mb-2">RR<span class="float-right text-muted">80%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-primary w-80 " role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Prima<span class="float-right text-muted">70%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-pink w-70" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Bureau ADL<span class="float-right text-muted">80%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-warning w-65" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Devenir<span class="float-right text-muted">80%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-danger w-80" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Bureau ADL<span class="float-right text-muted">70%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-success w-60" role="progressbar"></div>
											</div>
										</div>
										
									</div>
								</div>
							</div><!-- COL END -->
							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
								<div class="card">
									<div class="card-header">
										<h3 class="card-title">Top 5 Placeurs against total loan number GOALS</h3>
									</div>
									<div class="card-body p-4">
										<div class="mb-5">
											<p class="mb-2">Moanda<span class="float-right text-muted">80%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-primary w-80 " role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Louis<span class="float-right text-muted">70%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-pink w-70" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Mont Bouet<span class="float-right text-muted">80%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-warning w-65" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Bureau ADL<span class="float-right text-muted">80%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-danger w-80" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Devenir<span class="float-right text-muted">70%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-success w-60" role="progressbar"></div>
											</div>
										</div>
										
									</div>
								</div>
							</div><!-- COL END -->

						</div>

						<div class="row">
							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
								<div class="card">
									<div class="card-header">
										<h3 class="card-title">LAST 5 branches by loan numbers</h3>
									</div>
									<div class="card-body p-4">
										<div class="mb-5">
											<p class="mb-2">Bureau ADL<span class="float-right text-muted">225</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-primary w-80 " role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Université<span class="float-right text-muted">1255</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-pink w-70" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Okala<span class="float-right text-muted">8566</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-warning w-65" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Prima<span class="float-right text-muted">856</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-danger w-80" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Mouila<span class="float-right text-muted">7654</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-success w-60" role="progressbar"></div>
											</div>
										</div>
										
									</div>
								</div>
							</div><!-- COL END -->
							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
								<div class="card">
									<div class="card-header">
										<h3 class="card-title">LAST 5 branches by loan amount</h3>
									</div>
									<div class="card-body p-4">
										<div class="mb-5">
											<p class="mb-2">RR<span class="float-right text-muted">80745</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-primary w-80 " role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Prima<span class="float-right text-muted">56656</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-pink w-70" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Bureau ADL<span class="float-right text-muted">85665</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-warning w-65" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Devenir<span class="float-right text-muted">85545</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-danger w-80" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Bureau ADL<span class="float-right text-muted">70545</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-success w-60" role="progressbar"></div>
											</div>
										</div>
										
									</div>
								</div>
							</div><!-- COL END -->
							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
								<div class="card">
									<div class="card-header">
										<h3 class="card-title">Top 5 branches with AGING loan numbers</h3>
									</div>
									<div class="card-body p-4">
										<div class="mb-5">
											<p class="mb-2">Moanda<span class="float-right text-muted">80</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-primary w-80 " role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Louis<span class="float-right text-muted">70</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-pink w-70" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Mont Bouet<span class="float-right text-muted">80</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-warning w-65" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Bureau ADL<span class="float-right text-muted">80</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-danger w-80" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Devenir<span class="float-right text-muted">70</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-success w-60" role="progressbar"></div>
											</div>
										</div>
										
									</div>
								</div>
							</div><!-- COL END -->

						</div>

						<div class="row">
							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
								<div class="card">
									<div class="card-header">
										<h3 class="card-title">LAST 5 branches against loan number GOALS</h3>
									</div>
									<div class="card-body p-4">
										<div class="mb-5">
											<p class="mb-2">Bureau ADL<span class="float-right text-muted">80%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-primary w-80 " role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Université<span class="float-right text-muted">70%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-pink w-70" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Okala<span class="float-right text-muted">80%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-warning w-65" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Prima<span class="float-right text-muted">80%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-danger w-80" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Mouila<span class="float-right text-muted">70%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-success w-60" role="progressbar"></div>
											</div>
										</div>
										
									</div>
								</div>
							</div><!-- COL END -->
							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
								<div class="card">
									<div class="card-header">
										<h3 class="card-title">LAST 5 branches against total loan amount GOALS</h3>
									</div>
									<div class="card-body p-4">
										<div class="mb-5">
											<p class="mb-2">RR<span class="float-right text-muted">80%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-primary w-80 " role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Prima<span class="float-right text-muted">70%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-pink w-70" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Bureau ADL<span class="float-right text-muted">80%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-warning w-65" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Devenir<span class="float-right text-muted">80%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-danger w-80" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Bureau ADL<span class="float-right text-muted">70%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-success w-60" role="progressbar"></div>
											</div>
										</div>
										
									</div>
								</div>
							</div><!-- COL END -->
							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
								<div class="card">
									<div class="card-header">
										<h3 class="card-title">LAST 5 Placeurs against total loan number GOALSs</h3>
									</div>
									<div class="card-body p-4">
										<div class="mb-5">
											<p class="mb-2">Moanda<span class="float-right text-muted">80%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-primary w-80 " role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Louis<span class="float-right text-muted">70%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-pink w-70" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Mont Bouet<span class="float-right text-muted">80%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-warning w-65" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Bureau ADL<span class="float-right text-muted">80%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-danger w-80" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Devenir<span class="float-right text-muted">70%</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-success w-60" role="progressbar"></div>
											</div>
										</div>
										
									</div>
								</div>
							</div><!-- COL END -->

						</div>

						<div class="row">
							

							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-globe text-primary fa-3x text-primary-shadow"></i>
										<h6 class="mt-4 mb-2">Total Number of Loan Annule</h6>
										<h2 class="mb-2 number-font">834</h2>
										<p class="text-muted">Sed ut perspiciatis unde omnis accusantium doloremque</p>
									</div>
								</div>
							</div><!-- COL END -->

							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-dollar text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2">Total Amount of Loan Annule</h6>
										<h2 class="mb-2  number-font">$34,516</h2>
										<p class="text-muted">Sed ut perspiciatis unde omnis accusantium doloremque</p>
									</div>
								</div>
							</div><!-- COL END -->
							
							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-globe text-primary fa-3x text-primary-shadow"></i>
										<h6 class="mt-4 mb-2">Total Number of Loan Abondonne</h6>
										<h2 class="mb-2 number-font">834</h2>
										<p class="text-muted">Sed ut perspiciatis unde omnis accusantium doloremque</p>
									</div>
								</div>
							</div><!-- COL END -->
							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-dollar text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2">Total Amount of Loan Abondonne</h6>
										<h2 class="mb-2  number-font">$34,516</h2>
										<p class="text-muted">Sed ut perspiciatis unde omnis accusantium doloremque</p>
									</div>
								</div>
							</div><!-- COL END -->
						</div>

						<div class="row">
							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-3">
								<div class="card">
									<div class="card-header">
										<h3 class="card-title">Top 5 branches  by total number of loan Annule</h3>
									</div>
									<div class="card-body p-4">
										<div class="mb-5">
											<p class="mb-2">Bureau ADL<span class="float-right text-muted">80</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-primary w-80 " role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Université<span class="float-right text-muted">70</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-pink w-70" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Okala<span class="float-right text-muted">80</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-warning w-65" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Prima<span class="float-right text-muted">80</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-danger w-80" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Mouila<span class="float-right text-muted">70</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-success w-60" role="progressbar"></div>
											</div>
										</div>
										
									</div>
								</div>
							</div><!-- COL END -->
							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-3">
								<div class="card">
									<div class="card-header">
										<h3 class="card-title">Top 5 branches  by total amount of loan Annule</h3>
									</div>
									<div class="card-body p-4">
										<div class="mb-5">
											<p class="mb-2">RR<span class="float-right text-muted">705446546</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-primary w-80 " role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Prima<span class="float-right text-muted">705446546</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-pink w-70" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Bureau ADL<span class="float-right text-muted">705446546</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-warning w-65" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Devenir<span class="float-right text-muted">705446546</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-danger w-80" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Bureau ADL<span class="float-right text-muted">705446546</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-success w-60" role="progressbar"></div>
											</div>
										</div>
										
									</div>
								</div>
							</div><!-- COL END -->
							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-3">
								<div class="card">
									<div class="card-header">
										<h3 class="card-title">Top 5 branches  by total number of loan Abandonne</h3>
									</div>
									<div class="card-body p-4">
										<div class="mb-5">
											<p class="mb-2">Moanda<span class="float-right text-muted">5</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-primary w-80 " role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Louis<span class="float-right text-muted">4</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-pink w-70" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Mont Bouet<span class="float-right text-muted">6</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-warning w-65" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Bureau ADL<span class="float-right text-muted">5</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-danger w-80" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Devenir<span class="float-right text-muted">8</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-success w-60" role="progressbar"></div>
											</div>
										</div>
										
									</div>
								</div>
							</div><!-- COL END -->
							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-3">
								<div class="card">
									<div class="card-header">
										<h3 class="card-title">Top 5 branches  by total amount of loan Abondonne</h3>
									</div>
									<div class="card-body p-4">
										<div class="mb-5">
											<p class="mb-2">Moanda<span class="float-right text-muted">8056</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-primary w-80 " role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Louis<span class="float-right text-muted">704654</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-pink w-70" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Mont Bouet<span class="float-right text-muted">80654</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-warning w-65" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Bureau ADL<span class="float-right text-muted">80654</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-danger w-80" role="progressbar"></div>
											</div>
										</div>
										<div class="mb-5">
											<p class="mb-2">Devenir<span class="float-right text-muted">706456</span></p>
											<div class="progress h-2">
												<div class="progress-bar bg-success w-60" role="progressbar"></div>
											</div>
										</div>
										
									</div>
								</div>
							</div><!-- COL END -->

						</div>
													</div>
													<div class="tab-pane " id="tab6">
														<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xl-6">
								<div class="row">
									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">
										<div class="card">
											<div class="card-body text-center statistics-info">
												<div class="counter-icon bg-primary mb-0 box-primary-shadow">
													<i class="fe fe-trending-up text-white"></i>
												</div>
												<h6 class="mt-4 mb-1">Total Number of disbursed loans</h6>
												<h2 class="mb-2 number-font">34,516</h2>
													<div class="card-body ">
												
													<div class="progress progress-sm mt-0 mb-2">
														<div class="progress-bar bg-success w-50" role="progressbar"></div>
													</div>
														<div class=""><i class="fa fa-caret-down text-danger"></i>5% decrease</div>
													</div>
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">
										<div class="card">
											<div class="card-body text-center statistics-info">
												<div class="counter-icon bg-secondary mb-0 box-secondary-shadow">
													<i class="fe fe-codepen text-white"></i>
												</div>
												<h6 class="mt-4 mb-1">Total Amount of disbursed loans</h6>
												<h2 class="mb-2 number-font">$56,992</h2>
												<div class="card-body ">
												
													<div class="progress progress-sm mt-0 mb-2">
														<div class="progress-bar bg-success w-50" role="progressbar"></div>
													</div>
														<div class=""><i class="fa fa-caret-down text-danger"></i>5% decrease</div>
													</div>
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">
										<div class="card">
											<div class="card-body text-center statistics-info">
												<div class="counter-icon bg-success mb-0 box-success-shadow">
													<i class="fe fe-dollar-sign text-white"></i>
												</div>
												<h6 class="mt-4 mb-1">Total number of Active Loans</h6>
												<h2 class="mb-2  number-font">567</h2>
												
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">
										<div class="card">
											<div class="card-body text-center statistics-info">
												<div class="counter-icon bg-info mb-0 box-info-shadow">
													<i class="fe fe-briefcase text-white"></i>
												</div>
												<h6 class="mt-4 mb-1"> Total Amount of Active Loans</h6>
												<h2 class="mb-2  number-font">$34,789</h2>
												
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-6">
								<div class="card">
									<div class="card-header">
										<h3 class="card-title">Loan Trends</h3>
									</div>
									<div class="card-body">
										<div id="echart1" class="chart-donut chart-dropshadow"></div>
										<div class="mt-4">
											<span class="ml-5"><span class="dot-label bg-info mr-2"></span>Actives</span>
											<span class="ml-5"><span class="dot-label bg-secondary mr-2"></span>Approved</span>
											<span class="ml-5"><span class="dot-label bg-success mr-2"></span>In Process</span>
											<span class="ml-5"><span class="dot-label bg-danger mr-1"></span>Annule/Abondon</span>
										</div>
									</div>
								</div>
							</div><!-- COL END -->
						</div>
													</div>
													<div class="tab-pane " id="tab7">
														<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xl-6">
								<div class="row">
									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">
										<div class="card">
											<div class="card-body text-center statistics-info">
												<div class="counter-icon bg-primary mb-0 box-primary-shadow">
													<i class="fe fe-trending-up text-white"></i>
												</div>
												<h6 class="mt-4 mb-1">Total Number of disbursed loans</h6>
												<h2 class="mb-2 number-font">34,516</h2>
													<div class="card-body ">
												
													<div class="progress progress-sm mt-0 mb-2">
														<div class="progress-bar bg-success w-50" role="progressbar"></div>
													</div>
														<div class=""><i class="fa fa-caret-down text-danger"></i>5% decrease</div>
													</div>
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">
										<div class="card">
											<div class="card-body text-center statistics-info">
												<div class="counter-icon bg-secondary mb-0 box-secondary-shadow">
													<i class="fe fe-codepen text-white"></i>
												</div>
												<h6 class="mt-4 mb-1">Total Amount of disbursed loans</h6>
												<h2 class="mb-2 number-font">$56,992</h2>
												<div class="card-body ">
												
													<div class="progress progress-sm mt-0 mb-2">
														<div class="progress-bar bg-success w-50" role="progressbar"></div>
													</div>
														<div class=""><i class="fa fa-caret-down text-danger"></i>5% decrease</div>
													</div>
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">
										<div class="card">
											<div class="card-body text-center statistics-info">
												<div class="counter-icon bg-success mb-0 box-success-shadow">
													<i class="fe fe-dollar-sign text-white"></i>
												</div>
												<h6 class="mt-4 mb-1">Total number of Active Loans</h6>
												<h2 class="mb-2  number-font">567</h2>
												
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">
										<div class="card">
											<div class="card-body text-center statistics-info">
												<div class="counter-icon bg-info mb-0 box-info-shadow">
													<i class="fe fe-briefcase text-white"></i>
												</div>
												<h6 class="mt-4 mb-1"> Total Amount of Active Loans</h6>
												<h2 class="mb-2  number-font">$34,789</h2>
												
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-6">
								<div class="card">
									<div class="card-header">
										<h3 class="card-title">Loan Trends</h3>
									</div>
									<div class="card-body">
										<div id="echart1" class="chart-donut chart-dropshadow"></div>
										<div class="mt-4">
											<span class="ml-5"><span class="dot-label bg-info mr-2"></span>Actives</span>
											<span class="ml-5"><span class="dot-label bg-secondary mr-2"></span>Approved</span>
											<span class="ml-5"><span class="dot-label bg-success mr-2"></span>In Process</span>
											<span class="ml-5"><span class="dot-label bg-danger mr-1"></span>Annule/Abondon</span>
										</div>
									</div>
								</div>
							</div><!-- COL END -->
						</div>
													</div>
													
												</div>
											</div>
										</div>
							
						</div>
						<!-- PAGE-HEADER END -->

						<!-- ROW-1 -->
						
						<!-- ROW-1 END -->


					</div>
				</div>
				<!-- CONTAINER END -->
            </div>


		</div>



		<!-- JQUERY JS -->
		<script src="<?php echo base_url('assets/volgh/assets/js/jquery-3.4.1.min.js');?>"></script>

		<!-- BOOTSTRAP JS -->
		<script src="<?php echo base_url('assets/volgh/assets/plugins/bootstrap/js/bootstrap.bundle.min.js');?>"></script>
		<script src="<?php echo base_url('assets/volgh/assets/plugins/bootstrap/js/popper.min.js');?>"></script>

		<!-- SPARKLINE JS-->
		<script src="<?php echo base_url('assets/volgh/assets/js/jquery.sparkline.min.js');?>"></script>

		<!-- CHART-CIRCLE JS-->
		<script src="../../assets/js/circle-progress.min.js"></script>

		<!-- RATING STARJS -->
		<script src="<?php echo base_url('assets/volgh/assets/plugins/rating/jquery.rating-stars.js');?>"></script>

		<!-- CHARTJS CHART JS-->
		<script src="<?php echo base_url('assets/volgh/assets/plugins/chart/Chart.bundle.js');?>"></script>
		<script src="<?php echo base_url('assets/volgh/assets/plugins/chart/utils.js');?>"></script>

		<!-- PIETY CHART JS-->
		<script src="<?php echo base_url('assets/volgh/assets/plugins/peitychart/jquery.peity.min.js');?>"></script>
		<script src="<?php echo base_url('assets/volgh/assets/plugins/peitychart/peitychart.init.js');?>"></script>

		<!-- ECHART JS-->
		<script src="<?php echo base_url('assets/volgh/assets/plugins/echarts/echarts.js');?>"></script>

		<!--HORIZONTAL JS-->
		<script src="<?php echo base_url('assets/volgh/assets/plugins/horizontal-menu/horizontal-menu.js');?>"></script>

		<!-- Perfect SCROLLBAR JS-->
		<script src="<?php echo base_url('assets/volgh/assets/plugins/p-scroll/perfect-scrollbar.js');?>"></script>
		<script src="<?php echo base_url('assets/volgh/assets/plugins/p-scroll/pscroll-1.js');?>"></script>

		<!-- STICKY JS -->
		<script src="<?php echo base_url('assets/volgh/assets/js/stiky.js');?>"></script>

		<!-- APEXCHART JS -->
		<script src="<?php echo base_url('assets/volgh/assets/js/apexcharts.js');?>"></script>

		<!-- SIDEBAR JS -->
		<script src="<?php echo base_url('assets/volgh/assets//plugins/sidebar/sidebar.js');?>"></script>

		<!-- INDEX JS -->
		<script src="<?php echo base_url('assets/volgh/assets/js/index1.js');?>"></script>

		<!-- CUSTOM JS -->
       <script src="<?php echo base_url('assets/volgh/assets/js/custom.js');?>"></script>

	</body>
</html>