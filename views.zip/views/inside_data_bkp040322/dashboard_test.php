	<head>



		<!-- STYLE CSS -->
		<link href="<?php  echo base_url('assets/volgh/assets/css/style.css');?>" rel="stylesheet"/>


		<!--C3.JS CHARTS PLUGIN -->
		<link href="<?php echo base_url('assets/volgh/assets/plugins/charts-c3/c3-chart.css');?>" rel="stylesheet"/>

		<!--PERFECT SCROLL CSS-->
		<link href="<?php echo base_url('assets/volgh/assets/plugins/p-scroll/perfect-scrollbar.css');?>" rel="stylesheet"/>

		<!--- FONT-ICONS CSS -->
		<link href="<?php echo base_url('assets/volgh/assets/css/icons.css');?>" rel="stylesheet"/>


		<!-- COLOR SKIN CSS -->
		<link id="theme" rel="stylesheet" type="text/css" media="all" href="<?php echo base_url('assets/volgh/assets/colors/color1.css');?>" />

	</head>
<style>

.container {
    
    max-width: 1920px !important;
    
}


.navbar>.container {
    
    display: block;
}
element.style {
}
.navbar>.container, .navbar>.container-fluid {
    display: -ms-flexbox;
    /* display: flex; */
    -ms-flex-wrap: wrap;
    /* flex-wrap: wrap; */
    -ms-flex-align: center;
    /* align-items: center; */
    -ms-flex-pack: justify;
    /* justify-content: space-between; */
}
.navbar>.container, .navbar>.container-fluid {
    display: -ms-flexbox;
    /* display: flex;*/
    }

html, body {
    font-family: 'Open Sans',sans-serif;
    -webkit-font-smoothing: antialiased;
    overflow-x: hidden;
}
body {
    font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
    font-size: 14px;
    line-height: 1.42857143;
    color: #333;
    background-color: #fff;
}

* {
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
}
user agent stylesheet
body {
    display: block;
    margin: 8px;
}
html {
    font-size: 10px;
    -webkit-tap-highlight-color: rgba(0,0,0,0);
}
html {
    font-family: sans-serif;
    -webkit-text-size-adjust: 100%;
    -ms-text-size-adjust: 100%;
}
:after, :before {
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
}
:after, :before {
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
    
}
::-webkit-scrollbar {
    width: 5px !important;
    background-color: #005a93 !important;
    height: 5px !important;
}
::-webkit-scrollbar-thumb {
    background-color: #005a93;
}
::-webkit-scrollbar-track {
    webkit-box-shadow: inset 0 0 5px rgba(0,0,0,0.3) !important;
    background-color: #efefef;
}
body {
    margin: 0;
}
@media screen and (min-width: 1920px){
	.container{
		max-width: 100% !important;
	}
}


</style>
<div id="content-wrapper" style="width: 100%;max-width: 100% !important">
	<div class="row">
		<div class="col-lg-12">

			<div id="content-header" class="clearfix">
				<div class="pull-left">
					<ol class="breadcrumb">
						<li><a href="<?php echo base_url('Dashboard');?>">TABLEAU DE BORD</a></li>
						<li class="active"><span>Inside Data dashboard </span></li>
					</ol>
				</div>

			</div>
			<div class="main-box-body clearfix">
            		<div class="row" style="margin-top:10px;">					
					<div class="col-lg-12">
					<div class="page">
			<div class="page-main">

                <!--app-content open-->
				<div class="container app-content">
					<div class="">

						<!-- PAGE-HEADER -->
						<div class="page-header">
							<div>
								<h1 class="page-title">KPIs</h1>
								
							</div>
							
						</div>

						<div class="page-header">
							<div class="panel panel-primary">
											<div class=" tab-menu-heading">
												<div class="tabs-menu1 ">
													<!-- Tabs -->
													<ul class="nav panel-tabs">
														<li ><a href="#tab5" class="active" data-toggle="tab"><?php echo $active_loan;?></a></li>
														<li><a href="#tab6" data-toggle="tab">Credit Express</a></li>
														<li><a href="#tab7" data-toggle="tab">Credit Sans Guarantie</a></li>
														
													</ul>
												</div>
											</div>
											<div class="panel-body tabs-menu-body">
												<div class="tab-content">
													<div class="tab-pane active " id="tab5">
														<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xl-6">
								<div class="row">
									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">
										<div class="card">
											<div class="card-body text-center statistics-info">
												<div class="counter-icon bg-primary mb-0 box-primary-shadow">
													<i class="fe fe-trending-up text-white"></i>
												</div>
												<h6 class="mt-4 mb-1">Nombre total de prêts décaissés</h6>
												<h2 class="mb-2 number-font"><?php echo  number_format($disbursed_loannumber,0,',',',') ; ?></h2>
													<!--<div class="card-body ">-->
											
													<!--<div class="progress progress-sm mt-0 mb-2">-->
													<!--	<div class="progress-bar bg-success w-50" role="progressbar"></div>-->
													<!--</div>-->
													<!--	<div class=""><i class="fa fa-caret-down text-danger"></i>5% decrease</div>-->
													<!--</div>-->
											
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">
										<div class="card">
											<div class="card-body text-center statistics-info">
												<div class="counter-icon bg-secondary mb-0 box-secondary-shadow">
													<i class="fe fe-codepen text-white"></i>
												</div>
												<h6 class="mt-4 mb-1">Montant total des prêts décaissés</h6>
												<h2 class="mb-2 number-font"><?php echo number_format($disbursed_loanamount,0,',',',') ; ?></h2>
												<!--<div class="card-body ">-->
												
												<!--	<div class="progress progress-sm mt-0 mb-2">-->
												<!--		<div class="progress-bar bg-success w-50" role="progressbar"></div>-->
												<!--	</div>-->
												<!--		<div class=""><i class="fa fa-caret-down text-danger"></i>5% decrease</div>-->
												<!--	</div>-->
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">
										<div class="card">
											<div class="card-body text-center statistics-info">
												<div class="counter-icon bg-success mb-0 box-success-shadow">
													<i class="fe fe-dollar-sign text-white"></i>
												</div>
												<h6 class="mt-4 mb-1">Nombre total de prêts actifs</h6>
												<h2 class="mb-2  number-font"><?php echo number_format($active_loannumber,0,',',',') ; ?></h2>
												
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">
										<div class="card">
											<div class="card-body text-center statistics-info">
												<div class="counter-icon bg-info mb-0 box-info-shadow">
													<i class="fe fe-briefcase text-white"></i>
												</div>
												<h6 class="mt-4 mb-1"> Montant total des prêts actifs</h6>
												<h2 class="mb-2  number-font"><?php echo number_format($active_loanamount,0,',',','); ?></h2>
												
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-6">
								<div class="card">
									<div class="card-header">
										<h3 class="card-title">Tendances des prêts</h3>
									</div>
									<div class="card-body">
										<div id="echart2" class="chart-donut chart-dropshadow"></div>
										<!--<div class="mt-4">-->
										<!--	<span class="ml-5"><span class="dot-label bg-info mr-2"></span>Actives</span>-->
										<!--	<span class="ml-5"><span class="dot-label bg-secondary mr-2"></span>Approved</span>-->
										<!--	<span class="ml-5"><span class="dot-label bg-success mr-2"></span>In Process</span>-->
										<!--	<span class="ml-5"><span class="dot-label bg-danger mr-1"></span>Annule/Abondon</span>-->
										<!--</div>-->
									</div>
								</div>
							</div><!-- COL END -->
						</div>

						                                <div class="row">
							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2">Montant moyen de la demande de prêt</h6>
										<h2 class="mb-2  number-font"><?php 
										    if($active_loannumber){
										    $avg=  ($active_loanamount / $active_loannumber);
										    }else{
										      $avg=0;  
										    }
										    echo number_format($avg,0,',',',');
										?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->

							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-globe text-primary fa-3x text-primary-shadow"></i>
										<h6 class="mt-4 mb-2">Moyen Nbre de Jours déboursement</h6>
										<h2 class="mb-2 number-font"><?php if(round($average_loan_disposition) == 0){
										echo "1";}else{
										    echo round($average_loan_disposition);
										} ?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->
							
							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-globe text-primary fa-3x text-primary-shadow"></i>
										<h6 class="mt-4 mb-2">Productivité Efficacité</h6>
										<h2 class="mb-2 number-font"><?php 
										if($active_loannumber){
										    echo  number_format((($disbursed_loannumber / $active_loannumber)*100)). "%";
										    }else{
										      echo "0". "%"; 
										    }
										
										 ;?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->
							<!--<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">-->
							<!--	<div class="card">-->
							<!--		<div class="card-body text-center">-->
							<!--			<i class="fa fa-globe text-secondary fa-3x text-secondary-shadow"></i>-->
							<!--			<h6 class="mt-4 mb-2">Loan Approved  V.s Tokos</h6>-->
							<!--			<h2 class="mb-2  number-font"><?php echo $tilllastday_loan_approved['total_app'];?></h2>-->
							<!--			<p class="text-muted"></p>-->
							<!--		</div>-->
							<!--	</div>-->
							<!--</div>-->
							<!-- COL END -->
						</div>
                        
                                                        <div class="row">
							

							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2">Total des intérêts perçus</h6>
										<h2 class="mb-2 number-font"><?php echo  number_format($total_interest_ht_sum,0,',',',') ; ?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->

							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2">Total des frais de dossier collectés</h6>
										<h2 class="mb-2  number-font"><?php echo  number_format($frais_de_dossier_sum,0,',',',') ; ?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->
							
							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2"> Assurance principale totale collectée</h6>
										<h2 class="mb-2 number-font"><?php echo  number_format($frais_de_assurance_sum,0,',',',') ; ?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->
							
						</div>
						
						<div class="row">
							

							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2">Total des frais de dossier TTC collectés </h6>
										<h2 class="mb-2 number-font"><?php echo  number_format($frais_de_dossier_ttc_sum,0,',',',') ; ?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->

							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2">Total des frais d'enregistrement TTC collectés</h6>
										<h2 class="mb-2  number-font"><?php echo  number_format($frais_denregistrement_ttc_sum,0,',',',') ; ?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->
							
							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2"> Total des frais d'enregistrement HT collectés</h6>
										<h2 class="mb-2 number-font"><?php echo  number_format($frais_denregistrement_sum,0,',',',') ; ?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->
							
						</div>
						
                    						            <div class="row">
                    							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                    								<div class="card">
                    									<div class="card-header">
                    										<h3 class="card-title">Top 5 des agences par nombre de prêts</h3>
                    									</div>
                    									<div class="card-body p-4">
                    									    <?php 
                    									    $max_count= max(array_column($top5loan_countdetails, 'loancount'));
                    									    if(!empty($top5loan_countdetails)){ 
                    									        foreach($top5loan_countdetails as $tcount){
                    									    ?>
                    							        	<div class="mb-5">
                    											<p class="mb-2"><?php echo $tcount['department']?><span class="float-right text-muted"><?php echo  number_format($tcount['loancount'],0,',',',') ;?></span></p>
                    											<div class="progress  h-2">
                    												<div class="progress-bar"  style="background-color: <?php echo $tcount['color_pattern']?>;width:<?php echo ($tcount['loancount']/$max_count)*100?>%" role="progressbar"></div>
                    											</div>
                    										</div>
                    									    <?php } } ?>
                    										
                    										
                    									</div>
                    								</div>
                    							</div><!-- COL END -->
                    							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                    								<div class="card">
                    									<div class="card-header">
                    										<h3 class="card-title">Top 5 des agences par montant de prêt</h3>
                    									</div>
                    									<div class="card-body p-4">
                    									    
                    									    <?php 
                    									    $max_count= max(array_column($top5loan_amountdetails, 'total_amount'));
                    									     if(!empty($top5loan_amountdetails)){ 
                    									        foreach($top5loan_amountdetails as $tamount){
                    									    ?>
                    							        	<div class="mb-5">
                    											<p class="mb-2"><?php echo $tamount['department']?><span class="float-right text-muted"><?php echo number_format($tamount['total_amount'],0,',',',')  ;?></span></p>
                    											<div class="progress h-2">
                    												<div class="progress-bar"  style="background-color: <?php echo $tamount['color_pattern']?>;width:<?php echo ($tamount['total_amount']/$max_count)*100?>%" role="progressbar"></div>
                    											</div>
                    										</div>
                    									    <?php } } ?>
                    									    
                    										<!--<div class="mb-5">-->
                    										<!--	<p class="mb-2">RR<span class="float-right text-muted">80000</span></p>-->
                    										<!--	<div class="progress h-2">-->
                    										<!--		<div class="progress-bar bg-primary w-80 " role="progressbar"></div>-->
                    										<!--	</div>-->
                    										<!--</div>-->
                    										<!--<div class="mb-5">-->
                    										<!--	<p class="mb-2">Prima<span class="float-right text-muted">700002</span></p>-->
                    										<!--	<div class="progress h-2">-->
                    										<!--		<div class="progress-bar bg-pink w-70" role="progressbar"></div>-->
                    										<!--	</div>-->
                    										<!--</div>-->
                    										<!--<div class="mb-5">-->
                    										<!--	<p class="mb-2">Bureau ADL<span class="float-right text-muted">802666</span></p>-->
                    										<!--	<div class="progress h-2">-->
                    										<!--		<div class="progress-bar bg-warning w-65" role="progressbar"></div>-->
                    										<!--	</div>-->
                    										<!--</div>-->
                    										<!--<div class="mb-5">-->
                    										<!--	<p class="mb-2">Devenir<span class="float-right text-muted">80856</span></p>-->
                    										<!--	<div class="progress h-2">-->
                    										<!--		<div class="progress-bar bg-danger w-80" role="progressbar"></div>-->
                    										<!--	</div>-->
                    										<!--</div>-->
                    										<!--<div class="mb-5">-->
                    										<!--	<p class="mb-2">Bureau ADL<span class="float-right text-muted">7077888</span></p>-->
                    										<!--	<div class="progress h-2">-->
                    										<!--		<div class="progress-bar bg-success w-60" role="progressbar"></div>-->
                    										<!--	</div>-->
                    										<!--</div>-->
                    										
                    									</div>
                    								</div>
                    							</div><!-- COL END -->
                    							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                    								<div class="card">
                    									<div class="card-header">
                    										<h3 class="card-title">Top 5 des agences avec le moins de prêts vieillissants (> 3 jours)</h3>
                    									</div>
                    									<div class="card-body p-4">
                    									    <?php 
                    									    $max_count= max(array_column($top5agingloan, 'totalcount'));
                    									     if(!empty($top5agingloan)){
                    									        foreach($top5agingloan as $aging){
                    									    ?>
                    										<div class="mb-5">
                    											<p class="mb-2"><?php echo $aging['department'];?><span class="float-right text-muted"><?php echo $aging['totalcount'];?></span></p>
                    											<div class="progress h-2">
                    												<div class="progress-bar"  style="background-color: <?php echo $aging['color_pattern']?>;width:<?php echo ($aging['totalcount']/$max_count)*100?>%" role="progressbar"></div>
                    											</div>
                    										</div>
                    									    <?php } } ?>
                    										
                    									</div>
                    								</div>
                    							</div><!-- COL END -->
                    
                    						</div>
                                						<div class="row">
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">Top 5 des agences par rapport au nombre total de prêts par OBJECTIFS</h3>
                                									</div>
                                									<div class="card-body p-4">
                                									    
                                									    <?php 
                                									    
                    									    $max_count= max(array_column($trendingbranch_loannumber, 'progress'));
                    									     if(!empty($trendingbranch_loannumber)) {
                                									            $branch_loancount = 1;
                                									            foreach($trendingbranch_loannumber as $branch_loanno){
                                									                
                                									                if($branch_loanno['progress']) {
                                									    ?>
                                										<div class="mb-5">
                                											<p class="mb-2"><?php echo $branch_loanno['department']; ?><span class="float-right text-muted"><?php echo number_format($branch_loanno['progress'], 2).'%';?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar"  style="background-color: <?php echo $branch_loanno['color_pattern']?>;width:<?php echo ($branch_loanno['progress']/$max_count)*100?>%" role="progressbar"></div>
                                											</div>
                                										</div>
                                										
                                										<?php 
                                										
                                										    if($branch_loancount == 5){
                                										        break;
                                										    }
                                										    $branch_loancount ++;
                                									      } 
                                										}  }?>
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">Top 5 des agences par rapport au montant total du prêt par OBJECTIFS</h3>
                                									</div>
                                									<div class="card-body p-4">
                                									 <?php  
                    									    $max_count= max(array_column($trendingbranch_loanamount, 'progress'));
                    									    if(!empty($trendingbranch_loanamount)) {
                                									            $branch_amtcount = 1;
                                									            foreach($trendingbranch_loanamount as $branch_loanamt){
                                									                
                                									                if($branch_loanamt['progress']) {
                                									    ?>
                                										<div class="mb-5">
                                											<p class="mb-2"><?php echo $branch_loanamt['department']; ?><span class="float-right text-muted"><?php echo number_format($branch_loanamt['progress'], 2).'%';?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar"  style="background-color: <?php echo $branch_loanamt['color_pattern']?>;width:<?php echo ($branch_loanamt['progress']/$max_count)*100?>%" role="progressbar"></div>
                                											</div>
                                										</div>
                                										
                                										<?php 
                                										
                                										    if($branch_amtcount == 5){
                                										        break;
                                										    }
                                										    $branch_amtcount ++;
                                									      } 
                                										}  }?>
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">Top 5 Placeurs par rapport au nombre total de prêts par OBJECTIFS</h3>
                                									</div>
                                									<div class="card-body p-4">
                                									 <?php  
                    									    $max_count= max(array_column($trendingplaceur_loannumber, 'progress'));
                    									    if(!empty($trendingplaceur_loannumber)) {
                                									            $placeur_loancount = 1;
                                									            foreach($trendingplaceur_loannumber as $placeur_loanno){
                                									                
                                									                if($placeur_loanno['progress']) {
                                									    ?>
                                										<div class="mb-5">
                                											<p class="mb-2"><?php echo $placeur_loanno['user']; ?><span class="float-right text-muted"><?php echo number_format($placeur_loanno['progress'], 2).'%';?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar"  style="background-color: <?php echo $placeur_loanno['color_pattern']?>;width:<?php echo ($placeur_loanno['progress']/$max_count)*100?>%" role="progressbar"></div>
                                											</div>
                                										</div>
                                										
                                										<?php 
                                										
                                										    if($placeur_loancount == 5){
                                										        break;
                                										    }
                                										    $placeur_loancount ++;
                                									      } 
                                										}  }?>
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                
                                						</div>
                                
                                						<div class="row">
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">5 DERNIÈRES agences par Nbre de prêt</h3>
                                									</div>
                                									<div class="card-body p-4">
                                									 <?php  
                    									    $max_count= max(array_column($last5loan_countdetails, 'loancount'));
                    									    if(!empty($last5loan_countdetails)){ 
                                									        foreach($last5loan_countdetails as $lcount){
                                									    ?>
                                							        	<div class="mb-5">
                                											<p class="mb-2"><?php echo $lcount['department']?><span class="float-right text-muted"><?php echo number_format($lcount['loancount'],0,',',',')  ;?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar"  style="background-color: <?php echo $lcount['color_pattern']?>;width:<?php echo ($lcount['loancount']/$max_count)*100?>%" role="progressbar"></div>
                                											</div>
                                										</div>
                                								    <?php } } ?>
                                										
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">5 DERNIÈRES  agences par montant de prêt</h3>
                                									</div>
                                									<div class="card-body p-4">
                                									 <?php  
                    									    $max_count= max(array_column($last5loan_amountdetails, 'total_amount'));
                    									    if(!empty($last5loan_amountdetails)){ 
                                									        foreach($last5loan_amountdetails as $lamount){
                                									    ?>
                                							        	<div class="mb-5">
                                											<p class="mb-2"><?php echo $lamount['department']?><span class="float-right text-muted"><?php echo number_format($lamount['total_amount'],0,',',',')  ;?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar"  style="background-color: <?php echo $lamount['color_pattern']?>;width:<?php echo ($lamount['total_amount']/$max_count)*100?>%" role="progressbar"></div>
                                											</div>
                                										</div>
                                								    <?php } } ?>
                                										
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">Top 5 des agences avec des Nbre de prêt AGING</h3>
                                									</div>
                                									<div class="card-body p-4">
                                									    
                                									    <?php 
                    									    $max_count= max(array_column($top5loan_moreagingloan, 'totalcount'));
                    									     if(!empty($top5loan_moreagingloan)) {
                                									        foreach($top5loan_moreagingloan as $more_aging){
                                									    ?>
                                										<div class="mb-5">
                                											<p class="mb-2"><?php echo $more_aging['department']; ?><span class="float-right text-muted"><?php echo $more_aging['totalcount']; ?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar"  style="background-color: <?php echo $more_aging['color_pattern']?>;width:<?php echo ($more_aging['totalcount']/$max_count)*100?>%" role="progressbar"></div>
                                											</div>
                                										</div>
                                										<?php } } ?>
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                
                                						</div>
                                
                                						<div class="row">
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">5 DERNIÈRES Agences par rapport au Nbre de prêt par OBJECTIFS</h3>
                                									</div>
                                									<div class="card-body p-4">
                                									
                                									<?php 
                                									     
                    									    $max_count= max(array_column($last5branches_loanno, 'progress'));
                    									    
                                									if(!empty($last5branches_loanno)) {
                                									            $last_loancount = 1;
                                									            foreach($last5branches_loanno as $last_loanno){
                                									                
                                									                if($last_loanno['progress']) {
                                									    ?>
                                										<div class="mb-5">
                                											<p class="mb-2"><?php echo $last_loanno['department']; ?><span class="float-right text-muted"><?php echo number_format($last_loanno['progress'], 2).'%';?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar"  style="background-color: <?php echo $last_loanno['color_pattern']?>;width:<?php echo ($last_loanno['progress']/$max_count)*100?>%" role="progressbar"></div>
                                											</div>
                                										</div>
                                										
                                										<?php 
                                										
                                										    if($last_loancount == 5){
                                										        break;
                                										    }
                                										    $last_loancount ++;
                                									      } 
                                										}  }?>
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">5 DERNIÈRES agences par rapport au montant total du prêt par OBJECTIFS</h3>
                                									</div>
                                									<div class="card-body p-4">
                                										<?php 
                                									     
                    									    $max_count= max(array_column($last5branches_loanamt, 'progress'));
                    									    
                                									if(!empty($last5branches_loanamt)) {
                                									            $last_loanamt = 1;
                                									            foreach($last5branches_loanamt as $last_amount){
                                									                
                                									                if($last_amount['progress']) {
                                									    ?>
                                										<div class="mb-5">
                                											<p class="mb-2"><?php echo $last_amount['department']; ?><span class="float-right text-muted"><?php echo number_format($last_amount['progress'], 2).'%';?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar"  style="background-color: <?php echo $last_amount['color_pattern']?>;width:<?php echo ($last_amount['progress']/$max_count)*100?>%" role="progressbar"></div>
                                											</div>
                                										</div>
                                										
                                										<?php 
                                										
                                										    if($last_loanamt == 5){
                                										        break;
                                										    }
                                										    $last_loanamt ++;
                                									      } 
                                										}  }?>
                                										
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">5 DERNIERS Placeurs par rapport au nombre total de prêts par OBJECTIFS</h3>
                                									</div>
                                									<div class="card-body p-4">
                                								    	<?php 
                                									     
                    									    $max_count= max(array_column($last5placeur_loanno, 'progress'));
                    									   // print_r($last5placeur_loanno);
                                									        if(!empty($last5placeur_loanno)) {
                                									            $last_placeur = 1;
                                									            foreach($last5placeur_loanno as $last_placeurloaanno){
                                									                
                                									                if($last_placeurloaanno['progress']) {
                                									    ?>
                                    										<div class="mb-5">
                                    											<p class="mb-2"><?php echo $last_placeurloaanno['user']; ?><span class="float-right text-muted"><?php echo number_format($last_placeurloaanno['progress'], 2).'%';?></span></p>
                                    											<div class="progress h-2">
                                    												<div class="progress-bar"  style="background-color: <?php echo $last_placeurloaanno['color_pattern']?>;width:<?php echo ($last_placeurloaanno['progress']/100)*100?>%" role="progressbar"></div>
                                    											</div>
                                    										</div>
                                										
                                										<?php 
                                										
                                										    if($last_placeur == 5){
                                										        break;
                                										    }
                                										    $last_placeur ++;
                                									      } 
                                										}  }?>
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                
                                						</div>
                                
                                						<div class="row">
                                							
                                
                                							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
                                								<div class="card">
                                									<div class="card-body text-center">
                                										<i class="fa fa-globe text-primary fa-3x text-primary-shadow"></i>
                                										<h6 class="mt-4 mb-2">Nombre total d'annulations de prêt</h6>
                                										<h2 class="mb-2 number-font"><?php echo  number_format($Annuler_loannumber,0,',',',') ; ?></h2>
                                										<p class="text-muted"></p>
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                
                                							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
                                								<div class="card">
                                									<div class="card-body text-center">
                                										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
                                										<h6 class="mt-4 mb-2">Montant total de l'annulation du prêt</h6>
                                										<h2 class="mb-2  number-font"><?php echo  number_format($Annuler_loanamount,0,',',',') ; ?></h2>
                                										<p class="text-muted"></p>
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							
                                							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
                                								<div class="card">
                                									<div class="card-body text-center">
                                										<i class="fa fa-globe text-primary fa-3x text-primary-shadow"></i>
                                										<h6 class="mt-4 mb-2">Nombre total de prêt Abondonne</h6>
                                										<h2 class="mb-2 number-font"><?php echo  number_format($Abandonner_loannumber,0,',',',') ; ?></h2>
                                										<p class="text-muted"></p>
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
                                								<div class="card">
                                									<div class="card-body text-center">
                                										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
                                										<h6 class="mt-4 mb-2">Montant total du prêt Abondonne</h6>
                                										<h2 class="mb-2  number-font"><?php echo  number_format($Abandonner_loanamount,0,',',',') ; ?></h2>
                                										<p class="text-muted"></p>
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                						</div>
                                
                                						<div class="row">
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-3">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">Top 5 des agences par nombre total de prêts Annule</h3>
                                									</div>
                                									<div class="card-body p-4">
                                									    <?php
                                									    $max_count= max(array_column($top5loan_countdetails_annule, 'loancount'));
                                									    if(!empty($top5loan_countdetails_annule)){ 
                                									        foreach($top5loan_countdetails_annule as $tcount){
                                									    ?>
                                							        	<div class="mb-5">
                                											<p class="mb-2"><?php echo $tcount['department']?><span class="float-right text-muted"><?php echo  number_format($tcount['loancount'],0,',',',') ;?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar"  style="background-color: <?php echo $tcount['color_pattern']?>;width:<?php echo ($tcount['loancount']/$max_count)*100?>%" role="progressbar"></div>
                                											</div>
                                										</div>
                                									    <?php } } ?>
                                										
                                										
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-3">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">Top 5 des agences par montant total de prêt Annule</h3>
                                									</div>
                                									<div class="card-body p-4">
                                										<?php
                                										$max_count= max(array_column($top5loan_amountdetails_annule, 'total_amount'));
                                										
                                										if(!empty($top5loan_amountdetails_annule)){ 
                                									        foreach($top5loan_amountdetails_annule as $tcount){
                                									    ?>
                                							        	<div class="mb-5">
                                											<p class="mb-2"><?php echo $tcount['department']?><span class="float-right text-muted"><?php echo  number_format($tcount['total_amount'],0,',',',') ;?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar"  style="background-color: <?php echo $tcount['color_pattern']?>;width:<?php echo ($tcount['total_amount']/$max_count)*100?>%" role="progressbar"></div>
                                											</div>
                                										</div>
                                									    <?php } } ?>
                                										
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-3">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">Top 5 des agences par nombre total de prêts Abandon</h3>
                                									</div>
                                									<div class="card-body p-4">
                                										<?php
                                										
                                										$max_count= max(array_column($top5loan_countdetails_Abandonner, 'loancount'));
                                										if(!empty($top5loan_countdetails_Abandonner)){ 
                                									        foreach($top5loan_countdetails_Abandonner as $tcount){
                                									    ?>
                                							        	<div class="mb-5">
                                											<p class="mb-2"><?php echo $tcount['department']?><span class="float-right text-muted"><?php echo  number_format($tcount['loancount'],0,',',',') ;?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar"  style="background-color: <?php echo $tcount['color_pattern']?>;width:<?php echo ($tcount['loancount']/$max_count)*100?>%" role="progressbar"></div>
                                											</div>
                                										</div>
                                									    <?php } } ?>
                                										
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-3">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">Top 5 des agences par montant total de prêt Abondonne</h3>
                                									</div>
                                									<div class="card-body p-4">
                                										<?php
                                										$max_count= max(array_column($top5loan_amountdetails_Abandonner, 'total_amount'));
                                										if(!empty($top5loan_amountdetails_Abandonner)){ 
                                									        foreach($top5loan_amountdetails_Abandonner as $tcount){
                                									    ?>
                                							        	<div class="mb-5">
                                											<p class="mb-2"><?php echo $tcount['department']?><span class="float-right text-muted"><?php echo  number_format($tcount['total_amount'],0,',',',') ;?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar"  style="background-color: <?php echo $tcount['color_pattern']?>;width:<?php echo ($tcount['total_amount']/$max_count)*100?>%" role="progressbar"></div>
                                											</div>
                                										</div>
                                									    <?php } } ?>
                                										
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                
                                						</div>
						
						
													</div>
													<div class="tab-pane " id="tab6">
														<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xl-6">
								<div class="row">
									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">
										<div class="card">
											<div class="card-body text-center statistics-info">
												<div class="counter-icon bg-primary mb-0 box-primary-shadow">
													<i class="fe fe-trending-up text-white"></i>
												</div>
												<h6 class="mt-4 mb-1">Nombre total de prêts décaissés</h6>
												<h2 class="mb-2 number-font"><?php echo "0";
												//echo  number_format($disbursed_loannumber,0,',',',') ; ?></h2>
													<!--<div class="card-body ">-->
											
													<!--<div class="progress progress-sm mt-0 mb-2">-->
													<!--	<div class="progress-bar bg-success w-50" role="progressbar"></div>-->
													<!--</div>-->
													<!--	<div class=""><i class="fa fa-caret-down text-danger"></i>5% decrease</div>-->
													<!--</div>-->
											
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">
										<div class="card">
											<div class="card-body text-center statistics-info">
												<div class="counter-icon bg-secondary mb-0 box-secondary-shadow">
													<i class="fe fe-codepen text-white"></i>
												</div>
												<h6 class="mt-4 mb-1">Montant total des prêts décaissés</h6>
												<h2 class="mb-2 number-font"><?php echo "0";
												//echo number_format($disbursed_loanamount,0,',',',') ; ?></h2>
												<!--<div class="card-body ">-->
												
												<!--	<div class="progress progress-sm mt-0 mb-2">-->
												<!--		<div class="progress-bar bg-success w-50" role="progressbar"></div>-->
												<!--	</div>-->
												<!--		<div class=""><i class="fa fa-caret-down text-danger"></i>5% decrease</div>-->
												<!--	</div>-->
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">
										<div class="card">
											<div class="card-body text-center statistics-info">
												<div class="counter-icon bg-success mb-0 box-success-shadow">
													<i class="fe fe-dollar-sign text-white"></i>
												</div>
												<h6 class="mt-4 mb-1">Nombre total de prêts actifs</h6>
												<h2 class="mb-2  number-font"><?php echo "0";
												//echo number_format($active_loannumber,0,',',',') ; ?></h2>
												
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">
										<div class="card">
											<div class="card-body text-center statistics-info">
												<div class="counter-icon bg-info mb-0 box-info-shadow">
													<i class="fe fe-briefcase text-white"></i>
												</div>
												<h6 class="mt-4 mb-1"> Montant total des prêts actifs</h6>
												<h2 class="mb-2  number-font"><?php echo "0";
												//echo number_format($active_loanamount,0,',',','); ?></h2>
												
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-6">
								<div class="card">
									<div class="card-header">
										<h3 class="card-title">Tendances des prêts</h3>
									</div>
									<div class="card-body">
										<div id="echart2" class="chart-donut chart-dropshadow"></div>
										<!--<div class="mt-4">-->
										<!--	<span class="ml-5"><span class="dot-label bg-info mr-2"></span>Actives</span>-->
										<!--	<span class="ml-5"><span class="dot-label bg-secondary mr-2"></span>Approved</span>-->
										<!--	<span class="ml-5"><span class="dot-label bg-success mr-2"></span>In Process</span>-->
										<!--	<span class="ml-5"><span class="dot-label bg-danger mr-1"></span>Annule/Abondon</span>-->
										<!--</div>-->
									</div>
								</div>
							</div><!-- COL END -->
						</div>

						                                <div class="row">
							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2">Montant moyen de la demande de prêt</h6>
										<h2 class="mb-2  number-font"><?php 
										    if($active_loannumber){
										    $avg=  ($active_loanamount / $active_loannumber);
										    }else{
										      $avg=0;  
										    }
										    echo "0";
										    //echo number_format($avg,0,',',',');
										?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->

							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-globe text-primary fa-3x text-primary-shadow"></i>
										<h6 class="mt-4 mb-2">Moyen Nbre de Jours déboursement</h6>
										<h2 class="mb-2 number-font">0</h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->
							
							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-globe text-primary fa-3x text-primary-shadow"></i>
										<h6 class="mt-4 mb-2">Productivité Efficacité</h6>
										<h2 class="mb-2 number-font"><?php 
										if($active_loannumber){
										    echo "0". "%";
										    //echo  number_format(($disbursed_loannumber / $active_loannumber)). "%";
										    }else{
										      echo "0". "%"; 
										    }
										
										 ;?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->
							<!--<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">-->
							<!--	<div class="card">-->
							<!--		<div class="card-body text-center">-->
							<!--			<i class="fa fa-globe text-secondary fa-3x text-secondary-shadow"></i>-->
							<!--			<h6 class="mt-4 mb-2">Loan Approved  V.s Tokos</h6>-->
							<!--			<h2 class="mb-2  number-font"></h2>-->
							<!--			<p class="text-muted"></p>-->
							<!--		</div>-->
							<!--	</div>-->
							<!--</div>-->
							<!-- COL END -->
						</div>
                        
                                                        <div class="row">
							

							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2">Total des intérêts perçus</h6>
										<h2 class="mb-2 number-font"><?php echo "0";
										//echo  number_format($Annuler_loanamount,0,',',',') ; ?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->

							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2">Total des frais de dossier collectés</h6>
										<h2 class="mb-2  number-font"><?php echo "0";
										//echo  number_format($dossier_total,0,',',',') ; ?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->
							
							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2"> Assurance principale totale collectée</h6>
										<h2 class="mb-2 number-font"><?php echo "0";
										//echo  number_format($Annuler_loanamount,0,',',',') ; ?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->
							
						</div>
						<div class="row">
							

							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2">Total des frais de dossier TTC collectés </h6>
										<h2 class="mb-2 number-font"><?php echo "0";
										//echo  number_format($frais_de_dossier_ttc_sum,0,',',',') ; ?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->

							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2">Total des frais d'enregistrement TTC collectés</h6>
										<h2 class="mb-2  number-font"><?php echo "0";
										//echo  number_format($frais_denregistrement_ttc_sum,0,',',',') ; ?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->
							
							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2"> Total des frais d'enregistrement HT collectés</h6>
										<h2 class="mb-2 number-font"><?php echo "0";
										//echo  number_format($frais_denregistrement_sum,0,',',',') ; ?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->
							
						</div>
                    						            <div class="row">
                    							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                    								<div class="card">
                    									<div class="card-header">
                    										<h3 class="card-title">Top 5 des agences par nombre de prêts</h3>
                    									</div>
                    									<div class="card-body p-4">
                    									    <?php /* if(!empty($top5loan_countdetails)){ 
                    									        foreach($top5loan_countdetails as $tcount){
                    									    ?>
                    							        	<div class="mb-5">
                    											<p class="mb-2"><?php echo $tcount['department']?><span class="float-right text-muted"><?php echo  number_format($tcount['loancount'],0,',',',') ;?></span></p>
                    											<div class="progress h-2">
                    												<div class="progress-bar bg-primary" role="progressbar"></div>
                    											</div>
                    										</div>
                    									    <?php } } */ ?>
                    										
                    										
                    									</div>
                    								</div>
                    							</div><!-- COL END -->
                    							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                    								<div class="card">
                    									<div class="card-header">
                    										<h3 class="card-title">Top 5 des agences par montant de prêt</h3>
                    									</div>
                    									<div class="card-body p-4">
                    									    
                    									    <?php /* if(!empty($top5loan_amountdetails)){ 
                    									        foreach($top5loan_amountdetails as $tamount){
                    									    ?>
                    							        	<div class="mb-5">
                    											<p class="mb-2"><?php echo $tamount['department']?><span class="float-right text-muted"><?php echo number_format($tamount['total_amount'],0,',',',')  ;?></span></p>
                    											<div class="progress h-2">
                    												<div class="progress-bar bg-primary" role="progressbar"></div>
                    											</div>
                    										</div>
                    									    <?php } } */ ?>
                    									    
                    										<!--<div class="mb-5">-->
                    										<!--	<p class="mb-2">RR<span class="float-right text-muted">80000</span></p>-->
                    										<!--	<div class="progress h-2">-->
                    										<!--		<div class="progress-bar bg-primary w-80 " role="progressbar"></div>-->
                    										<!--	</div>-->
                    										<!--</div>-->
                    										<!--<div class="mb-5">-->
                    										<!--	<p class="mb-2">Prima<span class="float-right text-muted">700002</span></p>-->
                    										<!--	<div class="progress h-2">-->
                    										<!--		<div class="progress-bar bg-pink w-70" role="progressbar"></div>-->
                    										<!--	</div>-->
                    										<!--</div>-->
                    										<!--<div class="mb-5">-->
                    										<!--	<p class="mb-2">Bureau ADL<span class="float-right text-muted">802666</span></p>-->
                    										<!--	<div class="progress h-2">-->
                    										<!--		<div class="progress-bar bg-warning w-65" role="progressbar"></div>-->
                    										<!--	</div>-->
                    										<!--</div>-->
                    										<!--<div class="mb-5">-->
                    										<!--	<p class="mb-2">Devenir<span class="float-right text-muted">80856</span></p>-->
                    										<!--	<div class="progress h-2">-->
                    										<!--		<div class="progress-bar bg-danger w-80" role="progressbar"></div>-->
                    										<!--	</div>-->
                    										<!--</div>-->
                    										<!--<div class="mb-5">-->
                    										<!--	<p class="mb-2">Bureau ADL<span class="float-right text-muted">7077888</span></p>-->
                    										<!--	<div class="progress h-2">-->
                    										<!--		<div class="progress-bar bg-success w-60" role="progressbar"></div>-->
                    										<!--	</div>-->
                    										<!--</div>-->
                    										
                    									</div>
                    								</div>
                    							</div><!-- COL END -->
                    							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                    								<div class="card">
                    									<div class="card-header">
                    										<h3 class="card-title">Top 5 des agences avec le moins de prêts vieillissants (> 3 jours)</h3>
                    									</div>
                    									<div class="card-body p-4">
                    									    <?php /* if(!empty($top5agingloan)){
                    									        foreach($top5agingloan as $aging){
                    									    ?>
                    										<div class="mb-5">
                    											<p class="mb-2"><?php echo $aging['department'];?><span class="float-right text-muted"><?php echo $aging['totalcount'];?></span></p>
                    											<div class="progress h-2">
                    												<div class="progress-bar bg-primary" role="progressbar"></div>
                    											</div>
                    										</div>
                    									    <?php } } */ ?>
                    										
                    									</div>
                    								</div>
                    							</div><!-- COL END -->
                    
                    						</div>
                                						<div class="row">
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">Top 5 des agences par rapport au nombre total de prêts par OBJECTIFS</h3>
                                									</div>
                                									<div class="card-body p-4">
                                									    
                                									    <?php /*if(!empty($trendingbranch_loannumber)) {
                                									            $branch_loancount = 1;
                                									            foreach($trendingbranch_loannumber as $branch_loanno){
                                									                
                                									                if($branch_loanno['progress']) {
                                									    ?>
                                										<div class="mb-5">
                                											<p class="mb-2"><?php echo $branch_loanno['department']; ?><span class="float-right text-muted"><?php echo number_format($branch_loanno['progress'], 2).'%';?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar bg-primary" role="progressbar"></div>
                                											</div>
                                										</div>
                                										
                                										<?php 
                                										
                                										    if($branch_loancount == 5){
                                										        break;
                                										    }
                                										    $branch_loancount ++;
                                									      } 
                                										}  } */?>
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">Top 5 des agences par rapport au montant total du prêt par OBJECTIFS</h3>
                                									</div>
                                									<div class="card-body p-4">
                                									 <?php /*if(!empty($trendingbranch_loanamount)) {
                                									            $branch_amtcount = 1;
                                									            foreach($trendingbranch_loanamount as $branch_loanamt){
                                									                
                                									                if($branch_loanamt['progress']) {
                                									    ?>
                                										<div class="mb-5">
                                											<p class="mb-2"><?php echo $branch_loanamt['department']; ?><span class="float-right text-muted"><?php echo number_format($branch_loanamt['progress'], 2).'%';?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar bg-primary" role="progressbar"></div>
                                											</div>
                                										</div>
                                										
                                										<?php 
                                										
                                										    if($branch_amtcount == 5){
                                										        break;
                                										    }
                                										    $branch_amtcount ++;
                                									      } 
                                										}  } */?>
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">Top 5 Placeurs par rapport au nombre total de prêts par OBJECTIFS</h3>
                                									</div>
                                									<div class="card-body p-4">
                                									 <?php /*if(!empty($trendingplaceur_loannumber)) {
                                									            $placeur_loancount = 1;
                                									            foreach($trendingplaceur_loannumber as $placeur_loanno){
                                									                
                                									                if($placeur_loanno['progress']) {
                                									    ?>
                                										<div class="mb-5">
                                											<p class="mb-2"><?php echo $placeur_loanno['department']; ?><span class="float-right text-muted"><?php echo number_format($placeur_loanno['progress'], 2).'%';?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar bg-primary" role="progressbar"></div>
                                											</div>
                                										</div>
                                										
                                										<?php 
                                										
                                										    if($placeur_loancount == 5){
                                										        break;
                                										    }
                                										    $placeur_loancount ++;
                                									      } 
                                										}  } */?>
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                
                                						</div>
                                
                                						<div class="row">
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">5 DERNIÈRES agences par Nbre de prêt</h3>
                                									</div>
                                									<div class="card-body p-4">
                                									 <?php /*if(!empty($last5loan_countdetails)){ 
                                									        foreach($last5loan_countdetails as $lcount){
                                									    ?>
                                							        	<div class="mb-5">
                                											<p class="mb-2"><?php echo $lcount['department']?><span class="float-right text-muted"><?php echo number_format($lcount['loancount'],0,',',',')  ;?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar bg-primary" role="progressbar"></div>
                                											</div>
                                										</div>
                                								    <?php } } */?>
                                										
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">5 DERNIÈRES  agences par montant de prêt</h3>
                                									</div>
                                									<div class="card-body p-4">
                                									 <?php /*if(!empty($last5loan_amountdetails)){ 
                                									        foreach($last5loan_amountdetails as $lamount){
                                									    ?>
                                							        	<div class="mb-5">
                                											<p class="mb-2"><?php echo $lamount['department']?><span class="float-right text-muted"><?php echo number_format($lamount['total_amount'],0,',',',')  ;?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar bg-primary" role="progressbar"></div>
                                											</div>
                                										</div>
                                								    <?php } }*/ ?>
                                										
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">Top 5 des agences avec des Nbre de prêt AGING</h3>
                                									</div>
                                									<div class="card-body p-4">
                                									    
                                									    <?php /* if(!empty($top5loan_moreagingloan)) {
                                									        foreach($top5loan_moreagingloan as $more_aging){
                                									    ?>
                                										<div class="mb-5">
                                											<p class="mb-2"><?php echo $more_aging['department']; ?><span class="float-right text-muted"><?php echo $more_aging['totalcount']; ?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar bg-primary" role="progressbar"></div>
                                											</div>
                                										</div>
                                										<?php } } */?>
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                
                                						</div>
                                
                                						<div class="row">
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">5 DERNIÈRES Agences par rapport au Nbre de prêt par OBJECTIFS</h3>
                                									</div>
                                									<div class="card-body p-4">
                                									
                                									<?php 
                                									    /*
                                									if(!empty($last5branches_loanno)) {
                                									            $last_loancount = 1;
                                									            foreach($last5branches_loanno as $last_loanno){
                                									                
                                									                if($last_loanno['progress']) {
                                									    ?>
                                										<div class="mb-5">
                                											<p class="mb-2"><?php echo $last_loanno['department']; ?><span class="float-right text-muted"><?php echo number_format($last_loanno['progress'], 2).'%';?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar bg-primary" role="progressbar"></div>
                                											</div>
                                										</div>
                                										
                                										<?php 
                                										
                                										    if($last_loancount == 5){
                                										        break;
                                										    }
                                										    $last_loancount ++;
                                									      } 
                                										}  } */?>
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">5 DERNIÈRES agences par rapport au montant total du prêt par OBJECTIFS</h3>
                                									</div>
                                									<div class="card-body p-4">
                                										<?php 
                                									    /*
                                									if(!empty($last5branches_loanamt)) {
                                									            $last_loanamt = 1;
                                									            foreach($last5branches_loanamt as $last_amount){
                                									                
                                									                if($last_amount['progress']) {
                                									    ?>
                                										<div class="mb-5">
                                											<p class="mb-2"><?php echo $last_amount['department']; ?><span class="float-right text-muted"><?php echo number_format($last_amount['progress'], 2).'%';?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar bg-primary" role="progressbar"></div>
                                											</div>
                                										</div>
                                										
                                										<?php 
                                										
                                										    if($last_loanamt == 5){
                                										        break;
                                										    }
                                										    $last_loanamt ++;
                                									      } 
                                										}  } */?>
                                										
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">5 DERNIERS Placeurs par rapport au nombre total de prêts par OBJECTIFS</h3>
                                									</div>
                                									<div class="card-body p-4">
                                								    	<?php 
                                									    /*
                                									        if(!empty($last5placeur_loanno)) {
                                									            $last_placeur = 1;
                                									            foreach($last5placeur_loanno as $last_placeurloaanno){
                                									                
                                									                if($last_placeurloaanno['progress']) {
                                									    ?>
                                    										<div class="mb-5">
                                    											<p class="mb-2"><?php echo $last_placeurloaanno['department']; ?><span class="float-right text-muted"><?php echo number_format($last_placeurloaanno['progress'], 2).'%';?></span></p>
                                    											<div class="progress h-2">
                                    												<div class="progress-bar bg-primary" role="progressbar"></div>
                                    											</div>
                                    										</div>
                                										
                                										<?php 
                                										
                                										    if($last_placeur == 5){
                                										        break;
                                										    }
                                										    $last_placeur ++;
                                									      } 
                                										}  } */?>
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                
                                						</div>
                                
                                						<div class="row">
                                							
                                
                                							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
                                								<div class="card">
                                									<div class="card-body text-center">
                                										<i class="fa fa-globe text-primary fa-3x text-primary-shadow"></i>
                                										<h6 class="mt-4 mb-2">Nombre total d'annulations de prêt</h6>
                                										<h2 class="mb-2 number-font"><?php echo "0";
                                										//echo  number_format($Annuler_loannumber,0,',',',') ; ?></h2>
                                										<p class="text-muted"></p>
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                
                                							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
                                								<div class="card">
                                									<div class="card-body text-center">
                                										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
                                										<h6 class="mt-4 mb-2">Montant total de l'annulation du prêt</h6>
                                										<h2 class="mb-2  number-font"><?php echo "0";
                                										//echo  number_format($Annuler_loanamount,0,',',',') ; ?></h2>
                                										<p class="text-muted"></p>
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							
                                							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
                                								<div class="card">
                                									<div class="card-body text-center">
                                										<i class="fa fa-globe text-primary fa-3x text-primary-shadow"></i>
                                										<h6 class="mt-4 mb-2">Nombre total de prêt Abondonne</h6>
                                										<h2 class="mb-2 number-font"><?php echo "0";
                                										//echo  number_format($Abandonner_loannumber,0,',',',') ; ?></h2>
                                										<p class="text-muted"></p>
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
                                								<div class="card">
                                									<div class="card-body text-center">
                                										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
                                										<h6 class="mt-4 mb-2">Montant total du prêt Abondonne</h6>
                                										<h2 class="mb-2  number-font"><?php 
                                										echo "0";
                                										//echo  number_format($Abandonner_loanamount,0,',',',') ; ?></h2>
                                										<p class="text-muted"></p>
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                						</div>
                                
                                						<div class="row">
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-3">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">Top 5 des agences par nombre total de prêts Annule</h3>
                                									</div>
                                									<div class="card-body p-4">
                                									    <?php /* if(!empty($top5loan_countdetails_annule)){ 
                                									        foreach($top5loan_countdetails_annule as $tcount){
                                									    ?>
                                							        	<div class="mb-5">
                                											<p class="mb-2"><?php echo $tcount['department']?><span class="float-right text-muted"><?php echo  number_format($tcount['loancount'],0,',',',') ;?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar bg-primary w-<?php echo  number_format($tcount['loancount'],0,',',',') ;?>" role="progressbar"></div>
                                											</div>
                                										</div>
                                									    <?php } }*/ ?>
                                										
                                										
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-3">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">Top 5 des agences par montant total de prêt Annule</h3>
                                									</div>
                                									<div class="card-body p-4">
                                										<?php /*  if(!empty($top5loan_amountdetails_annule)){ 
                                									        foreach($top5loan_amountdetails_annule as $tcount){
                                									    ?>
                                							        	<div class="mb-5">
                                											<p class="mb-2"><?php echo $tcount['department']?><span class="float-right text-muted"><?php echo  number_format($tcount['total_amount'],0,',',',') ;?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar bg-primary w-<?php echo  number_format($tcount['total_amount'],0,',',',') ;?>" role="progressbar"></div>
                                											</div>
                                										</div>
                                									    <?php } } */?>
                                										
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-3">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">Top 5 des agences par nombre total de prêts Abandon</h3>
                                									</div>
                                									<div class="card-body p-4">
                                										<?php /*if(!empty($top5loan_countdetails_Abandonner)){ 
                                									        foreach($top5loan_countdetails_Abandonner as $tcount){
                                									    ?>
                                							        	<div class="mb-5">
                                											<p class="mb-2"><?php echo $tcount['department']?><span class="float-right text-muted"><?php echo  number_format($tcount['loancount'],0,',',',') ;?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar bg-primary w-<?php echo  number_format($tcount['loancount'],0,',',',') ;?>" role="progressbar"></div>
                                											</div>
                                										</div>
                                									    <?php } } */?>
                                										
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-3">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">Top 5 des agences par montant total de prêt Abondonne</h3>
                                									</div>
                                									<div class="card-body p-4">
                                										<?php /*if(!empty($top5loan_amountdetails_Abandonner)){ 
                                									        foreach($top5loan_amountdetails_Abandonner as $tcount){
                                									    ?>
                                							        	<div class="mb-5">
                                											<p class="mb-2"><?php echo $tcount['department']?><span class="float-right text-muted"><?php echo  number_format($tcount['total_amount'],0,',',',') ;?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar bg-primary w-<?php echo  number_format($tcount['total_amount'],0,',',',') ;?>" role="progressbar"></div>
                                											</div>
                                										</div>
                                									    <?php } } */ ?>
                                										
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                
                                						</div>
													</div>
													<div class="tab-pane " id="tab7">
														<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xl-6">
								<div class="row">
									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">
										<div class="card">
											<div class="card-body text-center statistics-info">
												<div class="counter-icon bg-primary mb-0 box-primary-shadow">
													<i class="fe fe-trending-up text-white"></i>
												</div>
												<h6 class="mt-4 mb-1">Nombre total de prêts décaissés</h6>
												<h2 class="mb-2 number-font"><?php echo "0";
												//echo  number_format($disbursed_loannumber,0,',',',') ; ?></h2>
													<!--<div class="card-body ">-->
											
													<!--<div class="progress progress-sm mt-0 mb-2">-->
													<!--	<div class="progress-bar bg-success w-50" role="progressbar"></div>-->
													<!--</div>-->
													<!--	<div class=""><i class="fa fa-caret-down text-danger"></i>5% decrease</div>-->
													<!--</div>-->
											
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">
										<div class="card">
											<div class="card-body text-center statistics-info">
												<div class="counter-icon bg-secondary mb-0 box-secondary-shadow">
													<i class="fe fe-codepen text-white"></i>
												</div>
												<h6 class="mt-4 mb-1">Montant total des prêts décaissés</h6>
												<h2 class="mb-2 number-font"><?php echo "0";
												//echo number_format($disbursed_loanamount,0,',',',') ; ?></h2>
												<!--<div class="card-body ">-->
												
												<!--	<div class="progress progress-sm mt-0 mb-2">-->
												<!--		<div class="progress-bar bg-success w-50" role="progressbar"></div>-->
												<!--	</div>-->
												<!--		<div class=""><i class="fa fa-caret-down text-danger"></i>5% decrease</div>-->
												<!--	</div>-->
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">
										<div class="card">
											<div class="card-body text-center statistics-info">
												<div class="counter-icon bg-success mb-0 box-success-shadow">
													<i class="fe fe-dollar-sign text-white"></i>
												</div>
												<h6 class="mt-4 mb-1">Nombre total de prêts actifs</h6>
												<h2 class="mb-2  number-font"><?php echo "0";
												//echo number_format($active_loannumber,0,',',',') ; ?></h2>
												
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-md-12 col-sm-12 col-xl-6">
										<div class="card">
											<div class="card-body text-center statistics-info">
												<div class="counter-icon bg-info mb-0 box-info-shadow">
													<i class="fe fe-briefcase text-white"></i>
												</div>
												<h6 class="mt-4 mb-1"> Montant total des prêts actifs</h6>
												<h2 class="mb-2  number-font"><?php echo "0";
												//echo number_format($active_loanamount,0,',',','); ?></h2>
												
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-6">
								<div class="card">
									<div class="card-header">
										<h3 class="card-title">Tendances des prêts</h3>
									</div>
									<div class="card-body">
										<div id="echart2" class="chart-donut chart-dropshadow"></div>
										<!--<div class="mt-4">-->
										<!--	<span class="ml-5"><span class="dot-label bg-info mr-2"></span>Actives</span>-->
										<!--	<span class="ml-5"><span class="dot-label bg-secondary mr-2"></span>Approved</span>-->
										<!--	<span class="ml-5"><span class="dot-label bg-success mr-2"></span>In Process</span>-->
										<!--	<span class="ml-5"><span class="dot-label bg-danger mr-1"></span>Annule/Abondon</span>-->
										<!--</div>-->
									</div>
								</div>
							</div><!-- COL END -->
						</div>

						                                <div class="row">
							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2">Montant moyen de la demande de prêt</h6>
										<h2 class="mb-2  number-font"><?php 
										    if($active_loannumber){
										    $avg=  ($active_loanamount / $active_loannumber);
										    }else{
										      $avg=0;  
										    }
										    echo "0";
										    //echo number_format($avg,0,',',',');
										?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->

							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-globe text-primary fa-3x text-primary-shadow"></i>
										<h6 class="mt-4 mb-2">Moyen Nbre de Jours déboursement</h6>
										<h2 class="mb-2 number-font">0</h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->
							
							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-globe text-primary fa-3x text-primary-shadow"></i>
										<h6 class="mt-4 mb-2">Productivité Efficacité</h6>
										<h2 class="mb-2 number-font"><?php 
										if($active_loannumber){
										    echo "0". "%";
										    //echo  number_format(($disbursed_loannumber / $active_loannumber)). "%";
										    }else{
										      echo "0". "%"; 
										    }
										
										 ;?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->
							<!--<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">-->
							<!--	<div class="card">-->
							<!--		<div class="card-body text-center">-->
							<!--			<i class="fa fa-globe text-secondary fa-3x text-secondary-shadow"></i>-->
							<!--			<h6 class="mt-4 mb-2">Loan Approved  V.s Tokos</h6>-->
							<!--			<h2 class="mb-2  number-font"></h2>-->
							<!--			<p class="text-muted"></p>-->
							<!--		</div>-->
							<!--	</div>-->
							<!--</div>-->
							<!-- COL END -->
						</div>
                        
                                                        <div class="row">
							

							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2">Total des intérêts perçus</h6>
										<h2 class="mb-2 number-font"><?php echo "0";
										//echo  number_format($Annuler_loanamount,0,',',',') ; ?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->

							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2">Total des frais de dossier collectés</h6>
										<h2 class="mb-2  number-font"><?php echo "0";
										//echo  number_format($dossier_total,0,',',',') ; ?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->
							
							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2"> Assurance principale totale collectée</h6>
										<h2 class="mb-2 number-font"><?php echo "0";
										//echo  number_format($Annuler_loanamount,0,',',',') ; ?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->
							
						</div>
						<div class="row">
							

							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2">Total des frais de dossier TTC collectés </h6>
										<h2 class="mb-2 number-font"><?php echo "0";
										//echo  number_format($frais_de_dossier_ttc_sum,0,',',',') ; ?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->

							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2">Total des frais d'enregistrement TTC collectés</h6>
										<h2 class="mb-2  number-font"><?php echo "0";
										//echo  number_format($frais_denregistrement_ttc_sum,0,',',',') ; ?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->
							
							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card">
									<div class="card-body text-center">
										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
										<h6 class="mt-4 mb-2"> Total des frais d'enregistrement HT collectés</h6>
										<h2 class="mb-2 number-font"><?php echo "0";
										//echo  number_format($frais_denregistrement_sum,0,',',',') ; ?></h2>
										<p class="text-muted"></p>
									</div>
								</div>
							</div><!-- COL END -->
							
						</div>
                    						            <div class="row">
                    							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                    								<div class="card">
                    									<div class="card-header">
                    										<h3 class="card-title">Top 5 des agences par nombre de prêts</h3>
                    									</div>
                    									<div class="card-body p-4">
                    									    <?php /*if(!empty($top5loan_countdetails)){ 
                    									        foreach($top5loan_countdetails as $tcount){
                    									    ?>
                    							        	<div class="mb-5">
                    											<p class="mb-2"><?php echo $tcount['department']?><span class="float-right text-muted"><?php echo  number_format($tcount['loancount'],0,',',',') ;?></span></p>
                    											<div class="progress h-2">
                    												<div class="progress-bar bg-primary" role="progressbar"></div>
                    											</div>
                    										</div>
                    									    <?php } } */ ?>
                    										
                    										
                    									</div>
                    								</div>
                    							</div><!-- COL END -->
                    							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                    								<div class="card">
                    									<div class="card-header">
                    										<h3 class="card-title">Top 5 des agences par montant de prêt</h3>
                    									</div>
                    									<div class="card-body p-4">
                    									    
                    									    <?php /* if(!empty($top5loan_amountdetails)){ 
                    									        foreach($top5loan_amountdetails as $tamount){
                    									    ?>
                    							        	<div class="mb-5">
                    											<p class="mb-2"><?php echo $tamount['department']?><span class="float-right text-muted"><?php echo number_format($tamount['total_amount'],0,',',',')  ;?></span></p>
                    											<div class="progress h-2">
                    												<div class="progress-bar bg-primary" role="progressbar"></div>
                    											</div>
                    										</div>
                    									    <?php } } */?>
                    									    
                    										<!--<div class="mb-5">-->
                    										<!--	<p class="mb-2">RR<span class="float-right text-muted">80000</span></p>-->
                    										<!--	<div class="progress h-2">-->
                    										<!--		<div class="progress-bar bg-primary w-80 " role="progressbar"></div>-->
                    										<!--	</div>-->
                    										<!--</div>-->
                    										<!--<div class="mb-5">-->
                    										<!--	<p class="mb-2">Prima<span class="float-right text-muted">700002</span></p>-->
                    										<!--	<div class="progress h-2">-->
                    										<!--		<div class="progress-bar bg-pink w-70" role="progressbar"></div>-->
                    										<!--	</div>-->
                    										<!--</div>-->
                    										<!--<div class="mb-5">-->
                    										<!--	<p class="mb-2">Bureau ADL<span class="float-right text-muted">802666</span></p>-->
                    										<!--	<div class="progress h-2">-->
                    										<!--		<div class="progress-bar bg-warning w-65" role="progressbar"></div>-->
                    										<!--	</div>-->
                    										<!--</div>-->
                    										<!--<div class="mb-5">-->
                    										<!--	<p class="mb-2">Devenir<span class="float-right text-muted">80856</span></p>-->
                    										<!--	<div class="progress h-2">-->
                    										<!--		<div class="progress-bar bg-danger w-80" role="progressbar"></div>-->
                    										<!--	</div>-->
                    										<!--</div>-->
                    										<!--<div class="mb-5">-->
                    										<!--	<p class="mb-2">Bureau ADL<span class="float-right text-muted">7077888</span></p>-->
                    										<!--	<div class="progress h-2">-->
                    										<!--		<div class="progress-bar bg-success w-60" role="progressbar"></div>-->
                    										<!--	</div>-->
                    										<!--</div>-->
                    										
                    									</div>
                    								</div>
                    							</div><!-- COL END -->
                    							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                    								<div class="card">
                    									<div class="card-header">
                    										<h3 class="card-title">Top 5 des agences avec le moins de prêts vieillissants (> 3 jours)</h3>
                    									</div>
                    									<div class="card-body p-4">
                    									    <?php /*if(!empty($top5agingloan)){
                    									        foreach($top5agingloan as $aging){
                    									    ?>
                    										<div class="mb-5">
                    											<p class="mb-2"><?php echo $aging['department'];?><span class="float-right text-muted"><?php echo $aging['totalcount'];?></span></p>
                    											<div class="progress h-2">
                    												<div class="progress-bar bg-primary" role="progressbar"></div>
                    											</div>
                    										</div>
                    									    <?php } }*/ ?>
                    										
                    									</div>
                    								</div>
                    							</div><!-- COL END -->
                    
                    						</div>
                                						<div class="row">
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">Top 5 des agences par rapport au nombre total de prêts par OBJECTIFS</h3>
                                									</div>
                                									<div class="card-body p-4">
                                									    
                                									    <?php /* if(!empty($trendingbranch_loannumber)) {
                                									            $branch_loancount = 1;
                                									            foreach($trendingbranch_loannumber as $branch_loanno){
                                									                
                                									                if($branch_loanno['progress']) {
                                									    ?>
                                										<div class="mb-5">
                                											<p class="mb-2"><?php echo $branch_loanno['department']; ?><span class="float-right text-muted"><?php echo number_format($branch_loanno['progress'], 2).'%';?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar bg-primary" role="progressbar"></div>
                                											</div>
                                										</div>
                                										
                                										<?php 
                                										
                                										    if($branch_loancount == 5){
                                										        break;
                                										    }
                                										    $branch_loancount ++;
                                									      } 
                                										}  } */?>
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">Top 5 des agences par rapport au montant total du prêt par OBJECTIFS</h3>
                                									</div>
                                									<div class="card-body p-4">
                                									 <?php /* if(!empty($trendingbranch_loanamount)) {
                                									            $branch_amtcount = 1;
                                									            foreach($trendingbranch_loanamount as $branch_loanamt){
                                									                
                                									                if($branch_loanamt['progress']) {
                                									    ?>
                                										<div class="mb-5">
                                											<p class="mb-2"><?php echo $branch_loanamt['department']; ?><span class="float-right text-muted"><?php echo number_format($branch_loanamt['progress'], 2).'%';?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar bg-primary" role="progressbar"></div>
                                											</div>
                                										</div>
                                										
                                										<?php 
                                										
                                										    if($branch_amtcount == 5){
                                										        break;
                                										    }
                                										    $branch_amtcount ++;
                                									      } 
                                										}  } */ ?>
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">Top 5 Placeurs par rapport au nombre total de prêts par OBJECTIFS</h3>
                                									</div>
                                									<div class="card-body p-4">
                                									 <?php /*if(!empty($trendingplaceur_loannumber)) {
                                									            $placeur_loancount = 1;
                                									            foreach($trendingplaceur_loannumber as $placeur_loanno){
                                									                
                                									                if($placeur_loanno['progress']) {
                                									    ?>
                                										<div class="mb-5">
                                											<p class="mb-2"><?php echo $placeur_loanno['department']; ?><span class="float-right text-muted"><?php echo number_format($placeur_loanno['progress'], 2).'%';?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar bg-primary" role="progressbar"></div>
                                											</div>
                                										</div>
                                										
                                										<?php 
                                										
                                										    if($placeur_loancount == 5){
                                										        break;
                                										    }
                                										    $placeur_loancount ++;
                                									      } 
                                										}  } */?>
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                
                                						</div>
                                
                                						<div class="row">
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">5 DERNIÈRES agences par Nbre de prêt</h3>
                                									</div>
                                									<div class="card-body p-4">
                                									 <?php /* if(!empty($last5loan_countdetails)){ 
                                									        foreach($last5loan_countdetails as $lcount){
                                									    ?>
                                							        	<div class="mb-5">
                                											<p class="mb-2"><?php echo $lcount['department']?><span class="float-right text-muted"><?php echo number_format($lcount['loancount'],0,',',',')  ;?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar bg-primary" role="progressbar"></div>
                                											</div>
                                										</div>
                                								    <?php } } */ ?>
                                										
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">5 DERNIÈRES  agences par montant de prêt</h3>
                                									</div>
                                									<div class="card-body p-4">
                                									 <?php /*if(!empty($last5loan_amountdetails)){ 
                                									        foreach($last5loan_amountdetails as $lamount){
                                									    ?>
                                							        	<div class="mb-5">
                                											<p class="mb-2"><?php echo $lamount['department']?><span class="float-right text-muted"><?php echo number_format($lamount['total_amount'],0,',',',')  ;?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar bg-primary" role="progressbar"></div>
                                											</div>
                                										</div>
                                								    <?php } }*/ ?>
                                										
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">Top 5 des agences avec des Nbre de prêt AGING</h3>
                                									</div>
                                									<div class="card-body p-4">
                                									    
                                									    <?php /* if(!empty($top5loan_moreagingloan)) {
                                									        foreach($top5loan_moreagingloan as $more_aging){
                                									    ?>
                                										<div class="mb-5">
                                											<p class="mb-2"><?php echo $more_aging['department']; ?><span class="float-right text-muted"><?php echo $more_aging['totalcount']; ?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar bg-primary" role="progressbar"></div>
                                											</div>
                                										</div>
                                										<?php } } */ ?>
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                
                                						</div>
                                
                                						<div class="row">
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">5 DERNIÈRES Agences par rapport au Nbre de prêt par OBJECTIFS</h3>
                                									</div>
                                									<div class="card-body p-4">
                                									
                                									<?php 
                                									  /*  
                                									if(!empty($last5branches_loanno)) {
                                									            $last_loancount = 1;
                                									            foreach($last5branches_loanno as $last_loanno){
                                									                
                                									                if($last_loanno['progress']) {
                                									    ?>
                                										<div class="mb-5">
                                											<p class="mb-2"><?php echo $last_loanno['department']; ?><span class="float-right text-muted"><?php echo number_format($last_loanno['progress'], 2).'%';?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar bg-primary" role="progressbar"></div>
                                											</div>
                                										</div>
                                										
                                										<?php 
                                										
                                										    if($last_loancount == 5){
                                										        break;
                                										    }
                                										    $last_loancount ++;
                                									      } 
                                										}  } */?>
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">5 DERNIÈRES agences par rapport au montant total du prêt par OBJECTIFS</h3>
                                									</div>
                                									<div class="card-body p-4">
                                										<?php 
                                									    /*
                                									if(!empty($last5branches_loanamt)) {
                                									            $last_loanamt = 1;
                                									            foreach($last5branches_loanamt as $last_amount){
                                									                
                                									                if($last_amount['progress']) {
                                									    ?>
                                										<div class="mb-5">
                                											<p class="mb-2"><?php echo $last_amount['department']; ?><span class="float-right text-muted"><?php echo number_format($last_amount['progress'], 2).'%';?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar bg-primary" role="progressbar"></div>
                                											</div>
                                										</div>
                                										
                                										<?php 
                                										
                                										    if($last_loanamt == 5){
                                										        break;
                                										    }
                                										    $last_loanamt ++;
                                									      } 
                                										}  } */?>
                                										
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">5 DERNIERS Placeurs par rapport au nombre total de prêts par OBJECTIFS</h3>
                                									</div>
                                									<div class="card-body p-4">
                                								    	<?php 
                                									    /*
                                									        if(!empty($last5placeur_loanno)) {
                                									            $last_placeur = 1;
                                									            foreach($last5placeur_loanno as $last_placeurloaanno){
                                									                
                                									                if($last_placeurloaanno['progress']) {
                                									    ?>
                                    										<div class="mb-5">
                                    											<p class="mb-2"><?php echo $last_placeurloaanno['department']; ?><span class="float-right text-muted"><?php echo number_format($last_placeurloaanno['progress'], 2).'%';?></span></p>
                                    											<div class="progress h-2">
                                    												<div class="progress-bar bg-primary" role="progressbar"></div>
                                    											</div>
                                    										</div>
                                										
                                										<?php 
                                										
                                										    if($last_placeur == 5){
                                										        break;
                                										    }
                                										    $last_placeur ++;
                                									      } 
                                										}  } */?>
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                
                                						</div>
                                
                                						<div class="row">
                                							
                                
                                							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
                                								<div class="card">
                                									<div class="card-body text-center">
                                										<i class="fa fa-globe text-primary fa-3x text-primary-shadow"></i>
                                										<h6 class="mt-4 mb-2">Nombre total d'annulations de prêt</h6>
                                										<h2 class="mb-2 number-font"><?php echo "0";
                                										//echo  number_format($Annuler_loannumber,0,',',',') ; ?></h2>
                                										<p class="text-muted"></p>
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                
                                							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
                                								<div class="card">
                                									<div class="card-body text-center">
                                										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
                                										<h6 class="mt-4 mb-2">Montant total de l'annulation du prêt</h6>
                                										<h2 class="mb-2  number-font"><?php echo "0";
                                										//echo  number_format($Annuler_loanamount,0,',',',') ; ?></h2>
                                										<p class="text-muted"></p>
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							
                                							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
                                								<div class="card">
                                									<div class="card-body text-center">
                                										<i class="fa fa-globe text-primary fa-3x text-primary-shadow"></i>
                                										<h6 class="mt-4 mb-2">Nombre total de prêt Abondonne</h6>
                                										<h2 class="mb-2 number-font"><?php echo "0";
                                										//echo  number_format($Abandonner_loannumber,0,',',',') ; ?></h2>
                                										<p class="text-muted"></p>
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
                                								<div class="card">
                                									<div class="card-body text-center">
                                										<i class="fa fa-money text-secondary fa-3x text-secondary-shadow"></i>
                                										<h6 class="mt-4 mb-2">Montant total du prêt Abondonne</h6>
                                										<h2 class="mb-2  number-font"><?php echo "0";
                                										//echo  number_format($Abandonner_loanamount,0,',',',') ; ?></h2>
                                										<p class="text-muted"></p>
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                						</div>
                                
                                						<div class="row">
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-3">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">Top 5 des agences par nombre total de prêts Annule</h3>
                                									</div>
                                									<div class="card-body p-4">
                                									    <?php /*if(!empty($top5loan_countdetails_annule)){ 
                                									        foreach($top5loan_countdetails_annule as $tcount){
                                									    ?>
                                							        	<div class="mb-5">
                                											<p class="mb-2"><?php echo $tcount['department']?><span class="float-right text-muted"><?php echo  number_format($tcount['loancount'],0,',',',') ;?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar bg-primary w-<?php echo  number_format($tcount['loancount'],0,',',',') ;?>" role="progressbar"></div>
                                											</div>
                                										</div>
                                									    <?php } } */ ?>
                                										
                                										
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-3">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">Top 5 des agences par montant total de prêt Annule</h3>
                                									</div>
                                									<div class="card-body p-4">
                                										<?php /*if(!empty($top5loan_amountdetails_annule)){ 
                                									        foreach($top5loan_amountdetails_annule as $tcount){
                                									    ?>
                                							        	<div class="mb-5">
                                											<p class="mb-2"><?php echo $tcount['department']?><span class="float-right text-muted"><?php echo  number_format($tcount['total_amount'],0,',',',') ;?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar bg-primary w-<?php echo  number_format($tcount['total_amount'],0,',',',') ;?>" role="progressbar"></div>
                                											</div>
                                										</div>
                                									    <?php } } */ ?>
                                										
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-3">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">Top 5 des agences par nombre total de prêts Abandon</h3>
                                									</div>
                                									<div class="card-body p-4">
                                										<?php /*if(!empty($top5loan_countdetails_Abandonner)){ 
                                									        foreach($top5loan_countdetails_Abandonner as $tcount){
                                									    ?>
                                							        	<div class="mb-5">
                                											<p class="mb-2"><?php echo $tcount['department']?><span class="float-right text-muted"><?php echo  number_format($tcount['loancount'],0,',',',') ;?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar bg-primary w-<?php echo  number_format($tcount['loancount'],0,',',',') ;?>" role="progressbar"></div>
                                											</div>
                                										</div>
                                									    <?php } } */ ?>
                                										
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                							<div class="col-sm-12 col-md-12 col-lg-12 col-xl-3">
                                								<div class="card">
                                									<div class="card-header">
                                										<h3 class="card-title">Top 5 des agences par montant total de prêt Abondonne</h3>
                                									</div>
                                									<div class="card-body p-4">
                                										<?php /* if(!empty($top5loan_amountdetails_Abandonner)){ 
                                									        foreach($top5loan_amountdetails_Abandonner as $tcount){
                                									    ?>
                                							        	<div class="mb-5">
                                											<p class="mb-2"><?php echo $tcount['department']?><span class="float-right text-muted"><?php echo  number_format($tcount['total_amount'],0,',',',') ;?></span></p>
                                											<div class="progress h-2">
                                												<div class="progress-bar bg-primary w-<?php echo  number_format($tcount['total_amount'],0,',',',') ;?>" role="progressbar"></div>
                                											</div>
                                										</div>
                                									    <?php } } */?>
                                										
                                										
                                									</div>
                                								</div>
                                							</div><!-- COL END -->
                                
                                						</div>
													</div>
													
												</div>
											</div>
										</div>
							
						</div>
						<!-- PAGE-HEADER END -->

						<!-- ROW-1 -->
						
						<!-- ROW-1 END -->


					</div>
				</div>
				<!-- CONTAINER END -->
            </div>


		</div>
					</div>
				</div>
			</div>			
		</div>
	</div>
	
</div>


</div>
</div>
</div>
<!-- JQUERY JS -->
<script src="<?php echo base_url('assets/volgh/assets/js/jquery-3.4.1.min.js');?>"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
 
<script src="<?php echo  base_url(); ?>assets/js/demo-skin-changer.js"></script>  
<script src="<?php echo  base_url(); ?>assets/js/jquery.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/bootstrap.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/jquery.nanoscroller.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/demo.js"></script>  
<script src="<?php echo  base_url(); ?>assets/js/jquery.scrollTo.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/jquery.slimscroll.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/moment.min.js"></script>

<script src="<?php echo  base_url(); ?>assets/js/raphael-min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/morris.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/scripts.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/pace.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/bootstrap-wizard.js"></script>


<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />

<script src="<?php echo  base_url(); ?>assets/js/jquery.dataTables.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/dataTables.fixedHeader.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/dataTables.tableTools.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/jquery.dataTables.bootstrap.js"></script>
 
<script src="<?php echo base_url();?>assets/js/modernizr.custom.js"></script> 
<script src="<?php echo base_url();?>assets/js/notificationFx.js"></script> 
<script src="<?php echo  base_url(); ?>assets/js/classie.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/xlsx.full.min.js"></script>
  


<!-- BOOTSTRAP JS -->
<!-- <script src="<?php echo base_url('assets/volgh/assets/plugins/bootstrap/js/bootstrap.bundle.min.js');?>"></script> -->
<script src="<?php echo base_url('assets/volgh/assets/plugins/bootstrap/js/popper.min.js');?>"></script>
<!-- SPARKLINE JS-->
<script src="<?php echo base_url('assets/volgh/assets/js/jquery.sparkline.min.js');?>"></script>
<!-- ECHART JS-->
<script src="<?php echo base_url('assets/volgh/assets/plugins/echarts/echarts.js');?>"></script>
<!-- SIDEBAR JS -->
<script src="<?php echo base_url('assets/volgh/assets//plugins/sidebar/sidebar.js');?>"></script>
<!-- INDEX JS -->
<script src="<?php echo base_url('assets/volgh/assets/js/index1.js');?>"></script>
<!-- CUSTOM JS -->
<script src="<?php echo base_url('assets/volgh/assets/js/custom.js');?>"></script>
<style type="text/css">
	.app-content div .page-header .panel{
		max-width: 100% !important;
		width: 100% !important;
	}
</style>
<style type="text/css">
	#sidebar-nav[aria-expanded="true"]{
		height: 100% !important;
		display: block !important;
	}
	@media screen and (max-width: 991px){
		#nav-col{
			width: 100% !important;
		}
	}
</style>
<script>
	// ('.navbar-toggle').click(function(){
	// 	if($('#sidebar-nav').hasClass('d-none')){
	// 		alert('asd');
	// 		$('#sidebar-nav').removeClass('d-none');
	// 	}else{
	// 		alert('1122');

	// 		$('#sidebar-nav').addClass('d-none');
	// 		$('#sidebar-nav').addClass('h-100');
	// 	}
	// });
	$(document).on('click', '.tabs-menu1 ul li' ,function(e){
		e.preventDefault();
		$('.tabs-menu1 ul li').removeClass('active');
		$('.tabs-menu1 ul li a').removeClass('active');
		$(this).addClass('active');
		$(this).find('a').addClass('active');
	});
//import * as echarts from 'echarts';
var app = {};

var chartDom = document.getElementById('echart2');
var myChart = echarts.init(chartDom);
var option;

const posList = [
  'left',
  'right',
  'top',
  'bottom',
  'inside',
  'insideTop',
  'insideLeft',
  'insideRight',
  'insideBottom',
  'insideTopLeft',
  'insideTopRight',
  'insideBottomLeft',
  'insideBottomRight'
];
app.configParameters = {
  rotate: {
    min: -90,
    max: 90
  },
  align: {
    options: {
      left: 'left',
      center: 'center',
      right: 'right'
    }
  },
  verticalAlign: {
    options: {
      top: 'top',
      middle: 'middle',
      bottom: 'bottom'
    }
  },
  position: {
    options: posList.reduce(function (map, pos) {
      map[pos] = pos;
      return map;
    }, {})
  },
  distance: {
    min: 0,
    max: 100
  }
};
app.config = {
  rotate: 90,
  align: 'left',
  verticalAlign: 'middle',
  position: 'insideBottom',
  distance: 15,
  onChange: function () {
    const labelOption = {
      rotate: app.config.rotate,
      align: app.config.align,
      verticalAlign: app.config.verticalAlign,
      position: app.config.position,
      distance: app.config.distance
    };
    myChart.setOption({
      series: [
        {
          label: labelOption
        },
        {
          label: labelOption
        },
        {
          label: labelOption
        },
        {
          label: labelOption
        }
      ]
    });
  }
};
const labelOption = {
  show: true,
  position: app.config.position,
  distance: app.config.distance,
  align: app.config.align,
  verticalAlign: app.config.verticalAlign,
  rotate: app.config.rotate,
  formatter: '{c}  {name|{a}}',
  fontSize: 16,
  rich: {
    name: {}
  }
};
option = {
  tooltip: {
    trigger: 'axis',
    axisPointer: {
      type: 'shadow'
    }
  },
  legend: {
    data: ['Actives', 'Approved', 'In Process', 'Annule/Abondon']
  },
  toolbox: {
    show: true,
    orient: 'vertical',
    left: 'right',
    top: 'center',
    feature: {
    //   mark: { show: true,title: "Reset" },
    //   dataView: { show: true, readOnly: false ,title: "Reset1"},
      magicType: { show: true, type: ['line', 'bar', 'stack'],title: {  line: "Line", bar: "Bar", stack:"Stack"  } },
      restore: { show: true,title: "Reset" },
      saveAsImage: { show: true, title: "Save as Image" }
    }
  },
  xAxis: [
    {
      type: 'category',
      axisTick: { show: false },
      data: ['This Semaine', 'Semaine 1', 'Semaine 2', 'Semaine 3']
    }
  ],
  yAxis: [
    {
      type: 'value'
    }
  ],
  series: [
    {
      name: 'Actives',
      type: 'bar',
      barGap: 0,
      label: labelOption,
      emphasis: {
        focus: 'series'
      },
      data: [<?php echo $this_week_data_actives; ?>, <?php echo $prev_week_data1_actives; ?>, <?php echo $prev_week_data2_actives; ?>, <?php echo $prev_week_data3_actives; ?>]
    },
    {
      name: 'Approved',
      type: 'bar',
      label: labelOption,
      emphasis: {
        focus: 'series'
      },
      data: [<?php echo $this_week_data_approved; ?>, <?php echo $prev_week_data1_approved; ?>, <?php echo $prev_week_data2_approved; ?>, <?php echo $prev_week_data3_approved; ?>]
    },
    {
      name: 'In Process',
      type: 'bar',
      label: labelOption,
      emphasis: {
        focus: 'series'
      },
      data: [<?php echo $this_week_data_in_process; ?>, <?php echo $prev_week_data1_cancelled; ?>, <?php echo $prev_week_data2_cancelled; ?>, <?php echo $prev_week_data3_cancelled; ?>]
    },
    {
      name: 'Annule/Abondon',
      type: 'bar',
      label: labelOption,
      emphasis: {
        focus: 'series'
      },
      data: [<?php echo $this_week_data_cancelled;?>, <?php echo $prev_week_data1_in_process; ?>, <?php echo $prev_week_data2_in_process; ?>, <?php echo $prev_week_data3_in_process; ?>]
    }
  ]
};

option && myChart.setOption(option);
</script>

</body>
</html>