<style type="text/css">
	.hidden { display: none; }

	.lodertypeof {    
    background-color: #dff0d8c7;
    background-image: url("<?php echo base_url('assets/img/select2-spinner.gif');?>");
    background-size: 18px 18px;
    background-position:right center;
    background-repeat: no-repeat;
    opacity: 0.5;
    }
    
    .pending_row{
        background-color: #ededb5;  
    }
    
    .rejected_row{
        background-color: #ff000047;
    }
    
    .approved_row{
        background-color: #8fbc8f8c;
    }
    
    .gen_row{
        background-color: lightblue;
    }
    
    .theader{
        font-size:12px;
        font-weight:600;
    }
</style>
<div id="content-wrapper">
	<div class="row">
		<div class="col-lg-12">

			<div id="content-header" class="clearfix">
				<div class="pull-left">
					<ol class="breadcrumb">
						<li><a href="<?php echo base_url('Dashboard');?>">TABLEAU DE BORD</a></li>
						<li class="active"><span> Prêts Hors Délai</span></li>
					</ol>
				</div>

			</div>
			<div class="main-box-body clearfix">
            		<div class="row" style="margin-top:10px;">					
					<div class="col-lg-12">
						
						
						<div class="main-box clearfix">

							<header class="main-box-header clearfix">
							    <div class="form-group">
									<form id="" action="<?php echo base_url('Inside_data/aging_loans')?>" method="POST">

                                        <div class="row" style="margin-top:2%">
                                            
                                            <div class="col-md-4">

    											<label class="col-md-3 control-label">Productivité:</label>
    											
    											<div class="col-md-8">
    											     <input type="radio" name="loan_type" value="credit_conso" <?php if($_POST['loan_type'] == "credit_conso"){ echo "checked";  } else {  if($active_loan['loan_id'] == "1") echo "checked";   }?> > Fêtes à la Carte <br/>
    											    <input type="radio" name="loan_type" value="credit_scolair" <?php if($_POST['loan_type'] == "credit_scolair") {echo "checked";  } else { if($active_loan['loan_id'] == "2") echo "checked";  }?>  > Congés à la Carte <br/>
    											    <input type="radio" name="loan_type" value="credit_confort" <?php if($_POST['loan_type'] == "credit_confort"){ echo "checked";  } else { if($active_loan['loan_id'] == "3") echo "checked";   }?>  > Crédit Confort <br/>
    											    <input type="radio" name="loan_type" value="pp_scolair" <?php if($_POST['loan_type'] == "pp_scolair") {echo "checked"; } else {  if($active_loan['loan_id'] == "4") echo "checked"; }?> > Crédit Scolaire <br/>
    			
    											</div>
											
											</div>
											
										    <div class="col-md-4">
										    	<button  type ="submit" class="btn btn-primary">Sélectionner</button> &nbsp;
										        <button id="btnExport" class="btn btn-primary" onclick="fnExcelReport('xlsx');"> Exporter </button>&nbsp;
										        <button id="btnPdf" type="button" class="btn btn-primary" onclick="generatePDF();"> PDF </button>
											</div>
										</div>
										
										
										
									</form>
								
								</div>
							</header>

							<div class="main-box-body clearfix">

								<div class="table-responsive">
								   
									<table id="table-example1" class="table table-hover table-striped">
										<thead>
											<tr>
											    <!--Loan Product -->
											    <th>Produit</th>
											    <!--Application # -->
												<th>№ Demande</th>
												<th>Agence</th>
												<th>Groupe Agence</th>
												<!--Comment-->
												<th>Commentaire</th>
												<!--Loan Amount-->
												<th>Montant du prêt</th>
											</tr>
										</thead>
										<tbody id="getrecord">
										    <?php if(!empty($result)){
										        foreach($result as $res){
										    ?>
										    <tr>
										        <td><?php echo $type; ?></td>
										        <td><?php echo $res['application_no']; ?></td>
										        <td><?php echo $res['department'];?></td>
										        <td><?php echo $res['branch']; ?></td>
										        <td><?php echo $res['current_status']; ?></td>
										        <td><?php echo $res['loan_amount']; ?></td>
										    </tr>
										    <?php } } ?>
										</tbody>
									</table>
									
									
									<table id="table-example" class="table table-hover table-striped" style="display:none;">
										<thead>
											<tr>
											    <!--Loan Product -->
											    <th>Produit</th>
											    <!--Application # -->
												<th>№ Demande</th>
												<th>Agence</th>
												<th>Groupe Agence</th>
												<!--Comment-->
												<th>Commentaire</th>
												<!--Loan Amount-->
												<th>Montant du prêt</th>
											</tr>
										</thead>
										<tbody id="getrecord">
										    <?php if(!empty($result)){
										        foreach($result as $res){
										    ?>
										    <tr>
										        <td><?php echo $type; ?></td>
										        <td><?php echo $res['application_no']; ?></td>
										        <td><?php echo $res['department'];?></td>
										        <td><?php echo $res['branch']; ?></td>
										        <td><?php echo $res['current_status']; ?></td>
										        <td><?php echo $res['loan_amount']; ?></td>
										    </tr>
										    <?php } } ?>
										</tbody>
									</table>
								</div>

							</div>
						</div>
					</div>
				</div>
			</div>			
		</div>
	</div>
	
</div>

 <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Filter</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      	<form id="" action="<?php echo base_url('Inside_data/placeur_approval')?>" method="POST">
      <div class="modal-body">
        <div class="form-group">
								

                                        <div class="row">
                                            
                                            <div class="col-md-6">

    											<label class="col-md-3 control-label">Productivité:</label>
    											
    											<div class="col-md-9">
    											    <input type="radio" name="loan_type" value="credit_conso" checked > Fêtes à la Carte <br/>
    											    <input type="radio" name="loan_type" value="credit_scolair"> Congés à la Carte <br/>
    											    <input type="radio" name="loan_type" value="credit_confort"> Crédit Confort <br/>
    											    <input type="radio" name="loan_type" value="pp_scolair"> Crédit Scolaire <br/>
    											    
    											
    			
    											</div>
											
											</div>
											
											<div class="col-md-6">
										    	<label class="col-md-2 control-label">Date:</label>

    											<div class="col-md-10">
    											    <input type="radio" name="date_type" value="today" > Today <br/>
    											    <input type="radio" name="date_type" value="yesterday"> Yesterday <br/>
    											    <input type="radio" name="date_type" value="this_week"> This Week <br/>
    											    <input type="radio" name="date_type" value="last_week"> Last Week <br/>
    											    <input type="radio" name="date_type" value="15_days"> Last 15 Days <br/>
    											    <input type="radio" name="date_type" value="this_month"> This Month <br/>
    											    <input type="radio" name="date_type" value="last_month"> Last Month <br/>
    											    <input type="radio" name="date_type" value="custom_range"> Custom Range <br/>
    											    
    											</div>
											</div>
											
										
										</div>
										
										
										
									
									
								</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button  type ="submit" class="btn btn-success">Sélectionner</button> &nbsp;
        
      </div>
      
      </form>
    </div>
  </div>
</div>

</div>
</div>
</div>

 
<script src="<?php echo  base_url(); ?>assets/js/demo-skin-changer.js"></script>  
<script src="<?php echo  base_url(); ?>assets/js/jquery.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/bootstrap.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/jquery.nanoscroller.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/demo.js"></script>  
<script src="<?php echo  base_url(); ?>assets/js/jquery.scrollTo.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/jquery.slimscroll.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/moment.min.js"></script>
<!-- 
<script src="<?php echo  base_url(); ?>assets/js/jquery-jvectormap-1.2.2.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/jquery-jvectormap-world-merc-en.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/gdp-data.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/flot/jquery.flot.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/flot/jquery.flot.resize.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/flot/jquery.flot.time.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/flot/jquery.flot.threshold.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/flot/jquery.flot.axislabels.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/jquery.sparkline.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/skycons.js"></script> -->

<script src="<?php echo  base_url(); ?>assets/js/raphael-min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/morris.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/scripts.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/pace.min.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/bootstrap-wizard.js"></script>

<!-- <script src="<?php echo  base_url(); ?>assets/js/select2.min.js"></script>
<script src="<?php echo base_url('assets/js/jquery.validate.min.js');?>"></script> 
<script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script> -->


<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />

<script src="<?php echo  base_url(); ?>assets/js/jquery.dataTables.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/dataTables.fixedHeader.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/dataTables.tableTools.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/jquery.dataTables.bootstrap.js"></script>
 
<script src="<?php echo base_url();?>assets/js/modernizr.custom.js"></script> 
<script src="<?php echo base_url();?>assets/js/notificationFx.js"></script> 
<script src="<?php echo  base_url(); ?>assets/js/classie.js"></script>
<script src="<?php echo  base_url(); ?>assets/js/xlsx.full.min.js"></script>
  
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.min.js"></script>  
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.6/jspdf.plugin.autotable.min.js"></script>  

<script type="text/javascript">

	$('input[name="daterange"]').daterangepicker({
		locale: {
	      format: 'YYYY/M/DD'
	    }
	});
	
function generatePDF() {
    
     var doc = new jsPDF('p', 'pt', 'letter');  
    var htmlstring = '';  
    var tempVarToCheckPageHeight = 0;  
    var pageHeight = 0;  
    pageHeight = doc.internal.pageSize.height;  
    specialElementHandlers = {  
        // element with id of "bypass" - jQuery style selector  
        '#bypassme': function(element, renderer) {  
            // true = "handled elsewhere, bypass text extraction"  
            return true  
        }  
    };  
    margins = {  
        top: 150,  
        bottom: 60,  
        left: 40,  
        right: 40,  
        width: 600  
    };  
    var y = 20;  
    doc.setLineWidth(2);  
    doc.text(200, y = y + 30, "Aging Loans");  
    doc.autoTable({  
        html: '#table-example',  
        startY: 70,  
        theme: 'grid',  
        // columnStyles: {  
        //     0: {  
        //         cellWidth: 180,  
        //     },  
        //     1: {  
        //         cellWidth: 180,  
        //     },  
        //     2: {  
        //         cellWidth: 180,  
        //     }  
        // },  
        // styles: {  
        //     minCellHeight: 40  
        // }  
    })  
    doc.save('Aging_Loans.pdf');  


//  var doc = new jsPDF();
//   doc.fromHTML(document.getElementById("table-example"), // page element which you want to print as PDF
//   15,
//   15, 
//   {
//     'width': 170
//   },
//   function(a) 
//   {
//     doc.save("HTML2PDF.pdf");
//   });
}

Highcharts.setOptions({
    colors: Highcharts.map(Highcharts.getOptions().colors, function (color) {
        return {
            radialGradient: {
                cx: 0.5,
                cy: 0.3,
                r: 0.7
            },
            stops: [
                [0, color],
                [1, Highcharts.color(color).brighten(-0.3).get('rgb')] // darken
            ]
        };
    })
});


// Highcharts.chart('container', {
//     chart: {
//         plotBackgroundColor: null,
//         plotBorderWidth: null,
//         plotShadow: false,
//         type: 'pie'
//     },
//     title: {
//         text: 'Status Overview'
//     },
//     tooltip: {
//         pointFormat: '{series.name}: <b>{point.y}</b>'
//     },
//     accessibility: {
//         point: {
//             valueSuffix: '%'
//         }
//     },
//     plotOptions: {
//         pie: {
//             allowPointSelect: true,
//             cursor: 'pointer',
//             dataLabels: {
//                 enabled: true,
//                 format: '<b>{point.name}</b>: {point.y}',
//                 connectorColor: 'silver'
//             }
//         }
//     },
//     series: [{
//         name: 'Count',
//         data:<?php echo $pie_data; ?>
//     }]
// });


$( document ).ready(function() {
    $(".highcharts-credits").css('display','none');


});

	


	

	// show popup notification 

   function notificationcall(data, status)
  {
      var notification = new NotificationFx({
          message : data,
          layout : 'bar',
          effect : 'slidetop',
          type : status          
        });
          notification.show();
          this.disabled = true;
  }
</script>

<script>
function fnExcelReport(type, fn, dl)
{
      var elt = document.getElementById('table-example');
    var wb = XLSX.utils.table_to_book(elt, { sheet: "Aging_Loans" });
    return dl ?
        XLSX.write(wb, { bookType: type, bookSST: true, type: 'base64' }) :
        XLSX.writeFile(wb, fn || ('Aging_Loans.' + (type || 'xlsx')));

}
$(window).load(function(){
    // alert('table');
		var table = $('#table-example1').dataTable({
			//'info': false,
			'sDom': 'lTfr<"clearfix">tip',
			"oLanguage": {
			  "sSearch": "<span>RECHERCHER:</span> _INPUT_", //search
			  "sLengthMenu": "AFFICHAGE _MENU_ ENREGISTREMENTS",
			},
		
		});		
		
	    var tt = new $.fn.dataTable.TableTools( table );
		$( tt.fnContainer() ).insertBefore('div.dataTables_wrapper');		
		var tableFixed = $('#table-example-fixed').dataTable({
			'info': false,
			'pageLength': 50
		});	
});

	$('#loan_schedule').change(function() {	    
	    var $option = $(this).find('option:selected');	    
	    var value = $option.val();//to get content of "value" attrib
	    var text = $option.text();//to get <option>Text</option> content
	    $('.addsch').html(text);

	});
	</script>

</body>
</html>