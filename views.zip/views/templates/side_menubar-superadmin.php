<?php
$user_permission = explode(',', $menu_permission['user_permission']);
?>
<link rel="stylesheet" href="<?php echo base_url('assets/css/libs/themify-icons.css'); ?>">
<style>
	/* @font-face {
	font-family: 'themify';
	src: url(<?php echo base_url('assets/css/fonts/themify.woff'); ?>) format("woff"),
     url(<?php echo base_url('assets/css/fonts/themify.ttf'); ?>) format("truetype");
}
span.ti-dashboard {
    font-size: 22px !important;
    margin-left: 0 !important;
}
span.ti-dashboard + span {
    margin-left: 10px !important;
}
#sidebar-nav .nav>li>a>span.ti-dashboard {
    font-weight: 100 !important;
} */
	.theme-blue #sidebar-nav .nav-pills>li.active>a>i.main-icon {
		color: #fff !important;
	}

	.theme-blue #sidebar-nav .nav>li>a {
		display: flex;
		align-items: center;
	}

	.theme-blue #sidebar-nav .nav>li img#menu_icon {
		display: none;
	}

	#sidebar-nav .nav>li>a>span {
		margin-left: 20px;
	}
	
	#sidebar-nav .submenu>li>a>span {
		margin-left: 12px;
	}
	
	.notify-badge {
      background-color: #f3786d;
      color: white;
      padding: 0px 5px;
      text-align: center;
      border-radius: 20%;
    }
    
    #sidebar-nav .submenu>li>a>.notify-badge {
		padding: 2px 5px;
	}
</style>
<div id="nav-col">
	<section id="col-left" class="col-left-nano">
		<div id="col-left-inner" class="col-left-nano-content">
			<div class="collapse navbar-collapse navbar-ex1-collapse" id="sidebar-nav">
				<ul class="nav nav-pills nav-stacked" style="display: block;">
					<li class="nav-header nav-header-first hidden-sm hidden-xs">
						Navigation
					</li>
					
					<?php
					if ($this->session->userdata('role')) {
					?>
						<li <?php echo ($page == 'Dashboard') ? ('class="active"') : ''; ?> <?php if (!in_array('1', $user_permission)) { ?> style="display:none;" <?php } ?>>
							<a href="<?php echo base_url('Dashboard'); ?>"><img src="<?php echo base_url('assets/img/icons1/menu.png'); ?>" id="menu_icon" class="icon-container black_img">
								<!-- <img src="<?php echo base_url('assets/img/icons1/menu_w.png'); ?>" id="menu_icon" class="white_img"> -->
								<i class="fa fa-desktop main-icon" aria-hidden="true"></i>
								<span class="icon-name">Tableau De Bord</span>
							</a>
						</li>
						<li <?php echo ($page == 'Customer') ? ('class="active"') : ''; ?> <?php if (!in_array('2', $user_permission)) { ?> style="display:none;" <?php } ?>>
							<a href="<?php echo base_url('Customer'); ?>"><img src="<?php echo base_url('assets/img/icons1/target.png'); ?>" id="menu_icon" class="black_img">
								<!-- <img src="<?php echo base_url('assets/img/icons1/target_w.png'); ?>" id="menu_icon" class="white_img"> -->
								<i class="fa fa fa-user main-icon" aria-hidden="true"></i>
								<span>Clientéle Particuliers</span>
							</a>
						</li>
						<li <?php echo ($page == 'PP_FETES_A_LA_CARTE' || $page == "PP CONGES A LA CARTE" || $page == "PP_Credit_Confort" || $page == "PP_Credit_Scolaire") ? ('class="active"') : ''; ?>>
							<a href="#" class="dropdown-toggle"><img src="<?php echo base_url('assets/img/icons1/analytics.png'); ?>" id="menu_icon" class="black_img">
								<i class="fa fa-newspaper-o main-icon" aria-hidden="true"></i>
								<span>Crédits de Campagne</span>
								<?php
								    $credits_de_campagne =  $loan_notification['credit_conso'] + $loan_notification['credit_scolair'] + $loan_notification['credit_confort'] + $loan_notification['pp_scolair'];
								    echo (!empty($credits_de_campagne)) ? "<span class='notify-badge'>".$credits_de_campagne."</span>" :"";
								?>
								<i class="fa fa-angle-right drop-icon"></i>
							</a>
							<ul class="submenu">
								<li <?php
									echo ($page == 'PP_FETES_A_LA_CARTE') ? ('class="active"') : ''; ?> <?php if (!in_array('4', $user_permission)) { ?> style="display:none;" <?php } ?>>
									<a href="<?php if ($loan_products[0]['loan_id'] == '1' && $loan_products[0]['status'] == '1') {
													echo base_url($loan_products[0]['loan_adress']);
												} else {
													echo '#';
												} ?>"><img src="<?php echo base_url('assets/img/icons1/money_fetes.png'); ?>" id="menu_icon" class="black_img">
										<!-- <img src="<?php echo base_url('assets/img/icons1/money_fetes_w.png'); ?>" id="menu_icon" class="white_img"> -->
										<i class="fa fa-gift main-icon" aria-hidden="true"></i>
										<span>Fêtes à la Carte</span><?php echo (!empty($loan_notification['credit_conso'])) ? "<span class='notify-badge'>".$loan_notification['credit_conso']."</span>" :""; ?>
									</a>
								</li>
								<li <?php echo ($page == 'PP CONGES A LA CARTE') ? ('class="active"') : ''; ?> <?php if (!in_array('6', $user_permission)) { ?> style="display:none;" <?php } ?>>
									<a href="<?php if (($loan_products[1]['loan_id'] == '2') && ($loan_products[1]['status'] == '1')) {
													echo base_url($loan_products[1]['loan_adress']);
												} else {
													echo '#';
												} ?>"><img src="<?php echo base_url('assets/img/icons1/save-money.png'); ?>" id="menu_icon" class="black_img">
										<!-- <img src="<?php echo base_url('assets/img/icons1/save-money_w.png'); ?>" id="menu_icon" class="white_img"> -->
										<i class="fa fa-umbrella main-icon" aria-hidden="true"></i>
										<span>Congés à la Carte</span><?php echo (!empty($loan_notification['credit_scolair'])) ? "<span class='notify-badge'>".$loan_notification['credit_scolair']."</span>" :""; ?>
									</a>
								</li>
								<li <?php echo ($page == 'PP_Credit_Confort') ? ('class="active"') : ''; ?> <?php if (!in_array('7', $user_permission)) { ?> style="display:none;" <?php } ?>>
									<a href="<?php if ($loan_products[2]['loan_id'] == '3' && $loan_products[2]['status'] == '1') {
													echo base_url($loan_products[2]['loan_adress']);
												} else {
													echo '#';
												} ?>"><img src="<?php echo base_url('assets/img/icons1/money2.png'); ?>" id="menu_icon" class="black_img">
										<!-- <img src="<?php echo base_url('assets/img/icons1/money2_w.png'); ?>" id="menu_icon" class="white_img"> -->
										<i class="fa fa-diamond main-icon" aria-hidden="true"></i>
										<span>Crédit Confort</span><?php echo (!empty($loan_notification['credit_confort'])) ? "<span class='notify-badge'>".$loan_notification['credit_confort']."</span>" :""; ?>
									</a>
								</li>
								<li <?php echo ($page == 'PP_Credit_Scolaire') ? ('class="active"') : ''; ?> <?php if (!in_array('8', $user_permission)) { ?> style="display:none;" <?php } ?>>
									<a href="<?php if ($loan_products[3]['loan_id'] == '4' && $loan_products[3]['status'] == '1') {
													echo base_url($loan_products[3]['loan_adress']);
												} else {
													echo '#';
												} ?>"><img src="<?php echo base_url('assets/img/icons1/money2.png'); ?>" id="menu_icon" class="black_img">
										<!-- <img src="<?php echo base_url('assets/img/icons1/money2_w.png'); ?>" id="menu_icon" class="white_img"> -->
										<i class="fa fa-graduation-cap main-icon" aria-hidden="true"></i>
										<span>Crédit Scolaire</span><?php echo (!empty($loan_notification['pp_scolair'])) ? "<span class='notify-badge'>".$loan_notification['pp_scolair']."</span>" :""; ?>
									</a>
								</li>
							</ul>
						</li>
						<li <?php echo ($page == "Credit_Express") ? ('class="active"') : ''; ?>>
							<a href="#" class="dropdown-toggle"><img src="<?php echo base_url('assets/img/icons1/analytics.png'); ?>" id="menu_icon" class="black_img">
								<i class="fa fa-credit-card main-icon" aria-hidden="true"></i>
								
								<?php
								    $credits_prive_classiques =  $loan_notification['credit_express'] + $loan_notification['credit_sans_garantie'] + $loan_notification['credit_prive'] + $loan_notification['credit_prive_avec_gageespece'] + $loan_notification['credit_prive_avec_caution'];
								    echo (!empty($credits_prive_classiques)) ? "<span>Crédits Privés Class..</span> <span class='notify-badge'>".$credits_prive_classiques."</span>" :"<span>Crédits Privés Classiques</span>"; 
								?>
								<i class="fa fa-angle-right drop-icon"></i>
							</a>
							<ul class="submenu">
								<li <?php
									echo ($page == 'Credit_Express') ? ('class="active"') : ''; ?> <?php if (!in_array('12', $user_permission)) { ?> style="display:none;" <?php } ?>>
									<a href="<?php if ($loan_products[4]['loan_id'] == '5' && $loan_products[4]['status'] == '1') {
													echo base_url($loan_products[4]['loan_adress']);
												} else {
													echo '#';
												} ?>"><img src="<?php echo base_url('assets/img/icons1/money_fetes.png'); ?>" id="menu_icon" class="black_img">
										<!-- <img src="<?php echo base_url('assets/img/icons1/money_fetes_w.png'); ?>" id="menu_icon" class="white_img"> -->
										<i class="fe fe-box main-icon" aria-hidden="true"></i>
										<span>Credit Express</span><?php echo (!empty($loan_notification['credit_express'])) ? "<span class='notify-badge'>".$loan_notification['credit_express']."</span>" :""; ?>
									</a>
								</li>
								<li <?php echo ($page == 'CREDIT SANS GARANTIE') ? ('class="active"') : ''; ?> <?php if (!in_array('13', $user_permission)) { ?> style="display:none;" <?php } ?>>
									<a href="<?php if (($loan_products[5]['loan_id'] == '6') && ($loan_products[5]['status'] == '1')) {
													echo base_url($loan_products[5]['loan_adress']);
												} else {
													echo '#';
												} ?>"><img src="<?php echo base_url('assets/img/icons1/save-money.png'); ?>" id="menu_icon" class="black_img">
										<!-- <img src="<?php echo base_url('assets/img/icons1/save-money_w.png'); ?>" id="menu_icon" class="white_img"> -->
										<i class="fe fe-cpu main-icon" aria-hidden="true"></i>
										<span>Credit sans Garantie</span><?php echo (!empty($loan_notification['credit_sans_garantie'])) ? "<span class='notify-badge'>".$loan_notification['credit_sans_garantie']."</span>" :""; ?>
									</a>
								</li>
								<li <?php echo ($page == 'Credit_Prive') ? ('class="active"') : ''; ?> <?php if (!in_array('14', $user_permission)) { ?> style="display:none;" <?php } ?>>
									<a href="<?php if ($loan_products[6]['loan_id'] == '7' && $loan_products[6]['status'] == '1') {
													echo base_url($loan_products[6]['loan_adress']);
												} else {
													echo '#';
												} ?>"><img src="<?php echo base_url('assets/img/icons1/money2.png'); ?>" id="menu_icon" class="black_img">
										<!-- <img src="<?php echo base_url('assets/img/icons1/money2_w.png'); ?>" id="menu_icon" class="white_img"> -->
										<i class="fe fe-database main-icon" aria-hidden="true"></i>
										<span>Crédit Privé RG</span><?php echo (!empty($loan_notification['credit_prive'])) ? "<span class='notify-badge'>".$loan_notification['credit_prive']."</span>" :""; ?>
									</a>
								</li>
								<li <?php echo ($page == 'PP_CREDIT_PRIVE_GAGE_ESPECE') ? ('class="active"') : ''; ?> <?php if (!in_array('15', $user_permission)) { ?> style="display:none;" <?php } ?>>
									<a href="<?php if ($loan_products[7]['loan_id'] == '8' && $loan_products[7]['status'] == '1') {
													echo base_url($loan_products[7]['loan_adress']);
												} else {
													echo '#';
												} ?>"><img src="<?php echo base_url('assets/img/icons1/money2.png'); ?>" id="menu_icon" class="black_img">
										<!-- <img src="<?php echo base_url('assets/img/icons1/money2_w.png'); ?>" id="menu_icon" class="white_img"> -->
										<i class="fa fa-500px main-icon" aria-hidden="true"></i>
										<span>Crédit Privé avec Gage Espece</span><?php echo (!empty($loan_notification['credit_prive_avec_gageespece'])) ? "<span class='notify-badge'>".$loan_notification['credit_prive_avec_gageespece']."</span>" :""; ?>
									</a>
								</li>
								<li <?php echo ($page == 'credit_prive_avec_caution') ? ('class="active"') : ''; ?> <?php if (!in_array('16', $user_permission)) { ?> style="display:none;" <?php } ?>>
									<a href="<?php if ($loan_products[8]['loan_id'] == '9' && $loan_products[8]['status'] == '1') {
													echo base_url($loan_products[8]['loan_adress']);
												} else {
													echo '#';
												} ?>"><img src="<?php echo base_url('assets/img/icons1/money2.png'); ?>" id="menu_icon" class="black_img">
										<!-- <img src="<?php echo base_url('assets/img/icons1/money2_w.png'); ?>" id="menu_icon" class="white_img"> -->
										<i class="fa fa-archive main-icon" aria-hidden="true"></i>
										<span>Crédit Privé avec Caution</span><?php echo (!empty($loan_notification['credit_prive_avec_caution'])) ? "<span class='notify-badge'>".$loan_notification['credit_prive_avec_caution']."</span>" :""; ?>
									</a>
								</li>
							</ul>
						</li>
						<li <?php echo ($page == "Credit_Conventionnes" || $page == "Credit_Dero" || $page == "credit_aux") ? ('class="active"') : ''; ?>>
							<a href="#" class="dropdown-toggle"><img src="<?php echo base_url('assets/img/icons1/analytics.png'); ?>" id="menu_icon" class="black_img">
								<i class="fa fa-file-o main-icon" aria-hidden="true"></i>
								<span>Autres Produits</span>
								<?php
								    $autres_products =  $loan_notification['credit_conventionnes'] + $loan_notification['credit_dero'] + $loan_notification['credit_aux'];
								    echo (!empty($autres_products)) ? "<span class='notify-badge'>".$autres_products."</span>" :"";
								?>
								<i class="fa fa-angle-right drop-icon"></i>
							</a>
							<ul class="submenu">
								<li <?php
									echo ($page == 'Credit_Conventionnes') ? ('class="active"') : ''; ?> <?php if (!in_array('17', $user_permission)) { ?> style="display:none;" <?php } ?>>
									<a href="<?php if ($loan_products[9]['loan_id'] == '10' && $loan_products[9]['status'] == '1') {
													echo base_url($loan_products[9]['loan_adress']);
												} else {
													echo '#';
												} ?>"><img src="<?php echo base_url('assets/img/icons1/money_fetes.png'); ?>" id="menu_icon" class="black_img">
										<!-- <img src="<?php echo base_url('assets/img/icons1/money_fetes_w.png'); ?>" id="menu_icon" class="white_img"> -->
										<i class="fa fa-copy main-icon" aria-hidden="true"></i>
										<span>Crédits Conventionnés</span><?php echo (!empty($loan_notification['credit_conventionnes'])) ? "<span class='notify-badge'>".$loan_notification['credit_conventionnes']."</span>" :""; ?>
									</a>
								</li>
							
								<li <?php
									echo ($page == 'Credit_Dero') ? ('class="active"') : ''; ?> <?php if (!in_array('18', $user_permission)) { ?> style="display:none;" <?php } ?>>
									<a href="<?php if ($loan_products[13]['loan_id'] == '14' && $loan_products[13]['status'] == '1') {
													echo base_url($loan_products[13]['loan_adress']);
												} else {
													echo '#';
												} ?>"><img src="<?php echo base_url('assets/img/icons1/money_fetes.png'); ?>" id="menu_icon" class="black_img">
										<!-- <img src="<?php echo base_url('assets/img/icons1/money_fetes_w.png'); ?>" id="menu_icon" class="white_img"> -->
										<i class="fa fa-copy main-icon" aria-hidden="true"></i>
										<span><?= $loan_products[13]['loan_original_name']?></span><?php echo (!empty($loan_notification['credit_dero'])) ? "<span class='notify-badge'>".$loan_notification['credit_dero']."</span>" :""; ?>
									</a>
								</li>
							
								<li <?php
									echo ($page == 'credit_aux') ? ('class="active"') : ''; ?> <?php if (!in_array('19', $user_permission)) { ?> style="display:none;" <?php } ?>>
									<a href="<?php if ($loan_products[14]['loan_id'] == '15' && $loan_products[14]['status'] == '1') {
													echo base_url($loan_products[14]['loan_adress']);
												} else {
													echo '#';
												} ?>"><img src="<?php echo base_url('assets/img/icons1/money_fetes.png'); ?>" id="menu_icon" class="black_img">
										<!-- <img src="<?php echo base_url('assets/img/icons1/money_fetes_w.png'); ?>" id="menu_icon" class="white_img"> -->
										<i class="fa fa-copy main-icon" aria-hidden="true"></i>
										<span><?= $loan_products[14]['loan_original_name']?></span><?php echo (!empty($loan_notification['credit_aux'])) ? "<span class='notify-badge'>".$loan_notification['credit_aux']."</span>" :""; ?>
									</a>
								</li>
							</ul>
						</li>
						
						<li <?php echo ($page == 'onero_secteur' || $page == 'onero_retraite') ? ('class="active"') : ''; ?>>
							<a href="#" class="dropdown-toggle"><img src="<?php echo base_url('assets/img/icons1/analytics.png'); ?>" id="menu_icon" class="black_img">
								<i class="fa fa-file-o main-icon" aria-hidden="true"></i>
								<span>ONERO</span>	<?php
								    $onero =  $loan_notification['onero_secteur'] + $loan_notification['onero_retraite'] + $loan_notification['onero_sans_garantie'];
								    echo (!empty($onero)) ? "<span class='notify-badge'>".$onero."</span>" :"";
								?>
								<i class="fa fa-angle-right drop-icon"></i>
							</a>
							<ul class="submenu">
								<li <?php
									echo ($page == 'onero_secteur') ? ('class="active"') : ''; ?> <?php if (!in_array('20', $user_permission)) { ?> style="display:none;" <?php } ?>>
									<a href="<?php if ($loan_products[10]['loan_id'] == '11' && $loan_products[10]['status'] == '1') {
													echo base_url($loan_products[10]['loan_adress']);
												} else {
													echo '#';
												} ?>"><img src="<?php echo base_url('assets/img/icons1/money_fetes.png'); ?>" id="menu_icon" class="black_img">
										<!-- <img src="<?php echo base_url('assets/img/icons1/money_fetes_w.png'); ?>" id="menu_icon" class="white_img"> -->
										<i class="fa fa-copy main-icon" aria-hidden="true"></i>
										<span><?= $loan_products[10]['loan_original_name']?></span><?php echo (!empty($loan_notification['onero_secteur'])) ? "<span class='notify-badge'>".$loan_notification['onero_secteur']."</span>" :""; ?>
									</a>
								</li>
							
								<li <?php
									echo ($page == 'onero_retraite') ? ('class="active"') : ''; ?> <?php if (!in_array('21', $user_permission)) { ?> style="display:none;" <?php } ?>>
									<a href="<?php if ($loan_products[11]['loan_id'] == '12' && $loan_products[11]['status'] == '1') {
													echo base_url($loan_products[11]['loan_adress']);
												} else {
													echo '#';
												} ?>"><img src="<?php echo base_url('assets/img/icons1/money_fetes.png'); ?>" id="menu_icon" class="black_img">
										<!-- <img src="<?php echo base_url('assets/img/icons1/money_fetes_w.png'); ?>" id="menu_icon" class="white_img"> -->
										<i class="fa fa-copy main-icon" aria-hidden="true"></i>
										<span><?= $loan_products[11]['loan_original_name']?></span><?php echo (!empty($loan_notification['onero_retraite'])) ? "<span class='notify-badge'>".$loan_notification['onero_retraite']."</span>" :""; ?>
									</a>
								</li>
							
								<li <?php
									echo ($page == '') ? ('class="active"') : ''; ?> <?php if (!in_array('22', $user_permission)) { ?> style="display:none;" <?php } ?>>
									<a href="<?php if ($loan_products[12]['loan_id'] == '13' && $loan_products[12]['status'] == '1') {
													echo base_url($loan_products[12]['loan_adress']);
												} else {
													echo '#';
												} ?>"><img src="<?php echo base_url('assets/img/icons1/money_fetes.png'); ?>" id="menu_icon" class="black_img">
										<!-- <img src="<?php echo base_url('assets/img/icons1/money_fetes_w.png'); ?>" id="menu_icon" class="white_img"> -->
										<i class="fa fa-copy main-icon" aria-hidden="true"></i>
										<span><?= $loan_products[12]['loan_original_name']?></span><?php echo (!empty($loan_notification['onero_sans_garantie'])) ? "<span class='notify-badge'>".$loan_notification['onero_sans_garantie']."</span>" :""; ?>
									</a>
								</li>
							</ul>
						</li>
						<li <?php echo ($page == 'Weekly Report' || $page == "All Report" || $page == "Tokos Report") ? ('class="active"') : ''; ?> <?php //if(!in_array('10',$user_permission)){
																																					?> <?php //} 
																																						?>>
							<a href="#" class="dropdown-toggle"><img src="<?php echo base_url('assets/img/icons1/analytics.png'); ?>" id="menu_icon" class="black_img">
								<!-- <img src="<?php echo base_url('assets/img/icons1/analytics_w.png'); ?>" id="menu_icon" class="white_img"> -->
								<i class="fe fe-layers main-icon" aria-hidden="true"></i>
								<span>Rapports</span>
								<i class="fa fa-angle-right drop-icon"></i>
							</a>
							<ul class="submenu">
								<li>
									<a href="<?php echo base_url('Reports/weekly_report'); ?>" <?php echo ($page == 'Weekly Report') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Rapport Hebdomadaire</a>
								</li>
								<li>
									<a href="<?php echo base_url('Reports/all_report'); ?>" <?php echo ($page == 'All Report') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Rapport Agrégat</a>
								</li>
								<li>
									<a href="<?php echo base_url('Reports/tokos_report'); ?>" <?php echo ($page == 'Tokos Report') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Rapport Tokos</a>
								</li>
							</ul>
						</li>
						<li <?php echo ($page_title == 'Fetes à la Carte Inactive Loans' || $page_title == "Conges à la Carte Inactive Loans" || $page_title == "Credit Confort Inactive Loans") ? ('class="active"') : ''; ?>>
							<a href="#" class="dropdown-toggle"><img src="<?php echo base_url('assets/img/icons1/menu.png'); ?>" id="menu_icon" class="black_img">
								<!-- <img src="<?php echo base_url('assets/img/icons1/menu_w.png'); ?>" id="menu_icon" class="white_img"> -->
								<i class="fa fa-calendar-minus-o main-icon" aria-hidden="true"></i>
								<span>Prêts Inactifs
									<!--Inactive Loans-->
								</span>
								<i class="fa fa-angle-right drop-icon"></i>
							</a>
							<ul class="submenu">
								<li>
									<a href="<?php echo base_url('Inactive/fetes_a_la_carte'); ?>" <?php echo ($page_title == 'Fetes à la Carte Inactive Loans') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Fetes à la Carte</a>
								</li>
								<li>
									<a href="<?php echo base_url('Inactive/conges_a_la_carte'); ?>" <?php echo ($page_title == 'Conges à la Carte Inactive Loans') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Conges à la Carte</a>
								</li>
								<li>
									<a href="<?php echo base_url('Inactive/credit_confort'); ?>" <?php echo ($page_title == 'Credit Confort Inactive Loans') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Credit Confort</a>
								</li>
								<li>
									<a href="<?php echo base_url('Inactive/pp_scolair'); ?>" <?php echo ($page_title == 'Credit Scolaire Inactive Loans') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Credit Scolaire</a>
								</li>
								<li>
									<a href="<?php echo base_url('Inactive/credit_express'); ?>" <?php echo ($page_title == 'Credit Express Inactive Loans') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Credit Express</a>
								</li>
								<li>
									<a href="<?php echo base_url('Inactive/credit_sans_garantie'); ?>" <?php echo ($page_title == 'Credit Sans Garantie Inactive Loans') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Credit Sans Garantie</a>
								</li>
								<li>
									<a href="<?php echo base_url('Inactive/credit_prive'); ?>" <?php echo ($page_title == 'Credit Prive RG Inactive Loans') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Credit Prive RG</a>
								</li>
								<li>
									<a href="<?php echo base_url('Inactive/credit_conventionnes'); ?>" <?php echo ($page_title == 'Credit Conventionnes Inactive Loans') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Credit Conventionnes</a>
								</li>
								<li>
									<a href="<?php echo base_url('Inactive/credit_prive_gage_espece'); ?>" <?php echo ($page_title == 'Credit Prive avec Gage Espece Inactive Loans') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i>Crédit Privé avec Gage Espece</a>
								</li>
								
								<li>
									<a href="<?php echo base_url('Inactive/credit_prive_avec_caution'); ?>" <?php echo ($page_title == 'Credit Prive Avec Caution Inactive Loans') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i>Crédit Privé Avec Caution</a>
								</li>
								
								<li>
									<a href="<?php echo base_url('Inactive/onero_secteur'); ?>" <?php echo ($page_title == 'PP Onero Secteur Prive') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Onero Secteur Prive</a>
								</li>
								<li>
									<a href="<?php echo base_url('Inactive/onero_sans_garantie'); ?>" <?php echo ($page_title == 'PP Onero Sans Garantie') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Onero Secteur Public</a>
								</li>
								<li>
									<a href="<?php echo base_url('Inactive/credit_dero'); ?>" <?php echo ($page_title == 'Crédit Dérogatoire') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Crédit Dérogatoire</a>
								</li>
								<li>
									<a href="<?php echo base_url('Inactive/onero_retraite'); ?>" <?php echo ($page_title == 'PP Onero Retraite') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Onero Retraite BICIG</a>
								</li>
								<li>
									<a href="<?php echo base_url('Inactive/credit_aux'); ?>" <?php echo ($page_title == 'Crédit Aux Personnel') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Crédit Aux Personnel</a>
								</li>
							</ul>
						</li>
						<li <?php echo ($page == "Productivité By Agence" || $page == "Performances" || $page == "Loan Statuses" || $page == "Branch Approval" ||
								$page == "Placeur Approval" || $page == "Annule" || $page == "Abandon" || $page == "Aging Loans" || $page == "Revenu" ||
								$page == "Branch Trending by Loan Number" || $page == "Branch Trending by Loan Amount" || $page == "Placeur Trending by Loan Number" || $page == "Placeur Trending by Loan Amount") ? ('class="active"') : ''; ?> <?php if (!in_array('11', $user_permission)) { ?> style="display:none;" <?php } ?>>
							<a href="#" class="dropdown-toggle"><img src="<?php echo base_url('assets/img/icons1/analytics.png'); ?>" id="menu_icon" class="black_img">
								<!-- <img src="<?php echo base_url('assets/img/icons1/analytics_w.png'); ?>" id="menu_icon" class="white_img"> -->
								<i class="fa fa-bar-chart main-icon" aria-hidden="true"></i>
								<span>Rapports Détaillés</span>
								<i class="fa fa-angle-right drop-icon"></i>
							</a>
							<ul class="submenu">
								<li>
									<a href="<?php echo base_url('Inside_data/finance_report'); ?>" <?php echo ($page == 'Revenu') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Revenu</a>
								</li>
								<li>
									<a href="<?php echo base_url('Inside_data/agence_insight'); ?>" <?php echo ($page == 'Productivité By Agence') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Productivité par Agence</a>
								</li>
								<!--<li>-->
								<!--	<a href="<?php echo base_url('Inside_data/client_bancaire'); ?>" <?php echo ($page == 'Productivité By Client Agence Bancaire') ? ('class="active"') : ''; ?> >Productivité By Client Agence Bancaire</a>-->
								<!--</li>-->
								<li>
									<a href="<?php echo base_url('Inside_data/performances'); ?>" <?php echo ($page == 'Performances') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Les performances</a>
								</li>
								<li>
									<a href="<?php echo base_url('Inside_data/loan_statuses'); ?>" <?php echo ($page == 'Loan Statuses') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Statuts de Prêts</a>
								</li>
								<li>
									<a href="<?php echo base_url('Inside_data/branch_approval'); ?>" <?php echo ($page == 'Branch Approval') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Approbation Agences</a>
								</li>
								<li>
									<a href="<?php echo base_url('Inside_data/placeur_approval'); ?>" <?php echo ($page == 'Placeur Approval') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Approbation Placeurs</a>
								</li>
								<li>
									<a href="<?php echo base_url('Inside_data/trending_branch/loan_number'); ?>" <?php echo ($page == "Branch Trending by Loan Number") ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Progression nbre de Prêts Agence</a>
								</li>
								<li>
									<a href="<?php echo base_url('Inside_data/trending_branch/loan_amount'); ?>" <?php echo ($page == "Branch Trending by Loan Amount") ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Progression montant total de Prêts Agence</a>
								</li>
								<li>
									<a href="<?php echo base_url('Inside_data/trending_placeur/loan_number'); ?>" <?php echo ($page == 'Placeur Trending by Loan Number') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Progression Placeur par nombre de Prêts</a>
								</li>
								<li>
									<a href="<?php echo base_url('Inside_data/trending_placeur/loan_amount'); ?>" <?php echo ($page == 'Placeur Trending by Loan Amount') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Progression Placeur par montant de Prêts</a>
								</li>
								<li>
									<a href="<?php echo base_url('Inside_data/annule'); ?>" <?php echo ($page == 'Annule') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Prêts Annulés</a>
								</li>
								<li>
									<a href="<?php echo base_url('Inside_data/abandon'); ?>" <?php echo ($page == 'Abandon') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Prêts Abandonnés</a>
								</li>
								<li>
									<a href="<?php echo base_url('Inside_data/aging_loans'); ?>" <?php echo ($page == 'Aging Loans') ? ('class="active"') : ''; ?>> <i class="fa fa-minus drop-icon"></i> Prêts vieillissants</a>
								</li>
							</ul>
						</li>
						<li <?php echo ($page == 'Inside data dashboard') ? ('class="active"') : ''; ?> <?php if (!in_array('11', $user_permission)) { ?> style="display:none;" <?php } ?>>
							<a href="<?php echo base_url('Inside_data_dashboard'); ?>"><img src="<?php echo base_url('assets/img/icons1/analytics.png'); ?>" id="menu_icon" class="black_img">
								<!-- <img src="<?php echo base_url('assets/img/icons1/analytics_w.png'); ?>" id="menu_icon" class="white_img"> -->
								<i class="fa fa-line-chart main-icon" aria-hidden="true"></i>
								<span>Tableau Performance</span>
							</a>
						</li>
						
					<?php } ?>
				</ul>
			</div>
		</div>
	</section>
	<div id="nav-col-submenu"></div>
	<div id="nav-col-submenu"></div>
</div>